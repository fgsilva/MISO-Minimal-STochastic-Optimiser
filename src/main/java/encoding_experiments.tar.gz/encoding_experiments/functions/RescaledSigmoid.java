package encoding_experiments.functions;

import org.encog.engine.network.activation.ActivationFunction;
import org.encog.mathutil.BoundMath;


public class RescaledSigmoid implements ActivationFunction {

    /**
     * The serial id.
     */
    private static final long serialVersionUID = 1L;

    /**
     * The parameters.
     */
    private final double[] params;

    /**
     * Construct a steepend sigmoid activation function.
     */

    private double[] signedSigmoidTable;

    public RescaledSigmoid() {
        signedSigmoidTable = new double[6001];
        this.params = new double[0];
        for (int a = 0; a < 6001; a++) {
            signedSigmoidTable[a] = ((1 / (1 + Math.exp(-((a - 3000) / 1000.0)))) - 0.5) * 2.0;
//            unsignedSigmoidTable[a] = 1 / (1+exp(-((a-3000)/1000.0)));
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public final void activationFunction(final double[] x, final int start,
                                         final int size) {
        for (int i = start; i < start + size; i++) {
            x[i] = (1.0 / (1.0 + BoundMath.exp(-1 * x[i]))) * 2 - 1;
        }
    }

    /**
     * @return The object cloned;
     */
    @Override
    public final ActivationFunction clone() {
        RescaledSigmoid copy = new RescaledSigmoid();
        copy.signedSigmoidTable = this.signedSigmoidTable.clone();

        return copy;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public final double derivativeFunction(final double b, final double a) {
        return a * (1.0 - a);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public final String[] getParamNames() {
        final String[] result = {};
        return result;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public final double[] getParams() {
        return this.params;
    }

    /**
     * @return Return true, Elliott activation has a derivative.
     */
    @Override
    public final boolean hasDerivative() {
        return true;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public final void setParam(final int index, final double value) {
        this.params[index] = value;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getFactoryCode() {
        return null;
    }

}