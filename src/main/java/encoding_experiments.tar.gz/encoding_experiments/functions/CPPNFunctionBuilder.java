package encoding_experiments.functions;

import org.encog.engine.network.activation.ActivationClippedLinear;
import org.encog.engine.network.activation.ActivationFunction;
import org.encog.util.obj.ChooseObject;

public class CPPNFunctionBuilder {

    public void buildCPPNActivationFunctions(
            final ChooseObject<ActivationFunction> activationFunctions) {
        activationFunctions.clear();
        //f(x) = x
        activationFunctions.add(0.25, new ActivationClippedLinear());
        activationFunctions.add(0.25, new RescaledSigmoid());
        activationFunctions.add(0.25, new ActivationExtendedGaussian());
        activationFunctions.add(0.25, new ActivationExtendedSIN());

		
		/*activationFunctions.add(0.25, new ActivationClippedLinear());
        activationFunctions.add(0.25, new ActivationBipolarSteepenedSigmoid());
		activationFunctions.add(0.25, new ActivationGaussian());
		activationFunctions.add(0.25, new ActivationSIN());*/


        activationFunctions.finalizeStructure();


    }

}
