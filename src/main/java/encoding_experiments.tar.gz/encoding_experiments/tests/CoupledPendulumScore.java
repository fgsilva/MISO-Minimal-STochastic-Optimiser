package encoding_experiments.tests;

import org.encog.ml.CalculateScore;
import org.encog.ml.MLMethod;

import java.io.Serializable;

/**
 * @author fernando
 */
public class CoupledPendulumScore implements CalculateScore, Serializable {

    private final int carts;
    private final double chainLength;

    public CoupledPendulumScore(int carts, double chainLength) {
        this.carts = carts;
        this.chainLength = chainLength;
    }

    @Override
    public double calculateScore(MLMethod method) {
        CoupledPendulum instance = new CoupledPendulum(carts, chainLength);

        return instance.computeScore(method);

    }


    @Override
    public boolean requireSingleThreaded() {
        return false;
    }


    @Override
    public boolean shouldMinimize() {
        return false;
    }

}
