package encoding_experiments.tests;

import encoding_experiments.EvolutionEngine;

public class RunPendulum2 {

    public static void main(String[] args) throws Exception {
        long time = System.currentTimeMillis() / 1000;

        String spointAugment = "neatConfs/switch_point_inverted_pendulum_0hidden_augment.conf";

        time = System.currentTimeMillis() / 1000;
        System.out.println(spointAugment);
        EvolutionEngine.main(new String[]{spointAugment});
        System.out.println("TIME: " + (System.currentTimeMillis() / 1000 - time) + " seconds");
        Runtime.getRuntime().gc();

    }
}
