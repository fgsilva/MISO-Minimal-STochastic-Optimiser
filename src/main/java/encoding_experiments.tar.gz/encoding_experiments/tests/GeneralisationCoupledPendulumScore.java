package encoding_experiments.tests;

import org.encog.ml.CalculateScore;
import org.encog.ml.MLMethod;

import java.io.Serializable;

/**
 * @author fernando
 */
public class GeneralisationCoupledPendulumScore implements CalculateScore, Serializable {

    private final int carts;
    private final double chainLength;
    private final double worldWidth;

    public GeneralisationCoupledPendulumScore(int carts, double chainLength, double worldWidth) {
        this.carts = carts;
        this.chainLength = chainLength;
        this.worldWidth = worldWidth;
    }

    @Override
    public double calculateScore(MLMethod method) {
        GeneralisationCoupledPendulum instance = new GeneralisationCoupledPendulum(carts, chainLength, worldWidth);

        return instance.computeScore(method);

    }


    @Override
    public boolean requireSingleThreaded() {
        return false;
    }


    @Override
    public boolean shouldMinimize() {
        return false;
    }

}
