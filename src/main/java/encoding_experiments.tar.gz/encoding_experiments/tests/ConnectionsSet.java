package encoding_experiments.tests;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Random;

public class ConnectionsSet {

    private HashMap<Integer, int[]> inputNodesCoor, outputNodesCoor;
    private int nodesX, nodesY;
    private Random random;

    private HashMap<Integer, Integer> pairing = new HashMap<Integer, Integer>();

    public ConnectionsSet(int nodesX, int nodesY, int[] inputs, int[] outputs, Random random) {
        this.nodesX = nodesX;
        this.nodesY = nodesY;
        this.random = random;
        this.inputNodesCoor = new HashMap<Integer, int[]>(nodesX * nodesY);
        this.outputNodesCoor = new HashMap<Integer, int[]>(nodesX * nodesY);
        int index = 0;
        for (int col = 0; col < nodesX; col++) {
            for (int row = 0; row < nodesY; row++) {
                int inputId = inputs[index], outputId = outputs[index];
                int xCor = col, yCor = row;
                inputNodesCoor.put(inputId, new int[]{xCor, yCor});
                outputNodesCoor.put(outputId, new int[]{xCor, yCor});
                index++;
            }
        }
    }

    public void createPerfectPairing() {
        this.pairing.clear();
        ArrayList<Integer> inputKeys = new ArrayList<Integer>();
        inputKeys.addAll(inputNodesCoor.keySet());
        Collections.sort(inputKeys);

        ArrayList<Integer> outputKeys = new ArrayList<Integer>();
        outputKeys.addAll(outputNodesCoor.keySet());
        Collections.sort(outputKeys);

        for (int i = 0; i < inputKeys.size(); i++) {
            this.pairing.put(inputKeys.get(i), outputKeys.get(i));
        }
    }


    public void shuffleColumns(double reg) {
        if (reg > 0.999)
            return;
        ArrayList<int[]> connectionsRewired = new ArrayList<int[]>();
        int totalConnections = this.pairing.size();
        int unconstrainedConnections;
        if (reg < 0.0001)
            unconstrainedConnections = totalConnections;
        else
            unconstrainedConnections = (int) (totalConnections - (reg * totalConnections));
        //System.out.println("column; total: " + totalConnections + "; unconstrained: " + unconstrainedConnections);
        int numberRows = this.nodesY, swapped = 0;
        while (swapped < unconstrainedConnections) {
            int chosenRow = this.random.nextInt(numberRows);
            int connectionsToSwap;
            //odd number of connections to change
            if (swapped == 0 && unconstrainedConnections % 2 != 0)
                connectionsToSwap = 3;
            else
                connectionsToSwap = 2;
            if (swapColumnConnections(connectionsToSwap, chosenRow, connectionsRewired)) {
                swapped += connectionsToSwap;
            }
        }
    }

    public void shuffleRows(double reg) {
        if (reg > 0.999)
            return;
        ArrayList<int[]> connectionsRewired = new ArrayList<int[]>();
        int totalConnections = this.pairing.size();

        int unconstrainedConnections;
        if (reg < 0.0001)
            unconstrainedConnections = totalConnections;
        else
            unconstrainedConnections = (int) (totalConnections - (reg * totalConnections));
        int numberColumns = this.nodesX, swapped = 0;
        while (swapped < unconstrainedConnections) {
            int chosenColumn = this.random.nextInt(numberColumns);
            int connectionsToSwap;
            //odd number of connections to change
            if (swapped == 0 && unconstrainedConnections % 2 != 0)
                connectionsToSwap = 3;
            else
                connectionsToSwap = 2;
            if (swapRowConnections(connectionsToSwap, chosenColumn, connectionsRewired))
                swapped += connectionsToSwap;
        }
    }


    private void shuffleAndSwap(ArrayList<int[]> fromPosList, ArrayList<int[]> toPosList, int connectionsToSwap) {
        //shuffle
        while (listsHaveCommonPositions(fromPosList, toPosList)) {
            Collections.shuffle(toPosList, this.random);
        }
        //System.out.println("af: " + toString(fromPosList) + "\n" + toString(toPosList));
        for (int i = 0; i < connectionsToSwap; i++) {
            int[] from = fromPosList.get(i);
            int[] to = toPosList.get(i);
            int fromId = getNodeAt(from, this.inputNodesCoor), toId = getNodeAt(to, this.outputNodesCoor);
            this.pairing.put(fromId, toId);
            //System.out.println("s: " + fromId + " => " + toId);
        }
    }

    private boolean listsHaveCommonPositions(ArrayList<int[]> l1,
                                             ArrayList<int[]> l2) {
        for (int i = 0; i < l1.size(); i++) {
            int[] i1 = l1.get(i), i2 = l2.get(i);
            //short cut, we know the size of the int[]
            if (i1[0] == i2[0] && i1[1] == i2[1])
                return true;
        }

        return false;
    }

	/*private String toString(ArrayList<int[]> list) {
        StringBuilder builder = new StringBuilder();
		builder.append("[");
		for(int[] i : list){
			builder.append("(" + i[0] + "," + i[1] + ") -- ");
		}
		builder.append("]");
		return builder.toString();
	}*/

    private int getNodeAt(int[] coor, HashMap<Integer, int[]> map) {
        for (int key : map.keySet()) {
            int[] value = map.get(key);
            if (value[0] == coor[0] && value[1] == coor[1])
                return key;
        }
        try {
            throw new Exception("Invalid search");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return -1;
    }

    private boolean swapColumnConnections(int connectionsToSwap, int chosenRow,
                                          ArrayList<int[]> connectionsRewired) {
        int numberColumns = this.nodesX;
        int[] columns = new int[connectionsToSwap];
        for (int i = 0; i < columns.length; i++) {
            columns[i] = random.nextInt(numberColumns);
            if (i >= 1) {
                boolean foundRepeated = true;
                while (foundRepeated) {
                    foundRepeated = false;
                    for (int j = 0; j < i; j++) {
                        if (columns[i] == columns[j]) {
                            columns[i] = random.nextInt(numberColumns);
                            foundRepeated = true;
                            //quebrar a guarda
                            j = i;
                        }
                    }
                }
            }
        }
        //System.out.println("COLS: " + Arrays.toString(columns));
        ArrayList<int[]> toPosList = new ArrayList<int[]>();
        ArrayList<int[]> fromPos = new ArrayList<int[]>();
        for (int i = 0; i < connectionsToSwap; i++) {
            int[] vec = new int[]{columns[i], chosenRow};
            fromPos.add(vec);
            if (listContains(vec, connectionsRewired)) {
                return false;
            } else
                toPosList.add(vec.clone());
        }
        //shuffle
        shuffleAndSwap(fromPos, toPosList, connectionsToSwap);

        //mark as having been rewired
        connectionsRewired.addAll(toPosList);

        return true;
    }


    private boolean swapRowConnections(int connectionsToSwap, int chosenColumn,
                                       ArrayList<int[]> connectionsRewired) {
        int numberRows = this.nodesY;
        int[] rows = new int[connectionsToSwap];
        for (int i = 0; i < rows.length; i++) {
            rows[i] = random.nextInt(numberRows);
            if (i >= 1) {
                for (int j = 0; j < i; j++) {
                    while (rows[i] == rows[j]) {
                        rows[j] = random.nextInt(numberRows);
                    }
                }
            }
        }
        ArrayList<int[]> toPosList = new ArrayList<int[]>();
        ArrayList<int[]> fromPos = new ArrayList<int[]>();
        for (int i = 0; i < connectionsToSwap; i++) {
            int[] vec = new int[]{chosenColumn, rows[i]};
            fromPos.add(vec);
            if (listContains(vec, connectionsRewired)) {
                return false;
            } else
                toPosList.add(vec.clone());
        }

        //mark as having been rewired
        connectionsRewired.addAll(toPosList);
        shuffleAndSwap(fromPos, toPosList, connectionsToSwap);


        return true;
    }

    private boolean listContains(int[] is, ArrayList<int[]> connectionsRewired) {
        for (int[] c : connectionsRewired)
            if (c[0] == is[0] && c[1] == is[1])
                return true;

        return false;
    }

    public HashMap<Integer, Integer> getPairing() {
        return this.pairing;
    }
}
