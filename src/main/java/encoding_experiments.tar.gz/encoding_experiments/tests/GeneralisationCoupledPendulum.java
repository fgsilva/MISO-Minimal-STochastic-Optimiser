package encoding_experiments.tests;

import encoding_experiments.layeredNets.ANNLayer;
import encoding_experiments.layeredNets.ANNNeuron;
import encoding_experiments.layeredNets.ANNSynapse;
import encoding_experiments.layeredNets.LayeredANN;
import org.apache.commons.math3.util.FastMath;
import org.encog.ml.MLMethod;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * FROM : http://heikohamann.de/coupledInvertedPendulums/
 *
 * @author fernando
 */
public class GeneralisationCoupledPendulum implements Serializable {

    private final double PI = Math.PI;

    //note: chainMax = chainLength.
    private double Kp, Kl, g, length, Vmotor, Vbreak, deltaUV, deltaT;
    private double chainMin, chainMax, worldWidth;
    private int stepsPerRun, currentStep, crabNum;

    private double[] phi, omega, v, u, x;
    private double fitness;

    public GeneralisationCoupledPendulum(int myCrabNum, double chainLength, double worldW) {
        crabNum = myCrabNum;
        this.phi = new double[myCrabNum];
        this.omega = new double[myCrabNum];
        this.v = new double[myCrabNum];
        this.u = new double[myCrabNum];
        this.x = new double[myCrabNum];
        fitness = 0.0;

        Kp = 0.005;
        Kl = 0.05;
        g = 9.81;
        length = 0.5;
        Vmotor = 7.0;
        Vbreak = 8.5;
        deltaUV = 0.05;

        deltaT = 0.01;

        chainMin = 0.05;
        this.chainMax = chainLength;
        //chainMax = 0.35;
        this.worldWidth = worldW;

        stepsPerRun = 4000;
        currentStep = 0;

        initialPosition();
    }

    public double computeScore(MLMethod method) {
        //this.fitness = 0;
        //this.currentStep = 0;

        //before
        //NEATNetwork net = (NEATNetwork) method;
        LayeredANN net = (LayeredANN) method;
        //System.out.println(net.getOutputCount());

        ArrayList<ANNNeuron> originalNeurons = net.getAllNeurons();
        ArrayList<ANNSynapse> originalSynapses = net.getAllSynapses();


        //copy controllers
        LayeredANN[] controllers = new LayeredANN[this.crabNum];
        if (this.crabNum > 1) {
            for (int i = 0; i < controllers.length; i++) {
                controllers[i] = createCopyNet(
                        net, originalNeurons, originalSynapses);
            }
        } else {
            controllers[0] = net;
        }

        //conduct simulation
        while (currentStep < stepsPerRun) {
            int[][] sensors = this.getSensorValues();
            int[][] outputs = new int[this.crabNum][];

            for (int j = 0; j < this.crabNum; j++) {
                double[] netInputs = normaliseSensorsValues(sensors[j]);
                outputs[j] = computeNormalisedOutputs(netInputs,
                        controllers[j]);
                /*if(outputs[j].length < 2){
                    System.out.println("going to blow");
				}*/
            }

            //System.out.println("outputs: " + outputs.length + "; " + outputs[0].length);
            int check = this.performOneStep(outputs);

            if (check != 1) {
                return fitness / currentStep;
            }
        }
        return this.getFitness();
    }


    private int[] computeNormalisedOutputs(double[] netInputs,
                                           LayeredANN network) {

        double[] outputs = network.compute(netInputs);

        //normalise actuation values in [0, 127]
        int[] result = new int[outputs.length];
        for (int i = 0; i < outputs.length; i++) {
            result[i] = (int) (outputs[i] * 127);
        }
        return result;
    }

    private double[] normaliseSensorsValues(int[] is) {
        double[] values = new double[is.length];
        for (int i = 0; i < values.length; i++) {
            values[i] = (double) is[i] / 127;
        }
        return values;
    }

    private LayeredANN createCopyNet(LayeredANN network,
                                     ArrayList<ANNNeuron> originalNeurons,
                                     ArrayList<ANNSynapse> originalSynapses) {
        //first, copy all neurons and synapses, then put them in the right place
        HashMap<Long, ANNNeuron> copyNeurons = new HashMap<Long, ANNNeuron>();
        HashMap<Long, ANNSynapse> copySynapse = new HashMap<Long, ANNSynapse>();

        for (ANNNeuron neuron : originalNeurons) {
            copyNeurons.put(neuron.getId(), neuron.shallowCopy());
        }

        for (ANNSynapse synapse : originalSynapses) {
            copySynapse.put(synapse.getInnovationNumber(), synapse.copy());
        }

        ANNLayer[] copyLayers = new ANNLayer[network.getNumberOfLayers()];

        for (int i = 0; i < network.getNumberOfLayers(); i++) {
            ANNLayer originalLayer = network.getLayer(i);

            copyLayers[i] = recreateLayer(originalLayer, copyNeurons, copySynapse);
        }


        return new LayeredANN(copyLayers, network.getBiasFirst());
    }

    private ANNLayer recreateLayer(ANNLayer originalLayer,
                                   HashMap<Long, ANNNeuron> copyNeurons,
                                   HashMap<Long, ANNSynapse> copySynapses) {
        ArrayList<ANNNeuron> originalLayerNeurons = originalLayer.getNeurons();
        ArrayList<ANNNeuron> copyLayerNeurons = new ArrayList<ANNNeuron>(originalLayerNeurons.size());

        //start assembling the pieces
        for (ANNNeuron neuron : originalLayerNeurons) {
            //find the right *copy neuron*
            ANNNeuron copyNeuron = copyNeurons.get(neuron.getId());

            //Search for and add the incoming neurons and incoming connections
            //for each incoming synapse, there is a corresponding incoming neuron
            for (int i = 0; i < neuron.getIncomingConnections().size(); i++) {
                ANNSynapse originalIncSynapse = neuron.getIncomingConnections().get(i);
                ANNNeuron originalIncNeuron = neuron.getIncomingNeurons().get(i);

                //add to the copy neuron
                copyNeuron.addIncomingNeuron(copyNeurons.get(originalIncNeuron.getId()));
                copyNeuron.addIncomingSynapse(copySynapses.get(originalIncSynapse.getInnovationNumber()));
            }
            copyLayerNeurons.add(copyNeuron);
        }
        return new ANNLayer(originalLayer.getLayerId(), copyLayerNeurons);
    }


    public void initialPosition() {

        if (crabNum > 0)
            phi[0] = 0.8 * PI;
        if (crabNum > 1)
            phi[1] = 0.9 * PI;
        if (crabNum > 2)
            phi[2] = 1.0 * PI;
        if (crabNum > 3)
            phi[3] = 1.1 * PI;
        if (crabNum > 4)
            phi[4] = 1.2 * PI;

        if (crabNum > 0)
            x[0] = 0.0 + 0.25 * (-4.0) * (chainMin + chainMax);
        if (crabNum > 1)
            x[1] = 0.0 + 0.25 * (-2.0) * (chainMin + chainMax);
        if (crabNum > 2)
            x[2] = 0.0 + 0.25 * 0.0 * (chainMin + chainMax);
        if (crabNum > 3)
            x[3] = 0.0 + 0.25 * 2.0 * (chainMin + chainMax);
        if (crabNum > 4)
            x[4] = 0.0 + 0.25 * 4.0 * (chainMin + chainMax);

        for (int j = 0; j < crabNum; j++) {
            omega[j] = 0.0;
            v[j] = 0.0;
            u[j] = 0.0;
        }

        fitness = 0.0;
        currentStep = 0;
    }

    private double motor(double u, double v) {
        if (FastMath.abs(u - v) > deltaUV) {
            if (u > v) {
                if (v >= 0)
                    return Vmotor;
                else
                    return Vbreak;
            } else {
                // u<=v
                if (v >= 0)
                    return -Vbreak;
                else
                    return -Vmotor;
            }
        } else {
            // fabs(u-v)<=deltaUV
            if (u >= v) {
                if (v >= 0)
                    return Vmotor / deltaUV * (u - v);
                else
                    return Vbreak / deltaUV * (u - v);
            } else {
                // u<v
                if (v >= 0)
                    return Vbreak / deltaUV * (u - v);
                else
                    return Vmotor / deltaUV * (u - v);
            }
        }
    }

    private double changeAngularVel(double phi, double omega,
                                    double u, double v) {

        if (omega == 0.0)
            return 3.0 * g / (2.0 * length) * FastMath.sin(phi) - 3.0 / (2.0 * length) * motor(u, v) * FastMath.cos(phi);
        else
            return 3.0 * g / (2.0 * length) * FastMath.sin(phi) - 3.0 / (2.0 * length) * motor(u, v) * FastMath.cos(phi)
                    - Kp * omega * FastMath.abs(omega) - Kl * omega / FastMath.abs(omega);

    }

    private int checkForBorders() {
        for (int j = 0; j < crabNum; j++) {
            // no room to the right:
            if (j < crabNum - 1) {
                if ((FastMath.abs(x[j] - x[j + 1]) < chainMin)
                        && ((v[j] > 0.0) || (v[j] == 0.0 && u[j] > 0.0))) {
                    //printf("%d knocks over %d to the right. (%f)\n", j, j+1, fabs(x[j]-x[j+1]));
                    v[j] = 0.0;
                    return 0;
                }
            }
            if (j > 0) {
                if ((FastMath.abs(x[j] - x[j - 1]) > chainMax)
                        && ((v[j] > 0.0) || (v[j] == 0.0 && u[j] > 0.0))) {
                    v[j] = 0.0;
                    //printf("%d snaps the chain by going right. (%f)\n", j, fabs(x[j]-x[j-1]));
                    return 0;
                }
            }
            // no room to the left:
            if (j < crabNum - 1) {
                if ((FastMath.abs(x[j] - x[j + 1]) > chainMax)
                        && ((v[j] < 0.0) || (v[j] == 0.0 && u[j] < 0.0))) {
                    v[j] = 0.0;
                    //printf("%d snaps the chain by going left. (%f)\n", j, fabs(x[j]-x[j+1]));
                    return 0;
                }
            }
            if (j > 0) {
                if ((FastMath.abs(x[j] - x[j - 1]) < chainMin)
                        && ((v[j] < 0.0) || (v[j] == 0.0 && u[j] < 0.0))) {
                    v[j] = 0.0;
                    //printf("%d knocks over %d to the left. (%f)\n", j, j-1, fabs(x[j]-x[j-1]));
                    return 0;
                }
            }


            if (omega[j] > 5.0 * PI) {
                omega[j] = 5.0 * PI;
                return 0;
            }
            if (omega[j] < -5.0 * PI) {
                omega[j] = -5.0 * PI;
                return 0;
            }
            if (x[j] < -worldWidth / 2.0) {
                x[j] = -worldWidth / 2.0;
                v[j] = 0.0;
                return 0;
            }
            if (x[j] > worldWidth / 2.0) {
                x[j] = worldWidth / 2.0;
                v[j] = 0.0;
                return 0;
            }
            if (v[j] < -2.0) {
                v[j] = -2.0;
                return 0;
            }
            if (v[j] > 2.0) {
                v[j] = 2.0;
                return 0;
            }
        }
        return 1;
    }

    public int[][] getSensorValues() {
        int[][] sensorValues = new int[crabNum][10];
        double distLeft;
        double distRight;

        for (int i = 0; i < crabNum; i++) {

            distLeft = 1.0;
            distRight = 1.0;

            if (crabNum > 1) {
                if (i == 0)
                    distRight = FastMath.abs(x[0] - x[1]);
                else if (i == crabNum - 1)
                    distLeft = FastMath.abs(x[crabNum - 1] - x[crabNum - 2]);
                else {
                    distLeft = FastMath.abs(x[i] - x[i - 1]);
                    distRight = FastMath.abs(x[i] - x[i + 1]);
                }
            }

            while (phi[i] < 0.0)
                phi[i] += 2.0 * PI;
            while (phi[i] > 2.0 * PI)
                phi[i] -= 2.0 * PI;

            if (phi[i] < 0.5 * PI) {
                sensorValues[i][0] = 127 - (int) (127.0 * phi[i] / (0.5 * PI));
                sensorValues[i][1] = 0;
                sensorValues[i][2] = 0;
                sensorValues[i][3] = 0;
            } else if (phi[i] < PI) {
                sensorValues[i][0] = 0;
                sensorValues[i][1] = 0;
                sensorValues[i][2] = 127 - (int) (127.0 * (phi[i] - 0.5 * PI) / (0.5 * PI));
                sensorValues[i][3] = 0;
            } else if (phi[i] < 1.5 * PI) {
                sensorValues[i][0] = 0;
                sensorValues[i][1] = (int) (-127.0 * (PI - phi[i]) / (0.5 * PI));
                sensorValues[i][2] = 0;
                sensorValues[i][3] = 0;
            } else {
                sensorValues[i][0] = 0;
                sensorValues[i][1] = 0;
                sensorValues[i][2] = 0;
                sensorValues[i][3] = (int) (-127.0 * (1.5 * PI - phi[i]) / (0.5 * PI));
            }

            if (x[i] < 0.0) {
                if ((worldWidth / 4.0) + x[i] < distLeft)
                    sensorValues[i][4] = (int) (-1.0 * 127.0 * x[i] / (worldWidth / 2.0));
                else
                    sensorValues[i][4] = (int) (127.0 * distLeft / (worldWidth / 2.0));
                if (distRight < (worldWidth / 4.0)) {
                    sensorValues[i][5] = (int) (127.0 * distRight / (worldWidth / 2.0));
                } else {
                    sensorValues[i][5] = 0;
                }
            } else {
                if ((worldWidth / 4.0) - x[i] < distRight) {
                    sensorValues[i][5] = (int) (127.0 * x[i] / (worldWidth / 2.0));
                } else {
                    sensorValues[i][5] = (int) (127.0 * distRight / (worldWidth / 2.0));
                }
                if (distLeft < (worldWidth / 4.0))
                    sensorValues[i][4] = (int) (127.0 * distLeft / (worldWidth / 2.0));
                else
                    sensorValues[i][4] = 0;
            }
            if (v[i] < 0.0) {
                sensorValues[i][6] = (int) (-1.0 * 127.0 * v[i] / 2.0);
                sensorValues[i][7] = 0;
            } else {
                sensorValues[i][6] = 0;
                sensorValues[i][7] = (int) (127.0 * v[i] / 2.0);
            }
            if (omega[i] < 0.0) {
                sensorValues[i][8] = (int) (-1.0 * 127.0 * omega[i] / (5.0 * PI));
                sensorValues[i][9] = 0;
            } else {
                sensorValues[i][8] = 0;
                sensorValues[i][9] = (int) (127.0 * omega[i] / (5.0 * PI));
            }

            // noise:
			/*
		      for(int i=0;i<10;i++) {
		      sensorValues[i] += rand()%6 - 3;
		      if(sensorValues[i]<0)
		      sensorValues[i] = 0;
		      }
			 */
        }

        return sensorValues;
    }

    public double getFitness() {
        return fitness;
    }

    public int performOneStep(final int[][] motorControl) {

        double phiD1, phiD2, phiD3;
        double omegaD1, omegaD2, omegaD3;
        double vD1, vD2, vD3;
        double xD1, xD2, xD3;

        for (int j = 0; j < crabNum; j++) {


            double a1 = 0;
            double a2 = 0;

            try {
                a1 = (double) motorControl[j][0] / 127.0;
                a2 = (double) motorControl[j][1] / 127.0;
            } catch (ArrayIndexOutOfBoundsException e) {
                //System.exit(0);
            }


            u[j] = 2.0 * (a1 - a2);

            // runge-kutta:
            phiD1 = omega[j];
            xD1 = v[j];
            omegaD1 = changeAngularVel(phi[j], omega[j], u[j], v[j]);
            vD1 = motor(u[j], v[j]);
            omegaD2 = changeAngularVel(phi[j] + phiD1 * deltaT * 0.5,
                    omega[j] + omegaD1 * deltaT * 0.5,
                    u[j],
                    v[j] + vD1 * deltaT * 0.5);
            phiD2 = omega[j] + omegaD1 * deltaT * 0.5;
            xD2 = v[j] + vD1 * deltaT * 0.5;
            vD2 = motor(u[j], v[j] + vD1 * deltaT * 0.5);
            omegaD3 = changeAngularVel(phi[j] - phiD1 * deltaT + phiD2 * deltaT * 2.0,
                    omega[j] - omegaD1 * deltaT + omegaD2 * deltaT * 2.0,
                    u[j],
                    v[j] + vD1 * deltaT + vD2 * deltaT * 2.0);
            phiD3 = omega[j] - omegaD1 * deltaT + omegaD2 * deltaT * 2.0;
            xD3 = v[j] - vD1 * deltaT + vD2 * deltaT * 2.0;
            vD3 = motor(u[j], v[j] - vD1 * deltaT + vD2 * deltaT * 2.0);

            phi[j] += deltaT * (1.0 / 6.0 * phiD1 + 4.0 / 6.0 * phiD2 + 1.0 / 6.0 * phiD3);
            x[j] += deltaT * (1.0 / 6.0 * xD1 + 4.0 / 6.0 * xD2 + 1.0 / 6.0 * xD3);
            omega[j] += deltaT * (1.0 / 6.0 * omegaD1 + 4.0 / 6.0 * omegaD2 + 1.0 / 6.0 * omegaD3);
            v[j] += deltaT * (1.0 / 6.0 * vD1 + 4.0 / 6.0 * vD2 + 1.0 / 6.0 * vD3);


            fitness += FastMath.abs(phi[j] - PI) / (PI * crabNum * (double) stepsPerRun);
        } // for crab num

        currentStep++;
        return checkForBorders();
    }

    public double[][] getState() {

        double[][] state = new double[crabNum][5];

        for (int i = 0; i < crabNum; i++) {
            state[i][0] = u[i];
            state[i][1] = x[i];
            state[i][2] = phi[i];
            state[i][3] = omega[i];
            state[i][4] = v[i];
        }

        return state;
    }

    /**
     * void CoupledPendulums::writeTrajectoryToFile() {

     FILE *f;
     char filename[256];

     f = fopen("results.sim","w");
     fprintf(f, "number_of_cats        = %d\n", crabNum);
     fprintf(f, "pendulum_length       = %f\n", length);
     fprintf(f, "width_of_cat          = %f\n", chainMin);
     fprintf(f, "length_of_chain       = %f\n", chainMax-chainMin);
     fprintf(f, "width_of_half_world   = %f\n", worldWidth/2.0);
     fprintf(f, "info_text             = AHHS2\n");
     fclose(f);

     for(unsigned int i=0;i<crabNum;i++) {
     sprintf(filename, "out%d.txt", i);
     f = fopen(filename,"a");
     fprintf(f, "%d %e %e %e %e %e %e\n",
     currentStep, u[i], x[i], phi[i], omega[i], v[i], motor(u[i],v[i]));
     fclose(f);
     }
     }
     */


}
