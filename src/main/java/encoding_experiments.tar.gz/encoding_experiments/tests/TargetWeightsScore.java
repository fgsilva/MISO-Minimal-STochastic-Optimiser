package encoding_experiments.tests;

import encoding_experiments.layeredNets.ANNSynapse;
import encoding_experiments.layeredNets.LayeredANN;
import org.encog.ml.CalculateScore;
import org.encog.ml.MLMethod;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class TargetWeightsScore implements CalculateScore, Serializable {


    private double maximumWeightError;
    private int numberInputNeurons, numberOutputNeurons;
    private double[][] targetWeights;
    private Random random;

    public TargetWeightsScore(int[] inputs, int[] outputs,
                              double regularity, double maximumWeightError, Random random,
                              double absWeightRange) {
        this.maximumWeightError = maximumWeightError;
        this.numberInputNeurons = inputs.length;
        this.numberOutputNeurons = outputs.length;
        this.random = random;

        this.targetWeights = new double[numberInputNeurons][numberOutputNeurons];

        int totalWeights = this.numberInputNeurons * this.numberOutputNeurons;
        int linksToRepeat = regularity < 0.999 ? (int) (totalWeights * regularity) : totalWeights;
        ArrayList<Double> generatedWeights = new ArrayList<Double>(totalWeights);

        if (linksToRepeat == totalWeights) {
            double randomNumber = this.generateRandomNumber(-absWeightRange, absWeightRange);
            for (int i = 0; i < totalWeights; i++) {
                generatedWeights.add(randomNumber);
            }
        } else {
            int randomNumbers = totalWeights - linksToRepeat;
            //the random numbers
            for (int i = 0; i < randomNumbers; i++) {
                generatedWeights.add(this.generateRandomNumber(-absWeightRange, absWeightRange));
            }
            //now the value that repeats
            if (linksToRepeat > 0) {
                double randomNumber = this.generateRandomNumber(-absWeightRange, absWeightRange);
                for (int i = randomNumbers; i < totalWeights; i++) {
                    generatedWeights.add(randomNumber);
                }
            }
            //shuffle
            Collections.shuffle(generatedWeights);
        }
        if (generatedWeights.size() != totalWeights) {
            System.out.println(generatedWeights.size() + " instead of " + totalWeights);
            System.exit(0);
        }
        int index = 0;
        for (int i = 0; i < targetWeights.length; i++) {
            for (int j = 0; j < targetWeights[i].length; j++) {
                targetWeights[i][j] = generatedWeights.get(index);
                index++;
            }
        }
    }


    private double generateRandomNumber(double min, double max) {
        double randomNumber = random.nextDouble() * (max - min) + min;
        return randomNumber;
    }


    @Override
    public boolean shouldMinimize() {
        return false;
    }

    @Override
    public boolean requireSingleThreaded() {
        return true;
    }

    @Override
    public double calculateScore(MLMethod phenotype) {
        //System.out.println("calc score.");
        LayeredANN net = (LayeredANN) phenotype;
        double proximityTarget = 0, fitness;
        ArrayList<ANNSynapse> links = net.getAllSynapses();

        //NEATLink[] links = net.getLinks();

        int biasId = 0;
        double[][] currentWeights = new double[this.numberInputNeurons][this.numberOutputNeurons];
        for (ANNSynapse link : links) {
            // bias not used here
            if (link.getFromNeuron() != biasId && link.getToNeuron() != biasId) {
                int input = (int) (link.getFromNeuron() - 1);
                int output = (int) (link.getToNeuron() - this.numberInputNeurons - 1);
                try {
                    currentWeights[input][output] = link.getWeight();
                } catch (Exception e) {
                    System.out.println("\n" + input + " ; " + output);
                    e.printStackTrace();
                    System.exit(0);
                }
            }
        }

        for (int in = 0; in < this.targetWeights.length; in++) {
            for (int out = 0; out < this.targetWeights[in].length; out++) {
                proximityTarget += this.maximumWeightError - Math.abs(currentWeights[in][out] - targetWeights[in][out]);
            }
        }

        //mean value
        proximityTarget /= (this.targetWeights.length * this.targetWeights[0].length);

        fitness = Math.pow(2, proximityTarget);
        //System.out.println("end of calc score.");
        return fitness;
    }

}
