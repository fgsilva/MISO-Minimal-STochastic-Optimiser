package encoding_experiments.tests;

import org.encog.ml.CalculateScore;
import org.encog.ml.MLMethod;
import org.encog.ml.data.MLData;
import org.encog.ml.data.basic.BasicMLData;
import org.encog.neural.neat.NEATNetwork;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Random;


public class BitMirroringScore implements CalculateScore, Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 1L;
    private final int samples = 10;
    private HashMap<Integer, Integer> pairing;
    private Random random;

    public BitMirroringScore(HashMap<Integer, Integer> pairing,
                             Random random) {
        this.pairing = pairing;
        this.random = random;
    }

    @Override
    public double calculateScore(MLMethod phenotype) {
        NEATNetwork net = (NEATNetwork) phenotype;
        double[][] inputs = generateInputs();

        double[][] targetOutputs = computeTargetOutputs(inputs);
        double fitness = 0;
        MLData inputData = new BasicMLData(this.pairing.size());
        for (int i = 0; i < inputs.length; i++) {
            inputData.setData(inputs[i]);
            double[] result = net.compute(inputData).getData();
            double[] targetResult = targetOutputs[i];
            for (int out = 0; out < result.length; out++) {
                if ((targetResult[out] > 0 && result[out] > 0)
                        || (targetResult[out] <= 0 && result[out] <= 0))
                    fitness++;
            }
        }

        return fitness;
    }


    private double[][] computeTargetOutputs(double[][] inputs) {
        double[][] targets = new double[inputs.length][];
        for (int i = 0; i < inputs.length; i++) {
            targets[i] = computeTargetOutputForInput(inputs[i]);
        }

        return targets;
    }

    private double[] computeTargetOutputForInput(double[] input) {
        double[] output = new double[input.length];
        for (int i = 0; i < input.length; i++) {
            int fromNode = i + 1;
            int toNode = this.pairing.get(fromNode);
            int toNodeIndex = toNode - input.length - 1;

            output[toNodeIndex] = input[i] > 0.0 ? 1.0 : -1.0;
            //System.out.println("f: " + fromNode + "(" + input[i] + " ) => " + toNode + "(" + output[i] + " )");
        }

        //System.exit(0);
        return output;
    }

    private double[][] generateInputs() {
        double[][] inputs = new double[samples][];

        for (int i = 0; i < samples; i++) {
            inputs[i] = generateRandomInput();
        }

        //check for repeated sets
        boolean repeated = true;
        while (repeated) {
            boolean repetitionFound = false;
            for (int i = 0; i < inputs.length; i++) {
                for (int j = i + 1; j < inputs.length; j++) {
                    if (areEqualVectors(inputs[i], inputs[j])) {
                        inputs[j] = this.generateRandomInput();
                        repetitionFound = true;
                    }
                }
            }
            if (!repetitionFound)
                repeated = false;
        }
        return inputs;
    }

    private boolean areEqualVectors(double[] v1, double[] v2) {
        for (int i = 0; i < v1.length; i++) {
            if ((v1[i] <= 0 && v2[i] > 0) || (v1[i] > 0 && v2[i] <= 0))
                return false;
        }
        return true;
    }

    private double[] generateRandomInput() {
        double[] result = new double[this.pairing.size()];

        for (int i = 0; i < result.length; i++) {
            if (random.nextBoolean())
                result[i] = 1;
            else
                result[i] = -1;
        }
        return result;
    }

    @Override
    public boolean requireSingleThreaded() {
        return true;
    }

    @Override
    public boolean shouldMinimize() {
        return false;
    }

}
