package encoding_experiments.tests;

import encoding_experiments.EvolutionEngine;

import java.io.IOException;

public class RunPendulum {

    public static void main(String[] args) throws IOException {
        long time = System.currentTimeMillis() / 1000;


        /****** hybrid 5 hidden **********/
        String hybridPendulum5hidden = "neatConfs/hybrid_inverted_pendulum_5hidden_noaugment.conf";
        time = System.currentTimeMillis() / 1000;
        System.out.println(hybridPendulum5hidden);
        EvolutionEngine.main(new String[]{hybridPendulum5hidden});
        System.out.println("TIME: " + (System.currentTimeMillis() / 1000 - time) + " seconds");
        Runtime.getRuntime().gc();

        /****** hybrid 10 hidden **********/
        String hybridPendulum10hidden = "neatConfs/hybrid_inverted_pendulum_10hidden_noaugment.conf";
        time = System.currentTimeMillis() / 1000;
        System.out.println(hybridPendulum10hidden);
        EvolutionEngine.main(new String[]{hybridPendulum10hidden});
        System.out.println("TIME: " + (System.currentTimeMillis() / 1000 - time) + " seconds");
        Runtime.getRuntime().gc();

        /***
         * regular again
         */

        /****** hybrid 5 hidden **********/
        hybridPendulum5hidden = "neatConfs/hybrid_inverted_pendulum_5hidden.conf";
        time = System.currentTimeMillis() / 1000;
        System.out.println(hybridPendulum5hidden);
        EvolutionEngine.main(new String[]{hybridPendulum5hidden});
        System.out.println("TIME: " + (System.currentTimeMillis() / 1000 - time) + " seconds");
        Runtime.getRuntime().gc();

        /****** hybrid 10 hidden **********/
        hybridPendulum10hidden = "neatConfs/hybrid_inverted_pendulum_10hidden.conf";
        time = System.currentTimeMillis() / 1000;
        System.out.println(hybridPendulum10hidden);
        EvolutionEngine.main(new String[]{hybridPendulum10hidden});
        System.out.println("TIME: " + (System.currentTimeMillis() / 1000 - time) + " seconds");
        Runtime.getRuntime().gc();
    }
}
