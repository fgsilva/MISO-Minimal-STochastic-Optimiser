package encoding_experiments.coevolve;

import java.util.Collection;
import java.util.TreeMap;

public class WeightsCorrespondence {

    //from, to , weight
    private TreeMap<Long, TreeMap<Long, Double>> correspondence;

    public WeightsCorrespondence() {
        this.correspondence = new TreeMap<Long, TreeMap<Long, Double>>();
    }

    public void clear() {
        Collection<TreeMap<Long, Double>> maps = correspondence.values();
        for (TreeMap<Long, Double> map : maps)
            map.clear();

        correspondence.clear();
    }

    public void putInfo(long fromNeuronID, long toNeuronID, double weight) {
        if (correspondence.containsKey(fromNeuronID)) {
            correspondence.get(fromNeuronID).put(toNeuronID, weight);
        } else {
            TreeMap<Long, Double> map = new TreeMap<Long, Double>();
            map.put(toNeuronID, weight);
            correspondence.put(fromNeuronID, map);
        }
    }

    public double getWeight(long fromNeuronID, long toNeuronID) {
        TreeMap<Long, Double> map = correspondence.get(fromNeuronID);
        if (map == null || !map.containsKey(toNeuronID))
            return 0;

        return map.get(toNeuronID);
    }

    public boolean containsConnection(long fromNeuronID, long toNeuronID) {
        TreeMap<Long, Double> map = correspondence.get(fromNeuronID);
        if (map == null || !map.containsKey(toNeuronID))
            return false;

        return true;
    }

}
