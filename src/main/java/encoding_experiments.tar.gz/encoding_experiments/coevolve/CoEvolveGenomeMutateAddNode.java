package encoding_experiments.coevolve;

import org.encog.engine.network.activation.ActivationFunction;
import org.encog.mathutil.randomize.RangeRandomizer;
import org.encog.ml.ea.genome.Genome;
import org.encog.neural.neat.NEATNeuronType;
import org.encog.neural.neat.NEATPopulation;
import org.encog.neural.neat.training.NEATGenome;
import org.encog.neural.neat.training.NEATInnovation;
import org.encog.neural.neat.training.NEATLinkGene;
import org.encog.neural.neat.training.NEATNeuronGene;
import org.encog.neural.neat.training.opp.NEATMutation;

import java.util.Random;

public class CoEvolveGenomeMutateAddNode extends NEATMutation {

    /**
     * {@inheritDoc}
     */
    @Override
    public void performOperation(final Random rnd, final Genome[] parents,
                                 final int parentIndex, final Genome[] offspring,
                                 final int offspringIndex) {
        CoEvolveEquiInitGenome genome = (CoEvolveEquiInitGenome) obtainGenome(parents, parentIndex, offspring,
                offspringIndex);

        NEATPopulation pop = (NEATPopulation) genome.getPopulation();

        if (genome.getDirectLinksExpressed()) {
            NEATGenome directGenome = (NEATGenome) genome.getDirectGenome();
            this.applyMutation(directGenome, false, pop);
        }

        if (genome.getIndirectLinksExpressed()) {
            this.applyMutation(genome, true, pop);
        }
        offspring[offspringIndex] = genome;
    }

    public void applyMutation(NEATGenome target, boolean anyFunction, NEATPopulation pop) {
        int countTrysToFindOldLink = getOwner().getMaxTries();

        //final NEATPopulation pop = ((NEATPopulation) target.getPopulation());

        // the link to split
        NEATLinkGene splitLink = null;

        final int sizeBias = ((NEATGenome) target).getInputCount()
                + ((NEATGenome) target).getOutputCount() + 10;

        // if there are not at least
        int upperLimit;
        if (target.getLinksChromosome().size() < sizeBias) {
            upperLimit = target.getNumGenes() - 1
                    - (int) Math.sqrt(target.getNumGenes());
        } else {
            upperLimit = target.getNumGenes() - 1;
        }

        while ((countTrysToFindOldLink--) > 0) {
            // choose a link, use the square root to prefer the older links
            final int i = RangeRandomizer.randomInt(0, upperLimit);
            final NEATLinkGene link = target.getLinksChromosome().get(i);

            // get the from neuron
            final long fromNeuron = link.getFromNeuronID();

            if ((link.isEnabled())
                    && (target.getNeuronsChromosome()
                    .get(getElementPos(target, fromNeuron))
                    .getNeuronType() != NEATNeuronType.Bias)) {
                splitLink = link;
                break;
            }
        }

        if (splitLink == null) {
            return;
        }

        splitLink.setEnabled(false);

        final long from = splitLink.getFromNeuronID();
        final long to = splitLink.getToNeuronID();

        final NEATInnovation innovation = pop.getInnovations()
                .findInnovationSplit(from, to);

        // add the splitting neuron
        final ActivationFunction af;
        if (anyFunction) {
            af = pop.getActivationFunctions().pick(new Random());
        } else {
            //does not really matter, just to avoid potential null pointer exceptions
            af = pop.getActivationFunctions().pickFirst();
        }

        target.getNeuronsChromosome().add(
                new NEATNeuronGene(NEATNeuronType.Hidden, af, innovation
                        .getNeuronID(), innovation.getInnovationID()));

        // add the other two sides of the link
        this.createLink(target, from, innovation.getNeuronID(),
                splitLink.getWeight(), pop);
        this.createLink(target, innovation.getNeuronID(), to, pop.getWeightRange(), pop);

        target.sortGenes();
    }

    /**
     * Create a link between two neuron id's. Create or find any necessary
     * innovation records.
     *
     * @param target    The target genome.
     * @param neuron1ID The id of the source neuron.
     * @param neuron2ID The id of the target neuron.
     * @param weight    The weight of this new link.
     */
    public void createLink(final NEATGenome target, final long neuron1ID,
                           final long neuron2ID, final double weight, NEATPopulation pop) {

        // first, does this link exist? (and if so, hopefully disabled,
        // otherwise we have a problem)
        for (final NEATLinkGene linkGene : target.getLinksChromosome()) {
            if ((linkGene.getFromNeuronID() == neuron1ID)
                    && (linkGene.getToNeuronID() == neuron2ID)) {
                // bring the link back, at the new weight
                linkGene.setEnabled(true);
                linkGene.setWeight(weight);
                return;
            }
        }

        // check to see if this innovation has already been tried
        final NEATInnovation innovation = pop.getInnovations().findInnovation(neuron1ID,
                neuron2ID);

        // now create this link
        final NEATLinkGene linkGene = new NEATLinkGene(neuron1ID, neuron2ID,
                true, innovation.getInnovationID(), weight);
        target.getLinksChromosome().add(linkGene);
    }

}
