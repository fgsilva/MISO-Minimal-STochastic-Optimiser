package encoding_experiments.coevolve;

import org.encog.engine.network.activation.ActivationFunction;
import org.encog.engine.network.activation.ActivationSteepenedSigmoid;
import org.encog.mathutil.randomize.RangeRandomizer;
import org.encog.neural.hyperneat.HyperNEATGenome;
import org.encog.neural.neat.NEATNeuronType;
import org.encog.neural.neat.NEATPopulation;
import org.encog.neural.neat.training.NEATGenome;
import org.encog.neural.neat.training.NEATLinkGene;
import org.encog.neural.neat.training.NEATNeuronGene;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class CoEvolveEquiInitGenome extends HyperNEATGenome {

    private static int ANN_INPUT_COUNT, ANN_OUTPUT_COUNT;
    private static boolean USE_BIAS;

    /**
     * @return the annInputCount
     */
    public synchronized static int getAnnInputCount() {
        return ANN_INPUT_COUNT;
    }

    /**
     * @return the annOutputCount
     */
    public synchronized static int getAnnOutputCount() {
        return ANN_OUTPUT_COUNT;
    }

    public NEATGenome getDirectGenome() {
        return this.directGenome;
    }

    /**
     */
    public static void setAnnInputCount(int annInputCount) {
        ANN_INPUT_COUNT = annInputCount;
    }

    /**
     */
    public static void setAnnOutputCount(int setAnnOutputCount) {
        ANN_OUTPUT_COUNT = setAnnOutputCount;
    }

    public static void setUseBias(boolean useBias) {
        USE_BIAS = useBias;
    }


    /**
     * Serial id.
     */
    private static final long serialVersionUID = 1L;


    //directly encoded genome
    private NEATGenome directGenome;

    private boolean useIndirect, useDirect;

    public CoEvolveEquiInitGenome(CoEvolveEquiInitGenome other) {
        super(other);

        if (other.getDirectGenome() != null)
            this.directGenome = new NEATGenome(other.getDirectGenome());
        this.useDirect = other.useDirect;
        this.useIndirect = other.useIndirect;
    }

    public CoEvolveEquiInitGenome(Random rnd, NEATPopulation pop,
                                  int inputCount, int outputCount, double connectionDensity) {
        super(rnd, pop, inputCount, outputCount, connectionDensity);
        /**
         * initialization
         */
        double value = rnd.nextDouble();
        //start only indirect
        if (value < 0.333) {
            this.useDirect = false;
            this.useIndirect = true;
        }
        //only direct
        else if (value < 0.667) {
            this.useDirect = true;
            this.useIndirect = false;
        }
        //both
        else {
            this.useDirect = true;
            this.useIndirect = true;
        }

        //NOTE: always have the direct, even if not used.
        //if(this.useDirect){
        this.directGenome = loadDirectGenome(rnd, pop, USE_BIAS);
        //this.directGenome.setPopulation(this.getPopulation());
        //}
    }

    public CoEvolveEquiInitGenome(List<NEATNeuronGene> neurons,
                                  List<NEATLinkGene> links, int inputCount, int outputCount) {
        super(neurons, links, inputCount, outputCount);
    }

    public void setDirectGenome(NEATGenome direct) {
        this.directGenome = direct;
    }

    public void setUseDirect(boolean useDirect) {
        this.useDirect = useDirect;
    }

    public void setUseIndirect(boolean useIndirect) {
        this.useIndirect = useIndirect;
    }

    private NEATGenome loadDirectGenome(Random rnd, NEATPopulation pop, boolean useBias) {
        int inputCount = ANN_INPUT_COUNT, outputCount = ANN_OUTPUT_COUNT;
        //MARK 21/9/2014: ENXERTO
        ActivationFunction af = new ActivationSteepenedSigmoid();
        ArrayList<NEATNeuronGene> neuronsList = new ArrayList<NEATNeuronGene>();
        ArrayList<NEATLinkGene> linksList = new ArrayList<NEATLinkGene>();

        // first bias
        int innovationID = 0;
        NEATNeuronGene biasGene = new NEATNeuronGene(NEATNeuronType.Bias, af,
                0, innovationID++);
        neuronsList.add(biasGene);

        // then inputs
        for (int i = 0; i < inputCount; i++) {
            NEATNeuronGene gene = new NEATNeuronGene(NEATNeuronType.Input, af,
                    i + 1, innovationID++);
            neuronsList.add(gene);
        }

        // then outputs
        for (int i = 0; i < outputCount; i++) {
            NEATNeuronGene gene = new NEATNeuronGene(NEATNeuronType.Output, af,
                    i + inputCount + 1, innovationID++);
            neuronsList.add(gene);
        }

        //TODO: this could be changed.
        /*double probEnabledDirect;
        double probChoosing = rnd.nextDouble();
		if(probChoosing < 0.33333){
			probEnabledDirect = 0;
		}
		else if(probChoosing < 0.666667){
			probEnabledDirect = 1.0;
		}
		else 
			probEnabledDirect = rnd.nextDouble(); */
        double probEnabledDirect = rnd.nextDouble();

        // and now links
        for (int i = 0; i < inputCount + 1; i++) {
            for (int j = 0; j < outputCount; j++) {
                long fromID = neuronsList.get(i).getId();
                //do not add bias-related links if not supposed to.
                if (useBias || (!useBias && fromID != 0)) {
                    long toID = neuronsList.get(inputCount + j + 1).getId();
                    double w = RangeRandomizer.randomize(rnd,
                            -pop.getWeightRange(), pop.getWeightRange());

                    boolean status;
                    //only direct.
                    if (this.useIndirect && !this.useDirect)
                        status = false;
                    else
                        status = !this.useIndirect ? true : rnd.nextDouble() < probEnabledDirect;

                    NEATLinkGene gene = new NEATLinkGene(fromID, toID, status, innovationID++, w);

                    linksList.add(gene);
                }
            }
        }

        return new NEATGenome(neuronsList, linksList, inputCount, outputCount);
    }

    public boolean getDirectLinksExpressed() {
        return this.useDirect;
    }

    public boolean getIndirectLinksExpressed() {
        return this.useIndirect;
    }

    public int getDirectExpressedLinksCount() {
        int count = 0;
        if (!this.useDirect)
            return 0;

        for (NEATLinkGene link : this.directGenome.getLinksChromosome())
            if (link.isEnabled())
                count++;
        return count;
    }
}


