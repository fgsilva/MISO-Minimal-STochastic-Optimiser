package encoding_experiments.coevolve;

import org.encog.ml.ea.genome.Genome;
import org.encog.ml.ea.train.EvolutionaryAlgorithm;
import org.encog.neural.neat.NEATGenomeFactory;
import org.encog.neural.neat.training.NEATGenome;
import org.encog.neural.neat.training.NEATLinkGene;
import org.encog.neural.neat.training.NEATNeuronGene;
import org.encog.neural.neat.training.opp.NEATCrossover;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class CoEvolveGenomeCrossover extends NEATCrossover {

    /**
     * The owning object.
     */
    private EvolutionaryAlgorithm owner;

    /**
     * Init this operator. This allows the EA to be defined.
     */
    @Override
    public void init(final EvolutionaryAlgorithm theOwner) {
        super.init(theOwner);
        this.owner = theOwner;
    }

    @Override
    public void performOperation(final Random rnd, final Genome[] parents,
                                 final int parentIndex, final Genome[] offspring,
                                 final int offspringIndex) {
        if (parents[parentIndex] instanceof CoEvolveEquiInitGenome) {
            CoEvolveEquiInitGenome p1 = (CoEvolveEquiInitGenome) parents[parentIndex],
                    p2 = (CoEvolveEquiInitGenome) parents[parentIndex + 1];

            CoEvolveEquiInitGenome fittest = p1.getScore() >= p2.getScore() ? p1 : p2;

            //indirect
            CoEvolveEquiInitGenome newIndirect = (CoEvolveEquiInitGenome) performCrossover(p1, p2);
            //direct
            NEATGenome newDirect;
            if (p1.getDirectLinksExpressed() && p2.getDirectLinksExpressed()) {
                NEATGenome d1 = p1.getDirectGenome(), d2 = p2.getDirectGenome();

                /** to avoid problems in crossover **/
                d1.setScore(p1.getScore());
                d1.setAdjustedScore(p1.getAdjustedScore());
                d2.setScore(p2.getScore());
                d2.setScore(p2.getAdjustedScore());

                newDirect = performCrossover(d1, d2);
            } else {
                /*newDirect = fittest.getDirectLinksExpressed() ?
                        new NEATGenome(fittest.getDirectGenome()) : null;*/
                newDirect = new NEATGenome(fittest.getDirectGenome());
            }

            if (newDirect != null) {
                newDirect.setPopulation(p1.getPopulation());

            }

            newIndirect.setDirectGenome(newDirect);
            boolean useDirect = fittest.getDirectLinksExpressed();
            boolean useIndirect = fittest.getIndirectLinksExpressed();

            newIndirect.setUseDirect(useDirect);
            newIndirect.setUseIndirect(useIndirect);

            offspring[offspringIndex] = newIndirect;

        } /*else if(parents[parentIndex] instanceof CoEvolvingHybridGenome){
			CoEvolvingHybridGenome p1 = (CoEvolvingHybridGenome) parents[parentIndex], 
					p2 = (CoEvolvingHybridGenome) parents[parentIndex + 1];
			NEATGenome d1 = p1.getDirectGenome(), d2 = p2.getDirectGenome();

			/** to avoid problems in crossover **/
			/*d1.setScore(p1.getScore());
			d1.setAdjustedScore(p1.getAdjustedScore());
			d2.setScore(p2.getScore());
			d2.setScore(p2.getAdjustedScore());

			NEATGenome newDirect = performCrossover(d1, d2);
			CoEvolvingHybridGenome newIndirect = (CoEvolvingHybridGenome) performCrossover(p1, p2);
			newIndirect.setDirectGenome(newDirect);

			boolean useDirect = p1.getScore() >= p2.getScore() ? p1.getDirectLinksExpressed() : p2.getDirectLinksExpressed();
			boolean useIndirect = p1.getScore() >= p2.getScore() ? p1.getIndirectLinksExpressed() : p2.getIndirectLinksExpressed();

			newIndirect.setUseDirect(useDirect);
			newIndirect.setUseIndirect(useIndirect);

			offspring[offspringIndex] = newIndirect;
		}
		else if(parents[parentIndex] instanceof CoEvolvingIncrementalGenome){
			CoEvolvingIncrementalGenome p1 = (CoEvolvingIncrementalGenome) parents[parentIndex], 
					p2 = (CoEvolvingIncrementalGenome) parents[parentIndex + 1];
			CoEvolvingIncrementalGenome newIndirect = (CoEvolvingIncrementalGenome) performCrossover(p1, p2);

			//one-point crossover
			int crossoverPoint = rnd.nextInt(p1.getDirectConnectionsToIndex().size());
			double[] newWeights = p1.getConnectionWeights().clone();
			boolean[] newEnabledStatus = p1.getIsConnectionEnabled().clone();


			for(int i = crossoverPoint; i < newWeights.length; i++){
				newWeights[i] = p2.getConnectionWeights()[i];
				newEnabledStatus[i] = p2.getIsConnectionEnabled()[i];
			}

			//from the fittest
			/*double[] newWeights = p1.getScore() >= p2.getScore() ? p1.getConnectionWeights().clone() : p2.getConnectionWeights().clone();
			boolean[] newEnabledStatus = p1.getScore() >= p2.getScore() ? p1.getIsConnectionEnabled().clone() : p2.getIsConnectionEnabled().clone();
			 */

			/*newIndirect.setDirectGenome(p1.getDirectConnectionsToIndex(), newEnabledStatus, newWeights);

			offspring[offspringIndex] = newIndirect;

		}*/
        else {
            try {
                throw new Exception("unknown genome @ crossover");
            } catch (Exception e) {
                e.printStackTrace();
                System.exit(0);
            }
        }

    }

    private NEATGenome performCrossover(NEATGenome mom, NEATGenome dad) {
        final NEATGenome best = favorParent(mom, dad);
        final NEATGenome notBest = (best == mom) ? mom : dad;

        final List<NEATLinkGene> selectedLinks = new ArrayList<NEATLinkGene>();
        final List<NEATNeuronGene> selectedNeurons = new ArrayList<NEATNeuronGene>();

        int curMom = 0; // current gene index from mom
        int curDad = 0; // current gene index from dad
        NEATLinkGene selectedGene = null;

        // add in the input and bias, they should always be here
        final int alwaysCount = ((NEATGenome) mom).getInputCount()
                + ((NEATGenome) mom).getOutputCount() + 1;
        for (int i = 0; i < alwaysCount; i++) {
            addNeuronID(i, selectedNeurons, best, notBest);
        }

        while ((curMom < mom.getNumGenes()) || (curDad < dad.getNumGenes())) {
            NEATLinkGene momGene = null; // the mom gene object
            NEATLinkGene dadGene = null; // the dad gene object
            long momInnovation = -1;
            long dadInnovation = -1;

            // grab the actual objects from mom and dad for the specified
            // indexes
            // if there are none, then null
            if (curMom < mom.getNumGenes()) {
                momGene = mom.getLinksChromosome().get(curMom);
                momInnovation = momGene.getInnovationId();
            }

            if (curDad < dad.getNumGenes()) {
                dadGene = dad.getLinksChromosome().get(curDad);
                dadInnovation = dadGene.getInnovationId();
            }

            // now select a gene for mom or dad. This gene is for the baby
            if ((momGene == null) && (dadGene != null)) {
                if (best == dad) {
                    selectedGene = dadGene;
                }
                curDad++;
            } else if ((dadGene == null) && (momGene != null)) {
                if (best == mom) {
                    selectedGene = momGene;
                }
                curMom++;
            } else if (momInnovation < dadInnovation) {
                if (best == mom) {
                    selectedGene = momGene;
                }
                curMom++;
            } else if (dadInnovation < momInnovation) {
                if (best == dad) {
                    selectedGene = dadGene;
                }
                curDad++;
            } else if (dadInnovation == momInnovation) {
                if (Math.random() < 0.5f) {
                    selectedGene = momGene;
                } else {
                    selectedGene = dadGene;
                }
                curMom++;
                curDad++;
            }

            if (selectedGene != null) {
                if (selectedLinks.size() == 0) {
                    selectedLinks.add(selectedGene);
                } else {
                    if (selectedLinks.get(selectedLinks.size() - 1)
                            .getInnovationId() != selectedGene
                            .getInnovationId()) {
                        selectedLinks.add(selectedGene);
                    }
                }

                // Check if we already have the nodes referred to in
                // SelectedGene.
                // If not, they need to be added.
                addNeuronID(selectedGene.getFromNeuronID(), selectedNeurons,
                        best, notBest);
                addNeuronID(selectedGene.getToNeuronID(), selectedNeurons,
                        best, notBest);
            }

        }

        // now create the required nodes. First sort them into order
        Collections.sort(selectedNeurons);

        // finally, create the genome
        final NEATGenomeFactory factory = (NEATGenomeFactory) this.owner
                .getPopulation().getGenomeFactory();
        final NEATGenome babyGenome = factory.factor(selectedNeurons,
                selectedLinks, mom.getInputCount(), mom.getOutputCount());
        babyGenome.setBirthGeneration(this.owner.getIteration());
        babyGenome.setPopulation(this.owner.getPopulation());
        babyGenome.sortGenes();

        return babyGenome;
    }

    /**
     * Choose a parent to favor.
     *
     * @param mom The mother.
     * @param dad The father.
     * @return The parent to favor.
     */
    protected NEATGenome favorParent(final NEATGenome mom, final NEATGenome dad) {

        // first determine who is more fit, the mother or the father?
        // see if mom and dad are the same fitness
        if (mom.getScore() == dad.getScore()) {
            // are mom and dad the same fitness
            if (mom.getNumGenes() == dad.getNumGenes()) {
                // if mom and dad are the same fitness and have the same number
                // of genes,
                // then randomly pick mom or dad as the most fit.
                if (Math.random() > 0) {
                    return mom;
                } else {
                    return dad;
                }
            }
            // mom and dad are the same fitness, but different number of genes
            // favor the parent with fewer genes
            else {
                if (mom.getNumGenes() < dad.getNumGenes()) {
                    return mom;
                } else {
                    return dad;
                }
            }
        } else {
            // mom and dad have different scores, so choose the better score.
            // important to note, better score COULD BE the larger or smaller
            // score.
            if (this.owner.getSelectionComparator().compare(mom, dad) < 0) {
                return mom;
            } else {
                return dad;
            }
        }

    }

}
