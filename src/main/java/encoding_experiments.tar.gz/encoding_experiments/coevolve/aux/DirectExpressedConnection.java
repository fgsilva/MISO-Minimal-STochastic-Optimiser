package encoding_experiments.coevolve.aux;

public class DirectExpressedConnection {

    private int fromId, toId;

    public DirectExpressedConnection(int from, int to) {
        this.fromId = from;
        this.toId = to;
    }

    /**
     * @return the fromId
     */
    public int getFromId() {
        return fromId;
    }

    /**
     * @return the toId
     */
    public int getToId() {
        return toId;
    }


    /**
     * @param fromId the fromId to set
     */
    public void setFromId(int fromId) {
        this.fromId = fromId;
    }

    /**
     * @param toId the toId to set
     */
    public void setToId(int toId) {
        this.toId = toId;
    }


    /* (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + fromId;
        result = prime * result + toId;
        return result;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        DirectExpressedConnection other = (DirectExpressedConnection) obj;
        if (fromId != other.fromId)
            return false;
        if (toId != other.toId)
            return false;
        return true;
    }

    public DirectExpressedConnection copy() {
        return new DirectExpressedConnection(this.fromId, this.toId);
    }


}
