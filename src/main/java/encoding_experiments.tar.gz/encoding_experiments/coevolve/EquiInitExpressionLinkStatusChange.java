package encoding_experiments.coevolve;

import org.encog.ml.ea.genome.Genome;
import org.encog.neural.neat.training.NEATGenome;
import org.encog.neural.neat.training.NEATLinkGene;
import org.encog.neural.neat.training.opp.NEATMutation;

import java.util.List;
import java.util.Random;


public class EquiInitExpressionLinkStatusChange extends NEATMutation {

    private final double probLinkChange = 0.01;//, probResetValue = 0.01;
    private final double probChangeIndirect = 0.05, probChangeDirect = 0.05;

    @Override
    public void performOperation(final Random rnd, final Genome[] parents,
                                 final int parentIndex, final Genome[] offspring,
                                 final int offspringIndex) {
        final NEATGenome target = obtainGenome(parents, parentIndex, offspring,
                offspringIndex);

        CoEvolveEquiInitGenome hybrid = (CoEvolveEquiInitGenome) target;
        NEATGenome direct = hybrid.getDirectGenome();

        //change what is expressed
        boolean changedInd = false, changedDir = false;
        if (rnd.nextDouble() < probChangeIndirect) {
            changedInd = true;
            hybrid.setUseIndirect(!hybrid.getIndirectLinksExpressed());
        } else if (rnd.nextDouble() < probChangeDirect) {
            changedDir = true;
            hybrid.setUseDirect(!hybrid.getDirectLinksExpressed());
        }

        //nothing is expressed
        if (!hybrid.getDirectLinksExpressed() && !hybrid.getIndirectLinksExpressed()) {
            if (changedInd)
                hybrid.setUseIndirect(true);
            if (changedDir)
                hybrid.setUseDirect(true);
        }

        //change direct expressed weight values
        if (hybrid.getDirectLinksExpressed() && hybrid.getIndirectLinksExpressed()) {
            try {
                this.applyMutation(direct.getLinksChromosome(), rnd);
            } catch (Exception e) {
                if (direct == null) {
                    System.out.println("direct null");
                }
                if (direct.getLinksChromosome() == null) {
                    System.out.println("links direct null");
                }
                if (rnd == null) {
                    System.out.println("rnd null");
                }
            }
        }
        offspring[offspringIndex] = hybrid;
    }

    private void applyMutation(List<NEATLinkGene> links, Random rnd) {
        //double weightRange = ((NEATPopulation) this.getOwner().getPopulation()).getWeightRange();
        for (NEATLinkGene link : links) {
            if (rnd.nextDouble() < this.probLinkChange) {
                link.setEnabled(!link.isEnabled());
            }
        }
    }
}

