package encoding_experiments.coevolve;

import org.encog.mathutil.randomize.RangeRandomizer;
import org.encog.ml.ea.genome.Genome;
import org.encog.neural.neat.NEATNeuronType;
import org.encog.neural.neat.NEATPopulation;
import org.encog.neural.neat.training.NEATGenome;
import org.encog.neural.neat.training.NEATInnovation;
import org.encog.neural.neat.training.NEATLinkGene;
import org.encog.neural.neat.training.NEATNeuronGene;
import org.encog.neural.neat.training.opp.NEATMutation;

import java.util.Random;

public class CoEvolveGenomeMutateAddLink extends NEATMutation {

    /**
     * {@inheritDoc}
     */
    @Override
    public void performOperation(final Random rnd, final Genome[] parents,
                                 final int parentIndex, final Genome[] offspring,
                                 final int offspringIndex) {
        CoEvolveEquiInitGenome genome = (CoEvolveEquiInitGenome) obtainGenome(
                parents, parentIndex, offspring,
                offspringIndex);
        NEATPopulation pop = (NEATPopulation) genome.getPopulation();
        if (genome.getDirectLinksExpressed()) {
            NEATGenome directGenome = (NEATGenome) genome.getDirectGenome();
            /*if(directGenome == null){
                System.out.println("wow");
				System.exit(0);
			}
			else {
				System.out.println(((NEATPopulation) directGenome.getPopulation())
				.getActivationCycles());
			}*/
            this.applyMutation(directGenome, rnd, pop);
        }

        if (genome.getIndirectLinksExpressed()) {
            this.applyMutation(genome, rnd, pop);
        }

        offspring[offspringIndex] = genome;
    }

    public void applyMutation(NEATGenome target, Random rnd, NEATPopulation population) {
        int countTrysToAddLink = this.getOwner().getMaxTries();

        // the link will be between these two neurons
        long neuron1ID = -1;
        long neuron2ID = -1;

        // try to add a link
        while ((countTrysToAddLink--) > 0) {
            final NEATNeuronGene neuron1 = this.chooseRandomNeuron(target, true, population);
            final NEATNeuronGene neuron2 = this.chooseRandomNeuron(target, false, population);

            if (neuron1 == null || neuron2 == null) {
                return;
            }

            // do not duplicate
            // do not go to a bias neuron
            // do not go from an output neuron
            // do not go to an input neuron
            if (!isDuplicateLink(target, neuron1.getId(), neuron2.getId())
                    && (neuron2.getNeuronType() != NEATNeuronType.Bias)
                    && (neuron2.getNeuronType() != NEATNeuronType.Input)) {

                if (population.getActivationCycles() != 1
                        || neuron1.getNeuronType() != NEATNeuronType.Output) {
                    neuron1ID = neuron1.getId();
                    neuron2ID = neuron2.getId();
                    break;
                }
            }
        }

        // did we fail to find a link
        if ((neuron1ID < 0) || (neuron2ID < 0)) {
            return;
        }

        double r = population.getWeightRange();
        this.createLink(target, neuron1ID, neuron2ID,
                RangeRandomizer.randomize(rnd, -r, r), population);
        target.sortGenes();
    }

    /**
     * Choose a random neuron.
     *
     * @param target       The target genome. Should the input and bias neurons be
     *                     included.
     * @param choosingFrom True if we are chosing from all neurons, false if we exclude
     *                     the input and bias.
     * @return The random neuron.
     */
    public NEATNeuronGene chooseRandomNeuron(final NEATGenome target,
                                             final boolean choosingFrom, NEATPopulation pop) {
        int start;

        if (choosingFrom) {
            start = 0;
        } else {
            start = target.getInputCount() + 1;
        }

        // if this network will not "cycle" then output neurons cannot be source
        // neurons
        if (!choosingFrom) {
            final int ac = pop.getActivationCycles();
            if (ac == 1) {
                start += target.getOutputCount();
            }
        }

        final int end = target.getNeuronsChromosome().size() - 1;

        // no neurons to pick!
        if (start > end) {
            return null;
        }

        final int neuronPos = RangeRandomizer.randomInt(start, end);
        final NEATNeuronGene neuronGene = target.getNeuronsChromosome().get(
                neuronPos);
        return neuronGene;

    }

    /**
     * Create a link between two neuron id's. Create or find any necessary
     * innovation records.
     *
     * @param target    The target genome.
     * @param neuron1ID The id of the source neuron.
     * @param neuron2ID The id of the target neuron.
     * @param weight    The weight of this new link.
     */
    public void createLink(final NEATGenome target, final long neuron1ID,
                           final long neuron2ID, final double weight, NEATPopulation pop) {

        // first, does this link exist? (and if so, hopefully disabled,
        // otherwise we have a problem)
        for (final NEATLinkGene linkGene : target.getLinksChromosome()) {
            if ((linkGene.getFromNeuronID() == neuron1ID)
                    && (linkGene.getToNeuronID() == neuron2ID)) {
                // bring the link back, at the new weight
                linkGene.setEnabled(true);
                linkGene.setWeight(weight);
                return;
            }
        }

        // check to see if this innovation has already been tried
        final NEATInnovation innovation = pop.getInnovations().findInnovation(neuron1ID,
                neuron2ID);

        // now create this link
        final NEATLinkGene linkGene = new NEATLinkGene(neuron1ID, neuron2ID,
                true, innovation.getInnovationID(), weight);
        target.getLinksChromosome().add(linkGene);
    }


}
