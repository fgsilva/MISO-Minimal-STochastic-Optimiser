package encoding_experiments.coevolve;

import org.encog.engine.network.activation.ActivationFunction;
import org.encog.mathutil.randomize.RangeRandomizer;
import org.encog.ml.ea.genome.Genome;
import org.encog.neural.neat.NEATGenomeFactory;
import org.encog.neural.neat.NEATNeuronType;
import org.encog.neural.neat.NEATPopulation;
import org.encog.neural.neat.training.NEATGenome;
import org.encog.neural.neat.training.NEATLinkGene;
import org.encog.neural.neat.training.NEATNeuronGene;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class FactoryCoEvolveEquiInitGenome implements NEATGenomeFactory, Serializable {

    private final int hiddenNodes;


    public FactoryCoEvolveEquiInitGenome(int hiddenNodes) {
        this.hiddenNodes = hiddenNodes;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public NEATGenome factor() {
        System.out.println("unexpected call");
        try {
            throw new Exception("factor no args");
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.exit(0);
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Genome factor(final Genome other) {
        return new CoEvolveEquiInitGenome((CoEvolveEquiInitGenome) other);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public NEATGenome factor(final List<NEATNeuronGene> neurons,
                             final List<NEATLinkGene> links, final int inputCount,
                             final int outputCount) {
        return new CoEvolveEquiInitGenome(neurons, links, inputCount, outputCount);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public NEATGenome factor(final Random rnd, final NEATPopulation pop,
                             final int inputCount, final int outputCount,
                             final double connectionDensity) {
        CoEvolveEquiInitGenome g = new CoEvolveEquiInitGenome(rnd,
                pop, inputCount, outputCount,
                connectionDensity);

        //no hidden nodes, nothing else to do here.
        if (hiddenNodes <= 0) {
            return g;
        }

        //the hidden neurons code only matters here if we are also using a direct genome.
        //boolean end = false;
        if (g.getDirectLinksExpressed()) {
            int inputs = CoEvolveEquiInitGenome.getAnnInputCount();
            int outputs = CoEvolveEquiInitGenome.getAnnOutputCount();

            //end = true;
            //System.out.println("caught one direct");
            NEATGenome newDirect = createDirectGenomeWIthHiddenNodes(pop, rnd,
                    inputs, outputs, this.hiddenNodes, g);

            g.setDirectGenome(newDirect);
            /*System.out.println("i: " + newDirect.getInputCount());
            System.out.println("o: " + newDirect.getOutputCount());
			System.out.println("links: " + newDirect.getLinksChromosome().size());
			System.out.println("nodes: " + newDirect.getNeuronsChromosome().size());*/
        }

		/*if(end){
			System.out.println("checked");
			System.exit(0);
		}*/
        return g;
    }

    private NEATGenome createDirectGenomeWIthHiddenNodes(NEATPopulation pop,
                                                         Random rnd, int inputCount, int outputCount, int hiddenNodes,
                                                         CoEvolveEquiInitGenome parent) {

        double enabledProb =
                //only direct? then 1, otherwise is hybrid so random.
                parent.getDirectLinksExpressed() && !parent.getIndirectLinksExpressed() ?
                        1.0 : rnd.nextDouble();

        ArrayList<NEATNeuronGene> neuronsList = new ArrayList<NEATNeuronGene>();
        ArrayList<NEATLinkGene> linksList = new ArrayList<NEATLinkGene>();

        ArrayList<NEATNeuronGene> inputs = new ArrayList<NEATNeuronGene>();
        ArrayList<NEATNeuronGene> hidden = new ArrayList<NEATNeuronGene>();
        ArrayList<NEATNeuronGene> outputs = new ArrayList<NEATNeuronGene>();

        // get the activation function
        ActivationFunction af = pop.getActivationFunctions().pickFirst();

        // first bias
        int innovationID = 0;
        NEATNeuronGene biasGene = new NEATNeuronGene(NEATNeuronType.Bias, af,
                inputCount, innovationID++);
        neuronsList.add(biasGene);

        // then inputs
        for (int i = 0; i < inputCount; i++) {
            NEATNeuronGene gene = new NEATNeuronGene(NEATNeuronType.Input, af,
                    i, innovationID++);
            neuronsList.add(gene);
            inputs.add(gene);
        }


        //then hidden nodes
        for (int i = 0; i < hiddenNodes; i++) {
            NEATNeuronGene gene = new NEATNeuronGene(NEATNeuronType.Hidden,
                    af, i + inputCount + 1, innovationID++);
            neuronsList.add(gene);
            hidden.add(gene);
        }

        // then outputs
        for (int i = 0; i < outputCount; i++) {
            NEATNeuronGene gene = new NEATNeuronGene(NEATNeuronType.Output, af,
                    i + inputCount + hiddenNodes + 1, innovationID++);
            neuronsList.add(gene);
            outputs.add(gene);
        }


        double w;
        NEATLinkGene gene;
        // and now links
        //bias to hidden, input to hidden
        for (NEATNeuronGene node : hidden) {
            w = RangeRandomizer.randomize(rnd,
                    -pop.getWeightRange(), pop.getWeightRange());
            gene = new NEATLinkGene(biasGene.getId(), node.getId(),
                    //bias enabled or disabled
                    rnd.nextDouble() < enabledProb,
                    innovationID++, w);
            linksList.add(gene);

            for (NEATNeuronGene input : inputs) {
                w = RangeRandomizer.randomize(rnd,
                        -pop.getWeightRange(), pop.getWeightRange());
                gene = new NEATLinkGene(input.getId(), node.getId(),
                        //weight enabled or disabled
                        rnd.nextDouble() < enabledProb,
                        innovationID++, w);
                linksList.add(gene);
            }
        }

        //bias to output, hidden to output.
        for (NEATNeuronGene node : outputs) {
            w = RangeRandomizer.randomize(rnd,
                    -pop.getWeightRange(), pop.getWeightRange());
            gene = new NEATLinkGene(biasGene.getId(), node.getId(),
                    //enabled or disabled
                    rnd.nextDouble() < enabledProb,
                    innovationID++, w);
            linksList.add(gene);

            for (NEATNeuronGene hiddenNode : hidden) {
                w = RangeRandomizer.randomize(rnd,
                        -pop.getWeightRange(), pop.getWeightRange());
                gene = new NEATLinkGene(hiddenNode.getId(), node.getId(),
                        //enabled or disabled
                        rnd.nextDouble() < enabledProb,
                        innovationID++, w);
                linksList.add(gene);
            }
        }

        NEATGenome genome =
                new NEATGenome(neuronsList, linksList, inputCount, outputCount);

        return genome;
    }


}
