package encoding_experiments.coevolve;

import encoding_experiments.coevolve.aux.DirectExpressedConnection;
import org.encog.Encog;
import org.encog.EncogError;
import org.encog.ml.ea.genome.Genome;
import org.encog.ml.ea.species.BasicSpecies;
import org.encog.ml.ea.species.Species;
import org.encog.neural.neat.training.NEATGenome;
import org.encog.neural.neat.training.NEATLinkGene;

import java.util.HashMap;
import java.util.List;

public class CoEvolveGenomeSpeciation extends RevisedNEATSpeciation {

    private int DIRECT_TARGET_SPECIES = 3, INDIRECT_TARGET_SPECIES = 3, MIXED_TARGET_SPECIES = 3;
    private double directThreshold = 6.0, indirectThreshold = 6.0, mixedThreshold = 12.0;

    /**
     * Serial ID
     */
    private static final long serialVersionUID = 1L;

    @Override
    public double getCompatibilityScore(final Genome gen1,
                                        final Genome gen2) {
        double scoreDirect = 0, scoreIndirect = 0;

        if (gen1 instanceof CoEvolveEquiInitGenome) {
            CoEvolveEquiInitGenome c1 = (CoEvolveEquiInitGenome) gen1;
            CoEvolveEquiInitGenome c2 = (CoEvolveEquiInitGenome) gen2;
            //different at some extent
            if (c1.getDirectLinksExpressed() != c2.getDirectLinksExpressed()
                    || c1.getIndirectLinksExpressed() != c2.getIndirectLinksExpressed()) {
                return Double.MAX_VALUE;
            } else {
                if (c1.getDirectLinksExpressed() && c2.getDirectLinksExpressed()) {
                    //scoreDirect = this.computeCompatibilityScoreWithDifferentNodeStatus(c1.getDirectGenome(), c2.getDirectGenome());
                    scoreDirect = this.computeCompatibilityScore(c1.getDirectGenome(), c2.getDirectGenome());
                }
                if (c2.getIndirectLinksExpressed() && c1.getIndirectLinksExpressed()) {
                    scoreIndirect = this.computeCompatibilityScore(c1, c2);
                }
            }
        }
        /*else if(gen1 instanceof CoEvolvingHybridGenome){
            scoreIndirect = computeCompatibilityScore(gen1, gen2);

			CoEvolvingHybridGenome coe1 = (CoEvolvingHybridGenome) gen1, coe2 = (CoEvolvingHybridGenome) gen2;
			scoreDirect = computeCompatibilityScore(coe1.getDirectGenome(), coe2.getDirectGenome());
		}
		else if(gen1 instanceof CoEvolvingIncrementalGenome){
			CoEvolvingIncrementalGenome coi1 = (CoEvolvingIncrementalGenome) gen1, coi2 = (CoEvolvingIncrementalGenome) gen2;
			scoreIndirect = computeCompatibilityScore(coi1, coi2);

			scoreDirect = computeIncrementalDirectDistance(coi1.getDirectConnectionsToIndex(), coi1.getIsConnectionEnabled(), coi1.getConnectionWeights(), 
					coi2.getDirectConnectionsToIndex(), coi2.getIsConnectionEnabled(), coi2.getConnectionWeights());

		}*/
        else {
            try {
                throw new Exception("unknown genome");
            } catch (Exception e) {
                e.printStackTrace();
                System.exit(0);
            }
        }

        return scoreIndirect + scoreDirect;

    }


    private double computeCompatibilityScoreWithDifferentNodeStatus(
            Genome gen1, Genome gen2) {
        double numDisjoint = 0;
        double numExcess = 0;
        double numMatched = 0;
        double weightDifference = 0;

        final NEATGenome genome1 = (NEATGenome) gen1;
        final NEATGenome genome2 = (NEATGenome) gen2;

        final int genome1Size = genome1.getLinksChromosome().size();
        final int genome2Size = genome2.getLinksChromosome().size();
        final int n = 1;// Math.max(genome1Size, genome2Size);

        int g1 = 0;
        int g2 = 0;

        while ((g1 < genome1Size) || (g2 < genome2Size)) {

            if (g1 == genome1Size) {
                g2++;
                numExcess++;
                continue;
            }

            if (g2 == genome2Size) {
                g1++;
                numExcess++;
                continue;
            }

            NEATLinkGene l1 = genome1.getLinksChromosome().get(g1);
            NEATLinkGene l2 = genome2.getLinksChromosome().get(g2);
            // get innovation numbers for each gene at this point
            final long id1 = l1.getInnovationId();
            final long id2 = l2.getInnovationId();
            final boolean status1 = l1.isEnabled();
            final boolean status2 = l2.isEnabled();

            // innovation numbers are identical and links have the same status so increase the matched score
            if (id1 == id2) {

                if (status1 == status2) {
                    // get the weight difference between these two genes
                    weightDifference += Math.abs(genome1.getLinksChromosome()
                            .get(g1).getWeight()
                            - genome2.getLinksChromosome().get(g2).getWeight());
                    numMatched++;

                } else {
                    numDisjoint++;
                }
                g1++;
                g2++;
            }

            // innovation numbers are different so increment the disjoint score
            if (id1 < id2) {
                numDisjoint++;
                g1++;
            }

            if (id1 > id2) {
                ++numDisjoint;
                ++g2;
            }

        }
        final double score = ((super.getConstExcess() * numExcess) / n)
                + ((super.getConstDisjoint() * numDisjoint) / n)
                + (super.getConstMatched() * (weightDifference / numMatched));
        return score;
    }


    private double computeIncrementalDirectDistance(
            HashMap<DirectExpressedConnection, Integer> m1,
            boolean[] connsEnabled1,
            double[] weights1,
            HashMap<DirectExpressedConnection, Integer> m2,
            boolean[] connsEnabled2, double[] weights2) {

        //we can use only the boolean[] and the double[]
        int matching = 0, disjoint = 0;
        double matchComponent = 0;
        int size1 = 0, size2 = 0;
        for (int i = 0; i < connsEnabled1.length; i++) {
            //at least one enabled
            if (connsEnabled1[i] || connsEnabled2[i]) {
                if (connsEnabled1[i] == connsEnabled2[i]) {
                    matching++;
                    matchComponent += Math.abs(weights1[i] - weights2[i]);
                } else
                    disjoint++;

                if (connsEnabled1[i])
                    size1++;
                if (connsEnabled2[i])
                    size2++;
            }
        }

        //not expressed in none
        if (size1 == 0 && size2 == 0)
            return 0;

        //else, compute similarity
        if (matchComponent > 0)
            matchComponent /= matching;

        double score = this.getConstDisjoint() * disjoint / Math.max(size1, size2) + this.getConstMatched() * matchComponent;
        return score;
    }


    public double computeCompatibilityScore(final Genome gen1,
                                            final Genome gen2) {
        double numDisjoint = 0;
        double numExcess = 0;
        double numMatched = 0;
        double weightDifference = 0;

        final NEATGenome genome1 = (NEATGenome) gen1;
        final NEATGenome genome2 = (NEATGenome) gen2;

        final int genome1Size = genome1.getLinksChromosome().size();
        final int genome2Size = genome2.getLinksChromosome().size();
        final int n = 1;// Math.max(genome1Size, genome2Size);

        int g1 = 0;
        int g2 = 0;

        while ((g1 < genome1Size) || (g2 < genome2Size)) {

            if (g1 == genome1Size) {
                g2++;
                numExcess++;
                continue;
            }

            if (g2 == genome2Size) {
                g1++;
                numExcess++;
                continue;
            }

            // get innovation numbers for each gene at this point
            final long id1 = genome1.getLinksChromosome().get(g1)
                    .getInnovationId();
            final long id2 = genome2.getLinksChromosome().get(g2)
                    .getInnovationId();

            // innovation numbers are identical so increase the matched score
            if (id1 == id2) {

                // get the weight difference between these two genes
                weightDifference += Math.abs(genome1.getLinksChromosome()
                        .get(g1).getWeight()
                        - genome2.getLinksChromosome().get(g2).getWeight());
                g1++;
                g2++;
                numMatched++;
            }

            // innovation numbers are different so increment the disjoint score
            if (id1 < id2) {
                numDisjoint++;
                g1++;
            }

            if (id1 > id2) {
                ++numDisjoint;
                ++g2;
            }

        }

        final double score = ((super.getConstExcess() * numExcess) / n)
                + ((super.getConstDisjoint() * numDisjoint) / n)
                + (super.getConstMatched() * (weightDifference / numMatched));
        return score;
    }

    /****************************************************************************
     * ===================== experimental extensions ===========================
     */

    /**
     * Determine the species.
     *
     * @param genomes The genomes to speciate.
     */
    @Override
    protected void speciateAndCalculateSpawnLevels(final List<Genome> genomes) {
        double maxScore = 0;

        if (genomes.size() == 0) {
            throw new EncogError("Can't speciate, the population is empty.");
        }

        final List<Species> speciesCollection = this.population.getSpecies();

        if (speciesCollection.size() == 0) {
            throw new EncogError("Can't speciate, there are no species.1");
        }


        // assign genomes to species (if any exist)
        for (final Genome g : genomes) {
            Species currentSpecies = null;
            final Genome genome = g;

            if (!Double.isNaN(genome.getAdjustedScore())
                    && !Double.isInfinite(genome.getAdjustedScore())) {
                maxScore = Math.max(genome.getAdjustedScore(), maxScore);
            }

            for (final Species s : speciesCollection) {
                final double compatibility = getCompatibilityScore(genome,
                        s.getLeader());
                CoEvolveEquiInitGenome gen = (CoEvolveEquiInitGenome) genome;
                //candidate genome and leader are of the same type.
                if (compatibility <= this.getCompatibilityThresholdByType(gen)) {
                    currentSpecies = s;
                    addSpeciesMember(s, genome);
                    genome.setSpecies(s);
                    break;
                }
            }

            // if this genome did not fall into any existing species, create a
            // new species
            if (currentSpecies == null) {
                currentSpecies = new BasicSpecies(this.population, genome);
                this.population.getSpecies().add(currentSpecies);
            }
        }


        //
        double totalSpeciesScore = 0;
        for (final Species species : speciesCollection) {
            totalSpeciesScore += species.calculateShare(this.getOwner()
                    .getScoreFunction().shouldMinimize(), maxScore);
        }

        if (speciesCollection.size() == 0) {
            throw new EncogError("Can't speciate, there are no species.2");
        }
        if (totalSpeciesScore < Encog.DEFAULT_DOUBLE_EQUAL) {
            // This should not happen much, or if it does, only in the
            // beginning.
            // All species scored zero. So they are all equally bad. Just divide
            // up the right to produce offspring evenly.
            divideEven(speciesCollection);
        } else {
            // Divide up the number of offspring produced to the most fit
            // species.
            divideByFittestSpecies(speciesCollection, totalSpeciesScore);
        }

        levelOff();

        this.adjustCompatibilityThreshold();


    }

    private double getCompatibilityThresholdByType(CoEvolveEquiInitGenome gen) {
        if (gen.getDirectLinksExpressed() && gen.getIndirectLinksExpressed()) {
            return this.mixedThreshold;
        } else if (gen.getDirectLinksExpressed() && !gen.getIndirectLinksExpressed()) {
            return this.directThreshold;
        } else if (gen.getIndirectLinksExpressed() && !gen.getDirectLinksExpressed()) {
            return this.indirectThreshold;
        }
        return Double.MAX_VALUE;
    }


    /**
     * Adjust the species compatibility threshold. This prevents us from having
     * too many species. Dynamically increase or decrease the
     * compatibilityThreshold.
     */
    @Override
    protected void adjustCompatibilityThreshold() {
        // has this been disabled (unlimited species)
        if (this.maxNumberOfSpecies < 1) {
            return;
        }

        final double thresholdIncrement = 0.3;

        List<Species> listSpecies = this.population.getSpecies();
        int countDirect = 0, countIndirect = 0, countMixed = 0;
        for (Species species : listSpecies) {
            CoEvolveEquiInitGenome leader = (CoEvolveEquiInitGenome) species.getLeader();
            if (leader.getDirectLinksExpressed() && leader.getIndirectLinksExpressed()) {
                countMixed++;
            } else if (leader.getDirectLinksExpressed() && !leader.getIndirectLinksExpressed()) {
                countDirect++;
            } else if (leader.getIndirectLinksExpressed() && !leader.getDirectLinksExpressed()) {
                countIndirect++;
            }
        }

        if (countDirect > this.DIRECT_TARGET_SPECIES) {
            this.directThreshold += thresholdIncrement;
        } else if (countDirect > 0 && countDirect < this.DIRECT_TARGET_SPECIES) {
            this.directThreshold -= thresholdIncrement;
        }

        if (countIndirect > this.INDIRECT_TARGET_SPECIES) {
            this.indirectThreshold += thresholdIncrement;
        } else if (countIndirect > 0 && countIndirect < this.INDIRECT_TARGET_SPECIES) {
            this.indirectThreshold -= thresholdIncrement;
        }

        if (countMixed > this.MIXED_TARGET_SPECIES) {
            this.mixedThreshold += thresholdIncrement;
        } else if (countMixed > 0 && countMixed < this.MIXED_TARGET_SPECIES) {
            this.mixedThreshold -= thresholdIncrement;
        }

        /**
         * readjust the number of target species.
         */
        if (countDirect == 0 || countIndirect == 0 || countMixed == 0) {
            //System.out.println("adjusting, dir: " + countDirect + "; ind: " + countIndirect + "; mix: " + countMixed);
            //only mixed exists
            if (countDirect == 0 && countIndirect == 0) {
                this.MIXED_TARGET_SPECIES = 8;
            }
            //only indirect exists
            else if (countDirect == 0 && countMixed == 0) {
                this.INDIRECT_TARGET_SPECIES = 8;
            }
            //only direct exists
            else if (countIndirect == 0 && countMixed == 0) {
                this.DIRECT_TARGET_SPECIES = 8;
            }
            //else, only one type of species is extinct
            //no direct
            else if (countDirect == 0) {
                this.MIXED_TARGET_SPECIES = 4;
                this.INDIRECT_TARGET_SPECIES = 4;
            }
            //no indirect
            else if (countIndirect == 0) {
                this.MIXED_TARGET_SPECIES = 4;
                this.DIRECT_TARGET_SPECIES = 4;
            }
            //no mixed
            else if (countMixed == 0) {
                this.DIRECT_TARGET_SPECIES = 4;
                this.INDIRECT_TARGET_SPECIES = 4;
            }
        }
    }
}
