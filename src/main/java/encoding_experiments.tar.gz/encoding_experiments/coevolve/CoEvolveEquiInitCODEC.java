package encoding_experiments.coevolve;

import encoding_experiments.BasicSubstrateHyperNEATCODEC;
import encoding_experiments.layeredNets.LayeredANN;
import encoding_experiments.layeredNets.LayeredNEATCODEC;
import org.encog.engine.network.activation.ActivationFunction;
import org.encog.ml.MLMethod;
import org.encog.ml.data.MLData;
import org.encog.ml.data.basic.BasicMLData;
import org.encog.ml.ea.genome.Genome;
import org.encog.neural.hyperneat.substrate.Substrate;
import org.encog.neural.hyperneat.substrate.SubstrateNode;
import org.encog.neural.neat.NEATLink;
import org.encog.neural.neat.NEATPopulation;
import org.encog.neural.neat.training.NEATGenome;
import org.encog.neural.neat.training.NEATLinkGene;

import java.util.ArrayList;
import java.util.HashMap;

public class CoEvolveEquiInitCODEC extends BasicSubstrateHyperNEATCODEC {

    private double weightRange;

    public CoEvolveEquiInitCODEC(double minWeight, double maxWeight,
                                 boolean useBias, boolean useRecurrence, boolean useTanh) {
        super(minWeight, maxWeight, useBias, useRecurrence, useTanh);
    }

    @Override
    public MLMethod decode(final NEATPopulation pop, final Substrate substrate,
                           final Genome g) {
        CoEvolveEquiInitGenome coGenome = (CoEvolveEquiInitGenome) g;
        this.weightRange = pop.getWeightRange();

        WeightsCorrespondence corr = new WeightsCorrespondence();
        if (coGenome.getDirectLinksExpressed()) {
            //add offsets (directly encoded)
            NEATGenome directGenome = coGenome.getDirectGenome();
            /**
             * compatibilise ids.
             * direct encoding, bias id = input count; inputs id from 0 to N - 1
             * indirect encoding, bias id = 0; input id from 1 to N
             * solution: follow the indirect encoding way.
             */
            HashMap<Long, Long> compatibilityMap = createCompatibilityMap(
                    substrate.getInputCount());

            for (NEATLinkGene link : directGenome.getLinksChromosome()) {
                if (link.isEnabled()) {
                    long from = link.getFromNeuronID(), to = link.getToNeuronID();
                    //compatibilise
                    if (compatibilityMap.containsKey(from)) {
                        from = compatibilityMap.get(from);
                    }
                    if (compatibilityMap.containsKey(to)) {
                        to = compatibilityMap.get(to);
                    }
                    corr.putInfo(from, to,
                            link.getWeight());
                }
            }
        }

        final ArrayList<NEATLink> linkList = new ArrayList<NEATLink>();
        final ActivationFunction[] afs = new ActivationFunction[substrate.getNodeCount()];

        final ActivationFunction af = this.function.clone();
        // all activation functions are the same
        for (int i = 0; i < afs.length; i++) {
            afs[i] = af;
        }

        LayeredANN cppn = null;
        //NEATNetwork cppn = null;
        if (coGenome.getIndirectLinksExpressed()) {
            // obtain the CPPN
            // obtain the CPPN
            final LayeredNEATCODEC neatCodec = new LayeredNEATCODEC(biasFirstCPPN);
            cppn = (LayeredANN) neatCodec.decode(coGenome);
        }

        decodeDirectWeights(substrate, cppn, linkList, corr,
                coGenome.getIndirectLinksExpressed(), coGenome.getDirectLinksExpressed());
        decodeRecurrentLinks(substrate, cppn, linkList, corr,
                coGenome.getIndirectLinksExpressed(), coGenome.getDirectLinksExpressed());
        corr.clear();

        if (coGenome.getIndirectLinksExpressed()) {
            decodeBiasLinks(substrate, cppn, linkList);
        }

        BasicSubstrateHyperNEATCODEC basic = new BasicSubstrateHyperNEATCODEC();

        LayeredANN net = basic.createNetworkFromNEATLinks(linkList, substrate, af);
        return net;

        // check for invalid neural network
        /*if (linkList.size() == 0) {
            return null;
		}

		Collections.sort(linkList);

		final NEATNetwork network = new NEATNetwork(substrate.getInputCount(),
				substrate.getOutputCount(), linkList, afs);

		network.setActivationCycles(substrate.getActivationCycles());
		return network;*/
    }

    /**
     * * compatibilise ids.
     * direct encoding, bias id = input count; inputs id from 0 to N - 1
     * indirect encoding, bias id = 0; input id from 1 to N
     * solution: follow the indirect encoding way.
     */
    private HashMap<Long, Long> createCompatibilityMap(int inputCount) {
        HashMap<Long, Long> directToIndirect = new HashMap<Long, Long>();
        directToIndirect.put((long) inputCount, (long) 0);
        for (long i = 0; i < inputCount; i++) {
            directToIndirect.put(i, i + 1);
        }
        return directToIndirect;
    }

	/*private void addOffsets(NEATNetwork network, WeightsCorrespondence corr) {
		for(NEATLink link : network.getLinks()){
			double newWeight = link.getWeight() + corr.getWeight(link.getFromNeuron(), link.getToNeuron());
			link.setWeight(newWeight);
		}
	}*/

    protected void decodeRecurrentLinks(
            Substrate substrate, LayeredANN cppn, ArrayList<NEATLink> linkList,
            WeightsCorrespondence corr,
            boolean useIndirect, boolean useDirect) {
        //input vector and output vector;
        final MLData input = useIndirect ?
                new BasicMLData(cppn.getInputCount()) : null;
        MLData output = null;

        //create recurrent links
        if (this.useRecurrence) {
            for (SubstrateNode target : substrate.getOutputNodes()) {

                double weight = 0;

                //direct encoding not used or connection not enabled = false
                if (corr.containsConnection(target.getId(), target.getId())) {
                    weight = corr.getWeight(target.getId(), target.getId());
                } else if (useIndirect) {
                    double[] targetLocation = target.getLocation();
                    //x1, y1, x1, y1, i.e., link from self & to self
                    input.setData(new double[]{targetLocation[0], targetLocation[1], targetLocation[0], targetLocation[1]});

                    output = cppn.compute(input);
                    //connection weight as cppn output number 1
                    weight = output.getData(0);
                    if (Math.abs(weight) > this.minWeight) {
                        //rescale.
                        weight *= this.maxWeight;
                    } else
                        weight = 0;
                }
						/*if(!this.controlOffset || (this.controlOffset && output.getData(1) > 0)){
					weight += this.getOffset(corr, target.getId(), target.getId());
				}*/

                weight = this.clampWeight(weight);


                linkList.add(new NEATLink(target.getId(), target.getId(), weight));
            }
        }
    }

    private double clampWeight(double weight) {
        if (weight < -this.weightRange)
            weight = -this.weightRange;
        else if (weight > this.weightRange)
            weight = this.weightRange;

        return weight;
    }


    protected void decodeDirectWeights(Substrate substrate, LayeredANN cppn,
                                       ArrayList<NEATLink> linkList, WeightsCorrespondence corr,
                                       boolean useIndirect, boolean useDirect) {
        //input vector
        final MLData input = useIndirect ?
                new BasicMLData(cppn.getInputCount()) : null;
        MLData output = null;

        //create all non-bias non-recurrent links
        for (SubstrateNode source : substrate.getInputNodes()) {
            for (SubstrateNode target : substrate.getOutputNodes()) {

                double weight = 0;

                if (corr.containsConnection(source.getId(), target.getId())) {
                    weight = corr.getWeight(source.getId(), target.getId());
                } else if (useIndirect) {
                    //SubstrateNode source = link.getSource(), target = link.getTarget();
                    double[] sourceLocation = source.getLocation(), targetLocation = target.getLocation();
                    //x1, y1, x2, y2
                    input.setData(new double[]{sourceLocation[0], sourceLocation[1],
                            targetLocation[0], targetLocation[1]});

                    output = cppn.compute(input);
                    //connection weight as cppn output number 1

                    weight = output.getData(0);

                    if (Math.abs(weight) > this.minWeight) {
                        //rescale.
                        weight *= this.maxWeight;
                    } else
                        weight = 0;
                }

						/*if(!this.controlOffset || (this.controlOffset && output.getData(1) > 0)){
					weight += this.getOffset(corr, source.getId(), target.getId());
				}*/

                weight = this.clampWeight(weight);


                linkList.add(new NEATLink(source.getId(), target.getId(), weight));
            }
        }
    }


}
