package encoding_experiments.coevolve;

import org.encog.ml.ea.train.EvolutionaryAlgorithm;
import org.encog.neural.neat.training.NEATGenome;
import org.encog.neural.neat.training.NEATLinkGene;
import org.encog.neural.neat.training.opp.links.SelectLinks;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class CoEvolveEquiInitGenomeSelectLinkProportion implements SelectLinks {

    /**
     * The portion of the links to mutate. 0.0 for none, 1.0 for all.
     */
    private double proportion;

    /**
     * The trainer.
     */
    private EvolutionaryAlgorithm trainer;

    /**
     * Select based on proportion.
     *
     * @param theProportion The proportion to select from.
     */
    public CoEvolveEquiInitGenomeSelectLinkProportion(double theProportion) {
        this.proportion = theProportion;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void init(EvolutionaryAlgorithm theTrainer) {
        this.trainer = theTrainer;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public List<NEATLinkGene> selectLinks(Random rnd, NEATGenome genome) {
        List<NEATLinkGene> result = new ArrayList<NEATLinkGene>();

        boolean mutated = false;

        CoEvolveEquiInitGenome coevolve = (CoEvolveEquiInitGenome) genome;
        ArrayList<NEATLinkGene> allLinks = new ArrayList<NEATLinkGene>();
        if (coevolve.getIndirectLinksExpressed()) {
            //add of indirect.
            allLinks.addAll(coevolve.getLinksChromosome());
        }
        if (coevolve.getDirectLinksExpressed()) {
            //add of direct
            allLinks.addAll(coevolve.getDirectGenome().getLinksChromosome());
        }

        for (final NEATLinkGene linkGene : allLinks) {
            if (rnd.nextDouble() < this.proportion) {
                mutated = true;
                result.add(linkGene);
            }
        }

        if (!mutated) {
            int idx = rnd.nextInt(allLinks.size());
            NEATLinkGene linkGene = allLinks.get(idx);
            result.add(linkGene);
        }

        return result;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public EvolutionaryAlgorithm getTrainer() {
        return trainer;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String toString() {
        StringBuilder result = new StringBuilder();
        result.append("[");
        result.append(this.getClass().getSimpleName());
        result.append(":proportion=");
        result.append(this.proportion);
        result.append("]");
        return result.toString();
    }
}
