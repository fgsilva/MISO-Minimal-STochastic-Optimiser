package encoding_experiments;

import org.encog.neural.hyperneat.substrate.Substrate;
import org.encog.neural.hyperneat.substrate.SubstrateNode;

import java.io.Serializable;

public class ExtendedSubstrateFactory implements Serializable {

    private static final double xMin = -1, xMax = 1, yMin = -1, yMax = 1;

    public static Substrate createSandwichSubstrate(int inputNodesX, int inputNodesY,
                                                    int outputNodesX, int outputNodesY) {

        Substrate result = new Substrate(3);
        double inputXTick = (xMax - xMin) / (inputNodesX - 1), inputYTick = (yMax - yMin) / (inputNodesY - 1);
        double outputXTick = (xMax - xMin) / (outputNodesX - 1), outputYTick = (yMax - yMin) / (outputNodesY - 1);

        //create the input layer
        for (int col = 0; col < inputNodesX; col++) {
            for (int row = 0; row < inputNodesY; row++) {
                double xCor = xMin + (col * inputXTick), yCor = yMin + (row * inputYTick);
                SubstrateNode inputNode = result.createInputNode();
                //set coordinates, z-axis only used for debugging purposes
                inputNode.getLocation()[0] = xCor;
                inputNode.getLocation()[1] = yCor;
                inputNode.getLocation()[2] = -1;
            }
        }

        //now create the output layer
        for (int col = 0; col < outputNodesX; col++) {
            for (int row = 0; row < outputNodesY; row++) {
                double xCor = xMin + (col * outputXTick), yCor = yMin + (row * outputYTick);
                SubstrateNode outputNode = result.createOutputNode();
                //set coordinates, z-axis only used for debugging purposes
                outputNode.getLocation()[0] = xCor;
                outputNode.getLocation()[1] = yCor;
                outputNode.getLocation()[2] = 1;

                // link this output node to every input node
                for (SubstrateNode inputNode : result.getInputNodes()) {
                    result.createLink(inputNode, outputNode);
                }
            }
        }

        return result;
    }

    public static Substrate createMultiLayerSubstrate(int inputNodesX,
                                                      int inputNodesY, int outputNodesX, int outputNodesY, int hiddenNodes) {

        Substrate result = new Substrate(3);
        double inputXTick = (xMax - xMin) / (inputNodesX - 1), outputXTick = (xMax - xMin) / (outputNodesX - 1), hiddenXTick = (xMax - xMin) / (hiddenNodes - 1);

        //create the input layer, all input nodes at y = -1
        for (int col = 0; col < inputNodesX; col++) {
            for (int row = 0; row < inputNodesY; row++) {
                double xCor = xMin + (col * inputXTick), yCor = yMin;
                SubstrateNode inputNode = result.createInputNode();
                //set coordinates, z-axis only used for debugging purposes
                inputNode.getLocation()[0] = xCor;
                inputNode.getLocation()[1] = yCor;
                inputNode.getLocation()[2] = -1;
            }
        }

        //create hidden layer, y = (ymin + ymax)/2
        for (int col = 0; col < hiddenNodes; col++) {
            double xCor = xMin + (col * hiddenXTick), yCor = (yMin + yMax) / 2;
            SubstrateNode hiddenNode = result.createHiddenNode();
            hiddenNode.getLocation()[0] = xCor;
            hiddenNode.getLocation()[1] = yCor;
            hiddenNode.getLocation()[2] = 0;


            // link this hidden node to every input node
            for (SubstrateNode inputNode : result.getInputNodes()) {
                result.createLink(inputNode, hiddenNode);
            }
        }

        //now create the output layer, at ymax
        for (int col = 0; col < outputNodesX; col++) {
            for (int row = 0; row < outputNodesY; row++) {
                double xCor = xMin + (col * outputXTick), yCor = yMax;
                SubstrateNode outputNode = result.createOutputNode();
                //set coordinates, z-axis only used for debugging purposes
                outputNode.getLocation()[0] = xCor;
                outputNode.getLocation()[1] = yCor;
                outputNode.getLocation()[2] = 1;

                // link this output node to every hidden node
                for (SubstrateNode hiddenNode : result.getHiddenNodes()) {
                    result.createLink(hiddenNode, outputNode);
                }
            }
        }

        return result;
    }

}
