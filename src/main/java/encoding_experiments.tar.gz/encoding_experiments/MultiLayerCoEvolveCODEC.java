package encoding_experiments;

import encoding_experiments.coevolve.CoEvolveEquiInitGenome;
import encoding_experiments.coevolve.WeightsCorrespondence;
import encoding_experiments.layeredNets.ANNNeuron;
import encoding_experiments.layeredNets.ANNSynapse;
import encoding_experiments.layeredNets.LayeredANN;
import encoding_experiments.layeredNets.LayeredNEATCODEC;
import org.encog.engine.network.activation.ActivationFunction;
import org.encog.engine.network.activation.ActivationSteepenedSigmoid;
import org.encog.ml.MLMethod;
import org.encog.ml.data.MLData;
import org.encog.ml.data.basic.BasicMLData;
import org.encog.ml.ea.genome.Genome;
import org.encog.neural.hyperneat.substrate.Substrate;
import org.encog.neural.hyperneat.substrate.SubstrateNode;
import org.encog.neural.neat.NEATLink;
import org.encog.neural.neat.NEATPopulation;
import org.encog.neural.neat.training.NEATGenome;
import org.encog.neural.neat.training.NEATLinkGene;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

public class MultiLayerCoEvolveCODEC extends BasicSubstrateHyperNEATCODEC implements Serializable {


    public MultiLayerCoEvolveCODEC(double minWeight, double maxWeight,
                                   boolean useBias, boolean useRecurrence, boolean useTanh) {
        super(minWeight, maxWeight, useBias, useRecurrence, useTanh);
    }

    @Override
    public MLMethod decode(final NEATPopulation pop, final Substrate substrate,
                           final Genome g) {
        CoEvolveEquiInitGenome coGenome = (CoEvolveEquiInitGenome) g;

        /**
         * ONLY INDIRECT
         */
        if (coGenome.getIndirectLinksExpressed() && !coGenome.getDirectLinksExpressed()) {
            return new MultiLayerSubstrateHyperNEATCODEC(minWeight, maxWeight, useBias, useRecurrence, useTanh).decode(g);
        }
        /**
         * ONLY DIRECT
         */
        else if (coGenome.getDirectLinksExpressed() && !coGenome.getIndirectLinksExpressed()) {
            coGenome.getDirectGenome().setPopulation(coGenome.getPopulation());
            return new LayeredNEATCODEC(false).decode(coGenome.getDirectGenome());
        }
        //hybrid
        else {
            //int totalNodes = coGenome.getDirectGenome().getNeuronsChromosome().size();
            final ArrayList<NEATLink> linkList = new ArrayList<NEATLink>();

            WeightsCorrespondence corr = new WeightsCorrespondence();

            NEATGenome directGenome = coGenome.getDirectGenome();
            /**
             * compatibilise ids.
             * direct encoding, bias id = input count; inputs id from 0 to N - 1
             * indirect encoding, bias id = 0; input id from 1 to N
             * solution: follow the indirect encoding way.
             */
            HashMap<Long, Long> compatibilityMap = createCompatibilityMap(
                    substrate.getInputCount());
            for (NEATLinkGene link : directGenome.getLinksChromosome()) {
                if (link.isEnabled()) {
                    long from = link.getFromNeuronID(), to = link.getToNeuronID();
                    //compatibilise
                    if (compatibilityMap.containsKey(from)) {
                        from = compatibilityMap.get(from);
                    }
                    if (compatibilityMap.containsKey(to)) {
                        to = compatibilityMap.get(to);
                    }
                    corr.putInfo(from, to,
                            link.getWeight());
                    //add all direct, they take precedence over the CPPNs
                    linkList.add(new NEATLink((int) from,
                            (int) to, link.getWeight()));
                }
            }

            // obtain the CPPN
            final LayeredNEATCODEC neatCodec = new LayeredNEATCODEC(biasFirstCPPN);
            final LayeredANN cppn = (LayeredANN) neatCodec.decode(coGenome);

            //NEATNetwork cppn = (NEATNetwork) new NEATCODEC().decode(coGenome);

            try {
                this.decodeDirectWeights(substrate, cppn, linkList, corr);
                this.decodeRecurrentLinks(substrate, cppn, linkList, corr);
                this.decodeBiasLinks(substrate, cppn, linkList, corr, 1);
            } catch (Exception e) {

            }
            corr.clear();

            if (this.function == null) {
                function = new ActivationSteepenedSigmoid();
            }
            final ActivationFunction af = this.function.clone();

            LayeredANN net = this.createHybridNetworkFromNEATLinks(
                    linkList, substrate, af);
            return net;
            /**
             * OLD
             */
            // check for invalid neural network
            /**if (linkList.size() == 0) {
             return null;
             }

             Collections.sort(linkList);

             //final ActivationFunction[] afs = new ActivationFunction[totalNodes];

             final ActivationFunction[] afs = new ActivationFunction[countNodes(linkList)];

             final ActivationFunction af = this.function.clone();
             // all activation functions are the same
             for (int i = 0; i < afs.length; i++) {
             afs[i] = af;
             }

             final NEATNetwork network = new NEATNetwork(substrate.getInputCount(),
             substrate.getOutputCount(), linkList, afs);

             network.setActivationCycles(substrate.getActivationCycles());
             return network;**/
        }
    }

    /**
     * * compatibilise ids.
     * direct encoding, bias id = input count; inputs id from 0 to N - 1
     * indirect encoding, bias id = 0; input id from 1 to N
     * solution: follow the indirect encoding way.
     */
    private HashMap<Long, Long> createCompatibilityMap(int inputCount) {
        HashMap<Long, Long> directToIndirect = new HashMap<Long, Long>();
        directToIndirect.put((long) inputCount, (long) 0);
        for (long i = 0; i < inputCount; i++) {
            directToIndirect.put(i, i + 1);
        }
        return directToIndirect;
    }

    private LayeredANN createHybridNetworkFromNEATLinks(
            ArrayList<NEATLink> linkList, Substrate substrate,
            ActivationFunction af) {
        ArrayList<ANNSynapse> synapses = createSynapsesFromNEATLink(linkList);
        ArrayList<ANNNeuron> neurons = createNeuronsFromAllStructures(
                substrate, af, linkList);

        LayeredANN net = new LayeredNEATCODEC(biasFirstANN).
                createNetFromStructure(synapses, neurons);

        return net;
    }

    private ArrayList<ANNNeuron> createNeuronsFromAllStructures(
            Substrate substrate, ActivationFunction af,
            ArrayList<NEATLink> linkList) {
        ArrayList<ANNNeuron> neurons = new ArrayList<ANNNeuron>();
        //keep track of neurons processed
        HashSet<Integer> neuronsProcessed = new HashSet<Integer>();

        ANNNeuron bias = new ANNNeuron(0, ANNNeuron.BIAS_NEURON, af.clone());
        neurons.add(bias);
        neuronsProcessed.add(0);

        //create inputs
        for (SubstrateNode input : substrate.getInputNodes()) {
            ANNNeuron inputNeuron = new ANNNeuron(input.getId(),
                    ANNNeuron.INPUT_NEURON, af.clone());
            neurons.add(inputNeuron);
            //add to set
            neuronsProcessed.add(input.getId());
        }

        //create hidden
        for (SubstrateNode hidden : substrate.getHiddenNodes()) {
            ANNNeuron hiddenNeuron = new ANNNeuron(
                    hidden.getId(), ANNNeuron.HIDDEN_NEURON, af.clone());
            neurons.add(hiddenNeuron);
            neuronsProcessed.add(hidden.getId());
        }

        //create output
        for (SubstrateNode output : substrate.getOutputNodes()) {
            ANNNeuron outputNeuron = new ANNNeuron(
                    output.getId(), ANNNeuron.OUTPUT_NEURON, af.clone());
            neurons.add(outputNeuron);
            neuronsProcessed.add(output.getId());
        }

        //all neurons not processed are hidden, loop through the links and find them
        for (NEATLink link : linkList) {
            int from = link.getFromNeuron(), to = link.getToNeuron();
            //from
            if (!neuronsProcessed.contains(from)) {
                ANNNeuron newNeuron = new ANNNeuron(from, ANNNeuron.HIDDEN_NEURON, af.clone());
                //add to list of neurons
                neurons.add(newNeuron);
                //add to set
                neuronsProcessed.add(from);
            }
            //to
            if (!neuronsProcessed.contains(to)) {
                ANNNeuron newNeuron = new ANNNeuron(to, ANNNeuron.HIDDEN_NEURON, af.clone());
                //add to list of neurons
                neurons.add(newNeuron);
                //add to set
                neuronsProcessed.add(to);
            }
        }

        return neurons;
    }

    /**
     * private int countNodes(ArrayList<NEATLink> linkList) {
     * HashSet<Integer> nodes = new HashSet<Integer>();
     * <p>
     * for(NEATLink link : linkList){
     * if(!nodes.contains(link.getFromNeuron())){
     * nodes.add(link.getFromNeuron());
     * }
     * <p>
     * if(!nodes.contains(link.getToNeuron())){
     * nodes.add(link.getToNeuron());
     * }
     * }
     * /*for(Integer node : nodes){
     * System.out.print(node + "\t");
     * }
     */
    //System.out.println("TOTAL NODES: " + nodes.size());
    /*return nodes.size();
    }**/
    protected void decodeBiasLinks(Substrate substrate, LayeredANN cppn,
                                   ArrayList<NEATLink> linkList, WeightsCorrespondence corr,
                                   int cppnBiasOutputIndex) {
        //input vector
        final MLData input = new BasicMLData(cppn.getInputCount());


        // now create biased links
        if (this.useBias) {
            input.clear();
            final List<SubstrateNode> biasedNodes = substrate.getBiasedNodes();
            for (final SubstrateNode target : biasedNodes) {
                if (!corr.containsConnection(0, target.getId())) {
                    //query the cppn to get the bias value for node at (x,y)
                    //cppn input = (x,y, 0, 0)
                    double[] targetLocation = target.getLocation();
                    input.setData(0, targetLocation[0]);
                    input.setData(1, targetLocation[1]);

                    //input.setData(4, cppnBias);

                    final MLData output = cppn.compute(input);

                    double biasWeight = 0;
                    try {
                        biasWeight = output.getData(cppnBiasOutputIndex);
                    } catch (ArrayIndexOutOfBoundsException e) {
                        System.out.println("a1 -- mlc");
                    } catch (IndexOutOfBoundsException e) {
                        System.out.println("a2 -- mlc");
                    }
                    if (Math.abs(biasWeight) > this.minWeight) {
                        //rescale.
                        biasWeight *= this.maxWeight;
                    } else
                        biasWeight = 0;

                    linkList.add(new NEATLink(0, target.getId(), biasWeight));
                }
            }
        }
    }

    protected void decodeRecurrentLinks(
            Substrate substrate, LayeredANN cppn, ArrayList<NEATLink> linkList,
            WeightsCorrespondence corr) {
        //create recurrent links
        if (this.useRecurrence) {
            this.decodeSelfRecurrent(substrate.getHiddenNodes(), 0, linkList, cppn, corr);
            this.decodeSelfRecurrent(substrate.getOutputNodes(), 0, linkList, cppn, corr);
        }
    }

    private void decodeSelfRecurrent(List<SubstrateNode> nodes, int cppnOutputIndex,
                                     ArrayList<NEATLink> linkList, LayeredANN cppn,
                                     WeightsCorrespondence corr) {
        //input vector
        final MLData input = new BasicMLData(cppn.getInputCount());

        for (SubstrateNode target : nodes) {
            if (!corr.containsConnection(target.getId(), target.getId())) {
                //SubstrateNode source = link.getSource(), target = link.getTarget();
                double[] targetLocation = target.getLocation();
                //x1, y1, x1, y1, i.e., link from self & to self
                input.setData(new double[]{targetLocation[0], targetLocation[1],
                        targetLocation[0], targetLocation[1]});

                final MLData output = cppn.compute(input);
                //connection weight as cppn output number 1
                double weight = output.getData(cppnOutputIndex);
                if (Math.abs(weight) > this.minWeight) {
                    //rescale.
                    weight *= this.maxWeight;
                } else
                    weight = 0;
                linkList.add(new NEATLink(target.getId(), target.getId(), weight));
            }
        }
    }

    protected void decodeDirectWeights(Substrate substrate, LayeredANN cppn,
                                       ArrayList<NEATLink> linkList, WeightsCorrespondence corr) {
        //create all non-bias non-recurrent links
        //first, input to hidden
        this.decodeFromTo(substrate.getInputNodes(), substrate.getHiddenNodes(),
                0, linkList, cppn, corr);
        //then, hidden to output
        this.decodeFromTo(substrate.getHiddenNodes(), substrate.getOutputNodes(),
                0, linkList, cppn, corr);
    }

    private void decodeFromTo(List<SubstrateNode> inputNodes,
                              List<SubstrateNode> targetNodes, int cppnOutputIndex,
                              ArrayList<NEATLink> linkList, LayeredANN cppn,
                              WeightsCorrespondence corr) {
        //input vector
        final MLData input = new BasicMLData(cppn.getInputCount());

        for (SubstrateNode source : inputNodes) {
            for (SubstrateNode target : targetNodes) {
                //not expressed directly
                if (!corr.containsConnection(source.getId(), target.getId())) {
                    //SubstrateNode source = link.getSource(), target = link.getTarget();
                    double[] sourceLocation = source.getLocation(), targetLocation = target.getLocation();
                    //x1, y1, x2, y2
                    input.setData(new double[]{sourceLocation[0], sourceLocation[1],
                            targetLocation[0], targetLocation[1]});

                    final MLData output = cppn.compute(input);
                    double weight = output.getData(cppnOutputIndex);

                    if (Math.abs(weight) > this.minWeight) {
                        //rescale.
                        weight *= this.maxWeight;
                    } else
                        weight = 0;

                    linkList.add(new NEATLink(source.getId(), target.getId(), weight));
                }
            }
        }
    }
}
