package encoding_experiments;

import java.io.IOException;

public class RunVisualTaskEvolutionEngine {

    public static void main(String[] args) throws IOException {
        //String ftneatConf = "neatConfs/ftneat_visual.conf";
        //String hyperneatConf = "neatConfs/hyperneat_visual.conf";
        String hybridConf = "neatConfs/coevol_hybrid_visual.conf";

        long time = System.currentTimeMillis() / 1000;

		/*System.out.println(hyperneatConf);
        EvolutionEngine.main(new String[]{hyperneatConf});
		System.out.println("TIME: " + (System.currentTimeMillis()/1000 - time) + " seconds");
		Runtime.getRuntime().gc();*/


        time = System.currentTimeMillis() / 1000;
        System.out.println(hybridConf);
        EvolutionEngine.main(new String[]{hybridConf});
        System.out.println("TIME: " + (System.currentTimeMillis() / 1000 - time) + " seconds");
        Runtime.getRuntime().gc();
		
		/*time = System.currentTimeMillis() / 1000;
		System.out.println(ftneatConf);
		EvolutionEngine.main(new String[]{ftneatConf});
		System.out.println("TIME: " + (System.currentTimeMillis()/1000 - time) + " seconds");
		Runtime.getRuntime().gc();
		
		//// weights
		/*String hyperneatWeights7by7 = "neatConfs/hyperneat_weights_target7x7.conf";
		time = System.currentTimeMillis() / 1000;
		System.out.println(hyperneatWeights7by7);
		EvolutionEngine.main(new String[]{hyperneatWeights7by7});
		System.out.println("TIME: " + (System.currentTimeMillis()/1000 - time) + " seconds");
		Runtime.getRuntime().gc();*/
    }

}
