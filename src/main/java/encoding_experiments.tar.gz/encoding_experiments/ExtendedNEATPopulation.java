package encoding_experiments;


import encoding_experiments.coevolve.CoEvolveEquiInitGenome;
import encoding_experiments.functions.CPPNFunctionBuilder;
import encoding_experiments.functions.RescaledSigmoid;
import org.encog.engine.network.activation.ActivationSteepenedSigmoid;
import org.encog.ml.ea.species.BasicSpecies;
import org.encog.neural.hyperneat.substrate.Substrate;
import org.encog.neural.neat.FactorNEATGenome;
import org.encog.neural.neat.NEATPopulation;
import org.encog.neural.neat.training.NEATGenome;
import org.encog.neural.neat.training.NEATInnovationList;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Random;


/**
 * @author fernando
 */
public class ExtendedNEATPopulation extends NEATPopulation implements Serializable {

    private static final long serialVersionUID = 1L;

    private double overriddenWeightRange;

    //for serialisation
    public ExtendedNEATPopulation() {
    }

    /**
     * to be used with neat
     */
    public ExtendedNEATPopulation(final int populationSize, int inputCount, int outputCount,
                                  double weightRange, int activationCycles, double connectionDensity, boolean useTanh) {
        super(inputCount, outputCount, populationSize);
        super.setInitialConnectionDensity(connectionDensity);
        super.setActivationCycles(activationCycles);
        this.overriddenWeightRange = weightRange;
        if (useTanh) {
            super.setNEATActivationFunction(new RescaledSigmoid());
        } else
            setNEATActivationFunction(new ActivationSteepenedSigmoid());
    }

    /**
     * to be used with hyperneat
     */
    public ExtendedNEATPopulation(final Substrate substrate, final int populationSize,
                                  int inputCount, int outputCount,
                                  double weightRange, int activationCycles,
                                  CPPNFunctionBuilder builder, double connectionDensity) {
        super(substrate, populationSize);
        super.setInputCount(inputCount);
        super.setOutputCount(outputCount);
        super.setInitialConnectionDensity(connectionDensity);
        super.setActivationCycles(activationCycles);
        this.overriddenWeightRange = weightRange;
        builder.buildCPPNActivationFunctions(super.getActivationFunctions());
    }

    @Override
    public double getWeightRange() {
        return this.overriddenWeightRange;
    }

    @Override
    public void reset() {
        //manually reset because of the factory (encog's default factories are not serializable)
        // create the genome factory
        if (isHyperNEAT()) {
            //codec overriden after this method is called
            //this.codec = new HyperNEATCODEC();
            setGenomeFactory(new SerializableFactorHyperNEATGenome());
        } else {
            //codec overriden after this method is called
            //this.codec = new NEATCODEC();
            //NOTE: factor neat genome is serializable
            setGenomeFactory(new FactorNEATGenome());
        }

        // create the new genomes
        getSpecies().clear();

        // reset counters
        getGeneIDGenerate().setCurrentID(1);
        getInnovationIDGenerate().setCurrentID(1);

        final Random rnd = super.getRandomNumberFactory().factor();

        // create one default species
        final BasicSpecies defaultSpecies = new BasicSpecies();
        defaultSpecies.setPopulation(this);

        // create the initial population
        for (int i = 0; i < getPopulationSize(); i++) {
            final NEATGenome genome = getGenomeFactory().factor(rnd, this,
                    super.getInputCount(), super.getOutputCount(),
                    super.getInitialConnectionDensity());
            defaultSpecies.add(genome);
        }
        defaultSpecies.setLeader(defaultSpecies.getMembers().get(0));
        getSpecies().add(defaultSpecies);

        // create initial innovations
        setInnovations(new NEATInnovationList(this));
    }


    public void reset(ArrayList<NEATGenome> population) {

        //manually reset because of the factory (encog's default factories are not serializable)
        // create the genome factory
        if (isHyperNEAT()) {
            //codec overriden after this method is called
            //this.codec = new HyperNEATCODEC();
            setGenomeFactory(new SerializableFactorHyperNEATGenome());
        } else {
            //codec overriden after this method is called
            //this.codec = new NEATCODEC();
            //NOTE: factor neat genome is serializable
            setGenomeFactory(new FactorNEATGenome());
        }

        // create the new genomes
        getSpecies().clear();

        // reset counters
        getGeneIDGenerate().setCurrentID(1);
        getInnovationIDGenerate().setCurrentID(1);

        final Random rnd = super.getRandomNumberFactory().factor();

        // create one default species
        final BasicSpecies defaultSpecies = new BasicSpecies();
        defaultSpecies.setPopulation(this);

        // create the initial population
        for (int i = 0; i < population.size(); i++) {
            final NEATGenome genome = new NEATGenome(population.get(i).getNeuronsChromosome(),
                    population.get(i).getLinksChromosome(),
                    super.getInputCount(), super.getOutputCount());
            defaultSpecies.add(genome);
        }
        defaultSpecies.setLeader(defaultSpecies.getMembers().get(0));
        getSpecies().add(defaultSpecies);

        // create initial innovations
        setInnovations(new NEATInnovationList(this));
    }

    public void resetCombined() {
        // create the new genomes
        getSpecies().clear();

        // reset counters
        getGeneIDGenerate().setCurrentID(1);
        getInnovationIDGenerate().setCurrentID(1);

        final Random rnd = super.getRandomNumberFactory().factor();

        // create one default species
        final BasicSpecies defaultSpecies = new BasicSpecies();
        defaultSpecies.setPopulation(this);

        // create the initial population
        for (int i = 0; i < getPopulationSize(); i++) {
            final NEATGenome genome = getGenomeFactory().factor(rnd, this,
                    super.getInputCount(), super.getOutputCount(),
                    super.getInitialConnectionDensity());
            defaultSpecies.add(genome);
        }
        defaultSpecies.setLeader(defaultSpecies.getMembers().get(0));
        getSpecies().add(defaultSpecies);

        // create initial innovations
        setInnovations(new NEATInnovationList(this));
    }

    public void resetEquiInitCombined() {
        // create the new genomes
        getSpecies().clear();

        // reset counters
        getGeneIDGenerate().setCurrentID(1);
        getInnovationIDGenerate().setCurrentID(1);

        final Random rnd = super.getRandomNumberFactory().factor();

        // create three default species
        //final BasicSpecies indirectSpecies = new BasicSpecies();
        //final BasicSpecies directSpecies = new BasicSpecies();
        final BasicSpecies mixedSpecies = new BasicSpecies();

        //indirectSpecies.setPopulation(this);
        //directSpecies.setPopulation(this);
        mixedSpecies.setPopulation(this);

        // create the initial population
        for (int i = 0; i < getPopulationSize(); i++) {
            final NEATGenome genome = getGenomeFactory().factor(rnd, this,
                    super.getInputCount(), super.getOutputCount(),
                    super.getInitialConnectionDensity());
            CoEvolveEquiInitGenome g = (CoEvolveEquiInitGenome) genome;
            //only indirect
            /*if(!g.getDirectLinksExpressed() && g.getIndirectLinksExpressed()){
                indirectSpecies.add(genome);
			}
			//only direct
			else if(g.getDirectLinksExpressed() && !g.getIndirectLinksExpressed()){
				directSpecies.add(genome);
			}
			//both
			else {*/
            mixedSpecies.add(genome);
            //}
        }
        //indirectSpecies.setLeader(indirectSpecies.getMembers().get(0));
        //directSpecies.setLeader(directSpecies.getMembers().get(0));
        mixedSpecies.setLeader(mixedSpecies.getMembers().get(0));


        //getSpecies().add(indirectSpecies);
        //getSpecies().add(directSpecies);
        getSpecies().add(mixedSpecies);

        // create initial innovations
        setInnovations(new NEATInnovationList(this));
    }

}