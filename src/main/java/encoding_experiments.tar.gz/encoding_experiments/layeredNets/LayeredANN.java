package encoding_experiments.layeredNets;

import org.encog.ml.MLError;
import org.encog.ml.MLRegression;
import org.encog.ml.data.MLData;
import org.encog.ml.data.MLDataSet;
import org.encog.ml.data.basic.BasicMLData;
import org.encog.util.simple.EncogUtility;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;

public class LayeredANN implements MLRegression, MLError, Serializable {

    private ANNLayer[] layers;
    private final int inputCount, outputCount;

    private boolean biasFirst;

    public LayeredANN(ANNLayer[] layers, boolean biasFirst) {
        this.layers = layers;
        this.biasFirst = biasFirst;
        //-1 because of the bias neuron (final position of the layer)
        this.inputCount = layers[0].getNeurons().size() - 1;
        this.outputCount = layers[layers.length - 1].getNeurons().size();
    }

    @Override
    public int getInputCount() {
        return this.inputCount;
    }

    @Override
    public int getOutputCount() {
        return this.outputCount;
    }

    @Override
    public double calculateError(final MLDataSet data) {
        return EncogUtility.calculateRegressionError(this, data);
    }

    public double[] compute(final double[] inputValues) {

        ArrayList<ANNNeuron> inputNeurons = layers[0].getNeurons();

        //inputs
        int biasIndex, biasOffset;
        if (biasFirst) {
            biasIndex = 0;
            biasOffset = 1;
        } else {
            biasIndex = this.inputCount;
            biasOffset = 0;
        }

        try {
            for (int i = 0; i < inputValues.length; i++) {
                inputNeurons.get(i + biasOffset).setActivationValue(inputValues[i]);
            }
            //bias
            inputNeurons.get(biasIndex).setActivationValue(1.0);
        } catch (ArrayIndexOutOfBoundsException e) {
            //System.out.println("c1 - n");
            /*System.out.println("inputs: " + this.getInputCount());
            System.out.println("outputs: " + this.getOutputCount());
			for(int i = 0; i < this.layers[1].getNeurons().size(); i++){
				System.out.println("n: " + this.layers[1].getNeurons().get(i).getId()
						+ " ; " + this.layers[1].getNeurons().get(i).getType());
			}
			System.exit(0);*/
        } catch (IndexOutOfBoundsException e) {
            //System.out.println("c1 - n2");
        }
        //loop
        for (ANNLayer layer : layers)
            layer.step();

        //return output
        double[] outputValues = layers[layers.length - 1].getNeuronActivations();

        return outputValues;
    }

    @Override
    public MLData compute(final MLData input) {
        double[] inputValues = input.getData();

        double[] outputValues = this.compute(inputValues);

        final MLData result = new BasicMLData(this.outputCount);
        result.setData(outputValues);

        return result;
    }

    public int getNumberOfLayers() {
        return this.layers.length;
    }

    public ANNLayer getLayer(int index) {
        return this.layers[index];
    }

    public ArrayList<ANNSynapse> getAllSynapses() {
        ArrayList<ANNSynapse> synapses = new ArrayList<ANNSynapse>();
        for (ANNLayer l : this.layers) {
            for (ANNNeuron n : l.getNeurons()) {
                synapses.addAll(n.getIncomingConnections());
            }
        }
        return synapses;
    }

    public ArrayList<ANNNeuron> getAllNeurons() {
        ArrayList<ANNNeuron> neurons = new ArrayList<ANNNeuron>();
        for (ANNLayer l : this.layers) {
            neurons.addAll(l.getNeurons());
        }
        return neurons;
    }

    public boolean getBiasFirst() {
        return this.biasFirst;
    }

    public int getBiasId() {
        if (this.biasFirst)
            return 0;
        return (int) this.layers[0].getNeurons().get(inputCount).getId();
    }

    public void reset() {
        for (ANNLayer l : this.layers) {
            for (ANNNeuron n : l.getNeurons()) {
                n.reset();
            }
        }
    }

    public LayeredANN copy() {
        return this.createCopyNet(this.getAllNeurons(), this.getAllSynapses());
    }

    protected LayeredANN createCopyNet(ArrayList<ANNNeuron> originalNeurons,
                                       ArrayList<ANNSynapse> originalSynapses) {
        //first, copy all neurons and synapses, then put them in the right place
        HashMap<Long, ANNNeuron> copyNeurons = new HashMap<Long, ANNNeuron>();
        HashMap<Long, ANNSynapse> copySynapse = new HashMap<Long, ANNSynapse>();

        for (ANNNeuron neuron : originalNeurons) {
            copyNeurons.put(neuron.getId(), neuron.shallowCopy());
        }

        for (ANNSynapse synapse : originalSynapses) {
            copySynapse.put(synapse.getInnovationNumber(), synapse.copy());
        }

        ANNLayer[] copyLayers = new ANNLayer[this.getNumberOfLayers()];

        for (int i = 0; i < this.getNumberOfLayers(); i++) {
            ANNLayer originalLayer = this.getLayer(i);

            copyLayers[i] = recreateLayer(originalLayer, copyNeurons, copySynapse);
        }


        return new LayeredANN(copyLayers, this.getBiasFirst());
    }

    private ANNLayer recreateLayer(ANNLayer originalLayer,
                                   HashMap<Long, ANNNeuron> copyNeurons,
                                   HashMap<Long, ANNSynapse> copySynapses) {
        ArrayList<ANNNeuron> originalLayerNeurons = originalLayer.getNeurons();
        ArrayList<ANNNeuron> copyLayerNeurons = new ArrayList<ANNNeuron>(originalLayerNeurons.size());

        //start assembling the pieces
        for (ANNNeuron neuron : originalLayerNeurons) {
            //find the right *copy neuron*
            ANNNeuron copyNeuron = copyNeurons.get(neuron.getId());

            //Search for and add the incoming neurons and incoming connections
            //for each incoming synapse, there is a corresponding incoming neuron
            for (int i = 0; i < neuron.getIncomingConnections().size(); i++) {
                ANNSynapse originalIncSynapse = neuron.getIncomingConnections().get(i);
                ANNNeuron originalIncNeuron = neuron.getIncomingNeurons().get(i);

                //add to the copy neuron
                copyNeuron.addIncomingNeuron(copyNeurons.get(originalIncNeuron.getId()));
                copyNeuron.addIncomingSynapse(copySynapses.get(originalIncSynapse.getInnovationNumber()));
            }
            copyLayerNeurons.add(copyNeuron);
        }
        return new ANNLayer(originalLayer.getLayerId(), copyLayerNeurons);
    }

}
