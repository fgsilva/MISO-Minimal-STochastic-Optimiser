package encoding_experiments;


import encoding_experiments.coevolve.CoEvolveEquiInitCODEC;
import encoding_experiments.coevolve.CoEvolveEquiInitGenome;
import encoding_experiments.coevolve.FactoryCoEvolveEquiInitGenome;
import encoding_experiments.functions.CPPNFunctionBuilder;
import encoding_experiments.layeredNets.ANNSynapse;
import encoding_experiments.layeredNets.LayeredANN;
import encoding_experiments.layeredNets.LayeredNEATCODEC;
import org.encog.engine.network.activation.ActivationFunction;
import org.encog.engine.network.activation.ActivationSteepenedSigmoid;
import org.encog.ml.CalculateScore;
import org.encog.ml.ea.codec.GeneticCODEC;
import org.encog.ml.ea.genome.Genome;
import org.encog.ml.ea.population.Population;
import org.encog.ml.ea.species.Species;
import org.encog.ml.ea.train.EvolutionaryAlgorithm;
import org.encog.ml.ea.train.basic.TrainEA;
import org.encog.neural.hyperneat.substrate.Substrate;
import org.encog.neural.neat.NEATNeuronType;
import org.encog.neural.neat.NEATPopulation;
import org.encog.neural.neat.PersistNEATPopulation;
import org.encog.neural.neat.training.NEATGenome;
import org.encog.neural.neat.training.NEATLinkGene;
import org.encog.neural.neat.training.NEATNeuronGene;
import org.encog.persist.EncogWriteHelper;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

public class ExtendedNEATTask {

    /****/
    private final double SAVE_GEN_FITNESS_RATE = 5;
    private final double SAVE_POP_GENOME_STRUCTURE = 10;

    private final int ACTIVATION_CYCLES;
    private final String OUTPUT_FOLDER;
    private final CalculateScore SCORE;

    private HashMap<Integer, double[]> fitnessScores;
    private double bestScore = Double.MIN_VALUE;
    private String fitnessScoreFile;

    private final boolean isHyperNEAT;
    private final boolean executeEvolHybrid;
    private final String hybridType;

    private final SpeciesStats speciesStats = new SpeciesStats();

    public ExtendedNEATTask(String outputFolder, CalculateScore score, String fitnessScoreFile, int activationCycles,
                            boolean isHyperNEAT, boolean executeEvolHybrid, String hybridType) {
        this.OUTPUT_FOLDER = outputFolder;
        this.SCORE = score;
        this.fitnessScores = new HashMap<Integer, double[]>();
        this.fitnessScoreFile = fitnessScoreFile;
        this.ACTIVATION_CYCLES = activationCycles;
        this.isHyperNEAT = isHyperNEAT;
        this.executeEvolHybrid = executeEvolHybrid;
        this.hybridType = new String(hybridType);
    }


    public void execute(Properties prop) {
        /* EA */
        int generations = Integer.valueOf(prop.getProperty("generations"));
        int populationSize = Integer.valueOf(prop.getProperty("populationSize"));

        //System.out.println("execute switch: " + this.hybridType);

        //not hybrid encoding
        if (!this.executeEvolHybrid) {

            if (this.isHyperNEAT) {
                System.out.println("HYPERNEAT");
                executeHyperNEAT(prop, generations, populationSize);
            }
            else {
                System.out.println("NEAT");
                executeNEAT(prop, generations, populationSize);
            }
        }
        //
        else {
            System.out.println("HYBRID: " + this.hybridType);

            switch (this.hybridType) {
                case "switch":
                    executeSwitch(prop, generations, populationSize);
                    break;
                case "combined-equi-init":
                    executeCombinedEquiInit(prop, generations, populationSize);
                    break;
            }
        }
    }


    private void executeCombinedEquiInit(Properties prop, int generations,
                                         int populationSize) {
        boolean useBias = Boolean.valueOf(prop.getProperty("useBias"));

        double netsWeightRange = Double.valueOf(prop.getProperty("netsWeightRange"));

        double minWeight = Double.valueOf(prop.getProperty("minANNWeight"));
        boolean useRecurrence = Boolean.valueOf(prop.getProperty("useRecurrence"));

        boolean useTanh = Boolean.valueOf(prop.getProperty("useTanh", "false"));

        int hiddenNodes = Integer.valueOf(prop.getProperty("hidden-nodes", "0"));

        ExtendedNEATPopulation pop = constructCombinedEquiInitPopulation(prop, populationSize, hiddenNodes);

        /** setup factory **/
        pop.setGenomeFactory(new FactoryCoEvolveEquiInitGenome(hiddenNodes));

        /** create initial random population**/
        pop.resetEquiInitCombined();

        boolean addStructureDirect = Boolean.valueOf(prop.getProperty("addStructureDirect"));
        //System.out.println("add direct: " + addStructureDirect);
        /** setup EA **/
        TrainEA trainer = ExtendedNEATUtil.constructCombinedEquiInitTrainer(prop, pop, SCORE, true, addStructureDirect);


        GeneticCODEC c;
        if (hiddenNodes <= 0) {
            c = new CoEvolveEquiInitCODEC(
                    minWeight, netsWeightRange, useBias, useRecurrence, useTanh);
        } else {
            c = new MultiLayerCoEvolveCODEC(minWeight, netsWeightRange, useBias, useRecurrence, useTanh);
        }
        pop.setCODEC(c);
        trainer.setCODEC(c);

        /** save **/
        boolean saveOnlyFinalPop = Boolean.valueOf(prop.getProperty("onlySaveFinalPop"));

        /** execute **/
        execute(trainer, 1, generations, saveOnlyFinalPop);

    }


    private ExtendedNEATPopulation constructCombinedEquiInitPopulation(
            Properties prop, int populationSize, int hiddenNodes) {
        /** cppn and substrate **/
        int inputNodesX = Integer.valueOf(prop.getProperty("numInputNodesX"));
        int inputNodesY = Integer.valueOf(prop.getProperty("numInputNodesY"));
        int outputNodesX = Integer.valueOf(prop.getProperty("numOutputNodesX"));
        int outputNodesY = Integer.valueOf(prop.getProperty("numOutputNodesY"));

        int cppnInputs = Integer.valueOf(prop.getProperty("cppnInputs"));
        int cppnOutputs = Integer.valueOf(prop.getProperty("cppnOutputs"));
        double netsWeightRange = Double.valueOf(prop.getProperty("netsWeightRange"));
        double netsConnectivity = Double.valueOf(prop.getProperty("netsInitialConnectivity"));

        /** setup substrate and population **/
        Substrate substrate;
        if (hiddenNodes <= 0) {
            substrate = ExtendedSubstrateFactory.
                    createSandwichSubstrate(inputNodesX, inputNodesY, outputNodesX, outputNodesY);
        } else {
            substrate = ExtendedSubstrateFactory.createMultiLayerSubstrate(inputNodesX, inputNodesY,
                    outputNodesX, outputNodesY, hiddenNodes);
        }
        //setup genome
        CoEvolveEquiInitGenome.setAnnInputCount(inputNodesX * inputNodesY);
        CoEvolveEquiInitGenome.setAnnOutputCount(outputNodesX * outputNodesY);
        CoEvolveEquiInitGenome.setUseBias(true);

        ExtendedNEATPopulation pop = new ExtendedNEATPopulation(substrate,
                populationSize, cppnInputs, cppnOutputs,
                netsWeightRange,
                ACTIVATION_CYCLES, new CPPNFunctionBuilder(), netsConnectivity);


        return pop;
    }


	/*private ExtendedNEATPopulation constructHybridCombinedTPopulation(
            Properties prop, int populationSize) {
		/** cppn and substrate **/
	/*int inputNodesX = Integer.valueOf(prop.getProperty("numInputNodesX"));
		int inputNodesY = Integer.valueOf(prop.getProperty("numInputNodesY"));
		int outputNodesX = Integer.valueOf(prop.getProperty("numOutputNodesX"));
		int outputNodesY = Integer.valueOf(prop.getProperty("numOutputNodesY"));

		int cppnInputs = Integer.valueOf(prop.getProperty("cppnInputs"));
		int cppnOutputs = Integer.valueOf(prop.getProperty("cppnOutputs"));
		double netsWeightRange = Double.valueOf(prop.getProperty("netsWeightRange"));
		double netsConnectivity = Double.valueOf(prop.getProperty("netsInitialConnectivity"));


		/** setup substrate and population **/
	/*Substrate substrate = ExtendedSubstrateFactory.
				createSandwichSubstrate(inputNodesX, inputNodesY, outputNodesX, outputNodesY);

		//setup genome
		CoEvolvingHybridGenome.setAnnInputCount(inputNodesX * inputNodesY);
		CoEvolvingHybridGenome.setAnnOutputCount(outputNodesX * outputNodesY);
		CoEvolvingHybridGenome.setUseBias(false);

		ExtendedNEATPopulation pop = new ExtendedNEATPopulation(substrate, 
				populationSize, cppnInputs, cppnOutputs, 
				netsWeightRange, 
				ACTIVATION_CYCLES, new CPPNFunctionBuilder(), netsConnectivity);


		return pop;
	}*/


    private void executeSwitch(Properties prop, int generations,
                               int populationSize) {

        int switchPoint = Integer.valueOf(prop.getProperty("switch-point"));
        boolean addStructureDirect = Boolean.valueOf(prop.getProperty("addStructureDirect"));
        boolean useBias = Boolean.valueOf(prop.getProperty("useBias"));

        /** setup EA **/
        /** setup hyperneat trainer **/
        TrainEA trainer = setupHyperNEATTrainer(prop, populationSize);

        /** save **/
        boolean saveOnlyFinalPop = Boolean.valueOf(prop.getProperty("onlySaveFinalPop"));

        //execute with hyperneat
        this.execute(trainer, 1, switchPoint, saveOnlyFinalPop);

        /** prepare direct ready to execute **/
		/*TrainEA directTrainer = loadDirectEncTrainerWithPop(trainer, 
				trainer.getPopulation().flatten(), 
				prop, populationSize, useBias);
		//System.out.println("loaded");
		//update best genome


		//System.out.println("best set");

		//System.out.println("\ngoing to execute direct @ gen: " + gen);*/
        TrainEA directTrainer = this.setupNEATTrainer(addStructureDirect, prop,
                populationSize, getDirectPopulation(trainer, useBias, prop));
        directTrainer.setIteration(switchPoint + 1);

        //this.loadDirectPopulation(trainer, useBias, prop, directTrainer);


        //replacePopulations(directTrainer, directPopulation);

        //List<Genome> genomes = directTrainer.getPopulation().flatten();


		/*directTrainer.getSpeciation().performSpeciation(directTrainer.getPopulation().flatten());
		directTrainer.getPopulation().purgeInvalidGenomes();*/

        this.execute(directTrainer, switchPoint + 1, generations, saveOnlyFinalPop);

    }

    private ArrayList<NEATGenome> getDirectPopulation(
            TrainEA indirectTrainer, boolean useBias, Properties prop) {
        List<Genome> indirectGenomes = indirectTrainer.getPopulation().flatten();

        ArrayList<NEATGenome> tempList = new ArrayList<NEATGenome>();
        for (Genome indirect : indirectGenomes) {
            LayeredANN net = (LayeredANN) indirectTrainer.getCODEC().decode(indirect);
            NEATGenome direct = translateNetToGenome(net, useBias, prop);
            direct.setScore(indirect.getScore());
            //direct.setAdjustedScore(ind.getScore());
            direct.setBirthGeneration(indirect.getBirthGeneration());

            tempList.add(direct);
        }

        return tempList;
    }

    private NEATGenome translateNetToGenome(LayeredANN net, boolean useBias, Properties prop) {
        int realInputCount = Integer.valueOf(prop.getProperty("numInputNodesX"))
                * Integer.valueOf(prop.getProperty("numInputNodesY"));
        int realOutputCount = Integer.valueOf(prop.getProperty("numOutputNodesX"))
                * Integer.valueOf(prop.getProperty("numOutputNodesY"));


        int inputCount = net.getInputCount(), outputCount = net.getOutputCount();
        if (!useBias) {
            inputCount++;
        }
        //purge invalid genomes
        if (inputCount != realInputCount || outputCount != realOutputCount) {
            return null;
        }
        int hiddenNodes = Integer.valueOf(prop.getProperty("hidden-nodes", "0"));

        if (hiddenNodes <= 0) {
            return perceptronNetGenome(net, useBias, prop, inputCount, outputCount);
        } else {
            return multiLayerNetGenome(net, useBias, prop, inputCount, outputCount, hiddenNodes);
        }
    }


    private NEATGenome multiLayerNetGenome(LayeredANN net, boolean useBias,
                                           Properties prop, int inputCount, int outputCount, int hiddenNodes) {
        ActivationFunction af = new ActivationSteepenedSigmoid();

        int innovationID = 0;

        ArrayList<NEATNeuronGene> inputs = new ArrayList<NEATNeuronGene>();
        ArrayList<NEATNeuronGene> hidden = new ArrayList<NEATNeuronGene>();
        ArrayList<NEATNeuronGene> outputs = new ArrayList<NEATNeuronGene>();
        ArrayList<NEATLinkGene> links = new ArrayList<NEATLinkGene>();

        //bias
        NEATNeuronGene biasGene = new NEATNeuronGene(NEATNeuronType.Bias, af,
                innovationID, innovationID);
        innovationID++;
        inputs.add(biasGene);

        //other inputs
        for (int i = 0; i < inputCount; i++) {
            NEATNeuronGene gene = new NEATNeuronGene(NEATNeuronType.Input, af,
                    innovationID, innovationID);
            innovationID++;
            inputs.add(gene);
        }

        //hidden
        for (int i = 0; i < hiddenNodes; i++) {
            NEATNeuronGene gene = new NEATNeuronGene(NEATNeuronType.Hidden, af,
                    innovationID, innovationID);
            innovationID++;
            hidden.add(gene);
        }

        //outputs
        for (int i = 0; i < outputCount; i++) {
            NEATNeuronGene gene = new NEATNeuronGene(NEATNeuronType.Output, af,
                    innovationID, innovationID);
            innovationID++;
            outputs.add(gene);
        }

        //bias to hidden and outputs
        NEATNeuronGene bias = inputs.get(0);
        //biased nodes so far
        ArrayList<NEATNeuronGene> biasedNodes = new ArrayList<NEATNeuronGene>();
        biasedNodes.addAll(outputs);
        biasedNodes.addAll(hidden);
        for (NEATNeuronGene biased : biasedNodes) {
            long fromID = bias.getId();
            long toID = biased.getId();
            double w = getNetWeightOfLink(fromID, toID, net);
            NEATLinkGene gene = new NEATLinkGene(fromID, toID, true, innovationID++, w);
            links.add(gene);
        }

        //check for recurrence in hidden and output nodes (biasedNodes)
        boolean useRecurrence = Boolean.valueOf(prop.getProperty("useRecurrence"));
        if (useRecurrence) {
            for (NEATNeuronGene biased : biasedNodes) {
                long fromID = biased.getId();
                long toID = biased.getId();
                double w = getNetWeightOfLink(fromID, toID, net);
                NEATLinkGene gene = new NEATLinkGene(fromID, toID, true, innovationID++, w);
                links.add(gene);
            }
        }


        //inputs to hidden
        for (int i = 1; i < inputs.size(); i++) {
            NEATNeuronGene input = inputs.get(i);
            for (NEATNeuronGene h : hidden) {
                long fromID = input.getId();
                long toID = h.getId();
                double w = getNetWeightOfLink(fromID, toID, net);
                NEATLinkGene gene = new NEATLinkGene(fromID, toID, true, innovationID++, w);
                links.add(gene);
            }
        }

        //hidden to output
        for (NEATNeuronGene h : hidden) {
            for (NEATNeuronGene o : outputs) {
                long fromID = h.getId();
                long toID = o.getId();
                double w = getNetWeightOfLink(fromID, toID, net);
                NEATLinkGene gene = new NEATLinkGene(fromID, toID, true, innovationID++, w);
                links.add(gene);
            }
        }

        //stores all neurons a list
        ArrayList<NEATNeuronGene> nodes = new ArrayList<NEATNeuronGene>();
        nodes.addAll(inputs);
        nodes.addAll(outputs);
        nodes.addAll(hidden);

        return new NEATGenome(nodes, links, inputCount, outputCount);
    }


    private NEATGenome perceptronNetGenome(LayeredANN net, boolean useBias,
                                           Properties prop, int inputCount, int outputCount) {
        // get the activation function
        ActivationFunction af = new ActivationSteepenedSigmoid();
        ArrayList<NEATNeuronGene> neuronsList = new ArrayList<NEATNeuronGene>();
        ArrayList<NEATLinkGene> linksList = new ArrayList<NEATLinkGene>();

        // first bias
        int innovationID = 0;
        NEATNeuronGene biasGene = new NEATNeuronGene(NEATNeuronType.Bias, af,
                0, innovationID++);
        neuronsList.add(biasGene);

        // then inputs

        for (int i = 0; i < inputCount; i++) {
            NEATNeuronGene gene = new NEATNeuronGene(NEATNeuronType.Input, af,
                    i + 1, innovationID++);
            neuronsList.add(gene);
        }

        // then outputs

        for (int i = 0; i < outputCount; i++) {
            NEATNeuronGene gene = new NEATNeuronGene(NEATNeuronType.Output, af,
                    i + inputCount + 1, innovationID++);
            neuronsList.add(gene);
        }


        // and now links
        for (int i = 0; i < inputCount + 1; i++) {
            for (int j = 0; j < outputCount; j++) {
                long fromID = neuronsList.get(i).getId();
                long toID = neuronsList.get(inputCount + j + 1)
                        .getId();

                //long newFrom = directToIndirect.containsKey(fromID) ? directToIndirect.get(fromID) : fromID;
                //long newTo = directToIndirect.containsKey(toID) ? directToIndirect.get(toID) : toID;
                //if(useBias || (!useBias && fromID != biasId)){
                double w = getNetWeightOfLink(fromID, toID, net);
                //double w = link.getWeight();
                NEATLinkGene gene = new NEATLinkGene(fromID, toID, true, innovationID++, w);
                linksList.add(gene);
                //}
            }
        }

        return new NEATGenome(neuronsList, linksList, inputCount, outputCount);
    }


    private double getNetWeightOfLink(long fromID, long toID, LayeredANN net) {


        for (ANNSynapse link : net.getAllSynapses()) {
            if (link.getFromNeuron() == fromID && link.getToNeuron() == toID)
                return link.getWeight();
        }

        //System.out.println(fromID + " => " + toID + "; " + newFrom + " => " + newTo + " ; " + net.getInputCount());
        //System.out.println("======================");
		/*for(ANNSynapse link : net.getAllSynapses()){
			System.out.println(link.getFromNeuron() + " => " + link.getToNeuron());
		}*/
        //System.out.println("crap "  + fromID + " ; " + toID);
        //System.exit(0);
        return 0;
    }



	/*private void recordSwitchPoint(int gen) {
		BufferedWriter writer;
		try {
			writer = new BufferedWriter(new FileWriter(this.OUTPUT_FOLDER + "switch_point_gen.txt"));
			writer.write(String.valueOf(gen));
			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}*/


    private void executeHyperNEAT(Properties prop, int generations,
                                  int populationSize) {

        /** setup hyperneat trainer **/
        TrainEA trainer = setupHyperNEATTrainer(prop, populationSize);

        /** save **/
        boolean saveOnlyFinalPop = Boolean.valueOf(prop.getProperty("onlySaveFinalPop"));

        /** execute **/
        execute(trainer, 1, generations, saveOnlyFinalPop);
    }


    private TrainEA setupHyperNEATTrainer(Properties prop, int populationSize) {
        double netsWeightRange = Double.valueOf(prop.getProperty("netsWeightRange"));

        double minWeight = Double.valueOf(prop.getProperty("minANNWeight"));
        boolean useBias = Boolean.valueOf(prop.getProperty("useBias"));
        boolean useRecurrence = Boolean.valueOf(prop.getProperty("useRecurrence"));

        boolean useTanh = Boolean.valueOf(prop.getProperty("useTanh", "false"));

        int hiddenNodes = Integer.valueOf(prop.getProperty("hidden-nodes", "0"));
        ExtendedNEATPopulation pop = constructHyperNEATPopulation(prop, populationSize, hiddenNodes);


        /** setup EA **/
        TrainEA trainer = ExtendedNEATUtil.constructTrainer(prop, pop, SCORE, true);
        GeneticCODEC c;
        if (hiddenNodes <= 0) {
            c = new BasicSubstrateHyperNEATCODEC(
                    minWeight, netsWeightRange, useBias, useRecurrence, useTanh);
        } else {
            c = new MultiLayerSubstrateHyperNEATCODEC(minWeight, netsWeightRange, useBias, useRecurrence, useTanh);
        }
        pop.setCODEC(c);
        trainer.setCODEC(c);

        return trainer;
    }


    private ExtendedNEATPopulation constructHyperNEATPopulation(Properties prop, int populationSize, int hiddenNodes) {
        /** cppn and substrate **/
        int inputNodesX = Integer.valueOf(prop.getProperty("numInputNodesX"));
        int inputNodesY = Integer.valueOf(prop.getProperty("numInputNodesY"));
        int outputNodesX = Integer.valueOf(prop.getProperty("numOutputNodesX"));
        int outputNodesY = Integer.valueOf(prop.getProperty("numOutputNodesY"));

        int cppnInputs = Integer.valueOf(prop.getProperty("cppnInputs"));
        int cppnOutputs = Integer.valueOf(prop.getProperty("cppnOutputs"));
        double netsWeightRange = Double.valueOf(prop.getProperty("netsWeightRange"));
        double netsConnectivity = Double.valueOf(prop.getProperty("netsInitialConnectivity"));


        /** setup substrate and population **/
        Substrate substrate;
        if (hiddenNodes <= 0) {
            substrate = ExtendedSubstrateFactory.
                    createSandwichSubstrate(inputNodesX, inputNodesY, outputNodesX, outputNodesY);
        } else {
            substrate = ExtendedSubstrateFactory.createMultiLayerSubstrate(inputNodesX, inputNodesY,
                    outputNodesX, outputNodesY, hiddenNodes);
        }
        ExtendedNEATPopulation pop = new ExtendedNEATPopulation(substrate,
                populationSize, cppnInputs, cppnOutputs,
                netsWeightRange,
                ACTIVATION_CYCLES, new CPPNFunctionBuilder(), netsConnectivity);

        /** create initial random population**/
        pop.reset();

        return pop;
    }


    private void executeNEAT(Properties prop, int generations,
                             int populationSize) {

        /** save **/
        boolean saveOnlyFinalPop = Boolean.valueOf(prop.getProperty("onlySaveFinalPop"));

        /**add new structure or only optimise connection weights**/
        boolean addStructure = Boolean.valueOf(prop.getProperty("addStructure", "false"));

        TrainEA neatTrainer = setupNEATTrainer(addStructure, prop, populationSize, null);


        execute(neatTrainer, 1, generations, saveOnlyFinalPop);
    }


    private TrainEA setupNEATTrainer(boolean addStructure, Properties prop,
                                     int populationSize, ArrayList<NEATGenome> population) {
        int inputNodesX = Integer.valueOf(prop.getProperty("numInputNodesX"));
        int inputNodesY = Integer.valueOf(prop.getProperty("numInputNodesY"));
        int outputNodesX = Integer.valueOf(prop.getProperty("numOutputNodesX"));
        int outputNodesY = Integer.valueOf(prop.getProperty("numOutputNodesY"));

        int numberInputs = inputNodesX * inputNodesY, numberOutputs = outputNodesX * outputNodesY;


        double netsWeightRange = Double.valueOf(prop.getProperty("netsWeightRange"));
        double netsConnectivity = Double.valueOf(prop.getProperty("netsInitialConnectivity"));

        boolean useTanh = Boolean.valueOf(prop.getProperty("useTanh", "false"));

        boolean biasFirst = false;
        /** setup population **/
        ExtendedNEATPopulation pop = new ExtendedNEATPopulation(populationSize, numberInputs, numberOutputs,
                netsWeightRange, ACTIVATION_CYCLES, netsConnectivity, useTanh);

        /** create initial random population or load one**/
        if (population == null)
            pop.reset();
        else
            pop.reset(population);

        /** setup EA **/
        TrainEA trainer = ExtendedNEATUtil.constructTrainer(prop,
                pop, SCORE, addStructure);
        GeneticCODEC c = new LayeredNEATCODEC(biasFirst);
        pop.setCODEC(c);
        trainer.setCODEC(c);

        return trainer;
    }


    private void execute(EvolutionaryAlgorithm trainer, int generationFrom, int generationsTo,
                         boolean saveOnlyFinalPop) {
        //System.out.println("start exec");
        try {
            recordPopulationInfo(0, trainer.getPopulation());
        } catch (IOException e) {
            e.printStackTrace();
        }


        for (int gen = generationFrom; gen <= generationsTo; gen++) {
         //   System.out.println("gen: " + gen);
            //System.out.println("\n" + gen);
            trainer.iteration();
            /*if (gen % SAVE_GEN_FITNESS_RATE == 0 || gen == 1) {
                recordFitnessScores(gen, trainer.getPopulation());
                recordSpeciesStats(gen, trainer.getPopulation());
            }
            if (gen % SAVE_POP_GENOME_STRUCTURE == 0) {
                NEATPopulation pop = (NEATPopulation) trainer.getPopulation();
                List<Genome> genomes = pop.flatten();
                if (genomes.get(0) instanceof CoEvolveEquiInitGenome) {
                    try {
                        saveCoEvolvingEquiInitPopulation(genomes, gen, pop, false);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
            if (!saveOnlyFinalPop || gen == generationsTo) {
                try {
                    recordPopulationInfo(gen, trainer.getPopulation());
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }*/

			if(gen % 10 == 0){
				System.out.println("gen " + gen + " : " + trainer.getBestGenome().getScore());
			}
        }
        trainer.finishTraining();

        try {
            saveFitnessScores(this.OUTPUT_FOLDER + this.fitnessScoreFile);
            speciesStats.flushSpeciesStats(this.OUTPUT_FOLDER);
        } catch (IOException e) {
            e.printStackTrace();
        }
        speciesStats.clear();
    }


    private void recordSpeciesStats(int gen, Population population) {
        speciesStats.recordInfo(gen, population);
    }


    private void saveFitnessScores(String outputFile) throws IOException {
        ArrayList<Integer> generations = new ArrayList<Integer>(this.fitnessScores.size());
        generations.addAll(this.fitnessScores.keySet());
        Collections.sort(generations);

        BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile));
        writer.write("generation scores");
        writer.newLine();

        for (int gen : generations) {
            StringBuilder builder = new StringBuilder();
            double[] scores = this.fitnessScores.get(gen);
            builder.append(String.valueOf(gen));
            for (double score : scores) {
                builder.append(" " + String.format("%.3f", score));
            }
            writer.write(builder.toString());
            writer.newLine();
        }
        writer.close();
    }


    private void recordPopulationInfo(int gen, Population population) throws IOException {
        PersistNEATPopulation persist = new PersistNEATPopulation();
        FileOutputStream fileOut = new FileOutputStream(this.OUTPUT_FOLDER + "population_gen_" + gen);
        persist.save(fileOut, population);
        fileOut.close();

        List<Genome> genomes = population.flatten();
        if (genomes.get(0) instanceof CoEvolveEquiInitGenome) {
            saveCoEvolvingEquiInitPopulation(genomes, gen, (NEATPopulation) population, true);
        }
		/*else if(genomes.get(0) instanceof CoEvolvingIncrementalGenome){
			saveCoEvolvingIncrementalPopulationInfo(genomes, gen);
		}
		/*FileOutputStream fileOut = new FileOutputStream(this.OUTPUT_FOLDER + "population_gen_" + gen);
		GZIPOutputStream gzipOut = new GZIPOutputStream(fileOut);
		ObjectOutputStream out = new ObjectOutputStream(gzipOut);
		out.writeObject(population);
		out.close();*/
    }


    private void saveCoEvolvingEquiInitPopulation(List<Genome> genomes, int gen,
                                                  NEATPopulation pop, boolean writeComplement) throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter(this.OUTPUT_FOLDER + "enabled_fit_gen_" + gen));
        writer.write("score use-indirect use-direct direct-expression-links");
        writer.newLine();
        for (Genome g : genomes) {
            CoEvolveEquiInitGenome inc = (CoEvolveEquiInitGenome) g;
            boolean useIndirect = inc.getIndirectLinksExpressed();
            boolean useDirect = inc.getDirectLinksExpressed();
            int directCount = useDirect ? inc.getDirectExpressedLinksCount() : -1;

            writer.write(inc.getScore() + " " + useIndirect +
                    " " + useDirect + " " + directCount);
            writer.newLine();
        }
        writer.close();

        if (writeComplement) {
            /**
             * now write the remaining.
             */
            FileOutputStream fileOut = new FileOutputStream(this.OUTPUT_FOLDER +
                    "complement_population_gen_" + gen);
            final EncogWriteHelper persist = new EncogWriteHelper(fileOut);

            // make sure the best species goes first
            final Species bestSpecies = pop.determineBestSpecies();
            if (bestSpecies != null) {
                saveSpecies(persist, bestSpecies);
            }

            // now write the other species, other than the best one
            for (final Species species : pop.getSpecies()) {
                if (species != bestSpecies) {
                    saveSpecies(persist, species);
                }
            }
            persist.flush();
            fileOut.close();
        }
    }


    private void saveSpecies(final EncogWriteHelper out, final Species species) {
        out.addColumn("s");
        out.addColumn(species.getAge());
        out.addColumn(species.getBestScore());
        out.addColumn(species.getGensNoImprovement());
        out.writeLine();

        for (final Genome genome : species.getMembers()) {
            final CoEvolveEquiInitGenome master = (CoEvolveEquiInitGenome) genome;
            final NEATGenome neatGenome = master.getDirectGenome();
            out.addColumn("g");
            out.addColumn(master.getIndirectLinksExpressed());
            out.addColumn(master.getDirectLinksExpressed());
            out.addColumn(master.getDirectExpressedLinksCount());

			/*out.addColumn(neatGenome.getAdjustedScore());
			out.addColumn(neatGenome.getScore());
			out.addColumn(neatGenome.getBirthGeneration());*/
            out.writeLine();

            if (neatGenome != null) {

                for (final NEATNeuronGene neatNeuronGene : neatGenome.getNeuronsChromosome()) {
                    out.addColumn("n");
                    out.addColumn(neatNeuronGene.getId());
                    //out.addColumn(neatNeuronGene.getActivationFunction());
                    out.addColumn(PersistNEATPopulation
                            .neuronTypeToString(neatNeuronGene.getNeuronType()));
                    out.addColumn(neatNeuronGene.getInnovationId());
                    out.writeLine();
                }
                for (final NEATLinkGene neatLinkGene : neatGenome
                        .getLinksChromosome()) {
                    out.addColumn("l");
                    out.addColumn(neatLinkGene.getId());
                    out.addColumn(neatLinkGene.isEnabled());
                    out.addColumn(neatLinkGene.getFromNeuronID());
                    out.addColumn(neatLinkGene.getToNeuronID());
                    out.addColumn(neatLinkGene.getWeight());
                    out.addColumn(neatLinkGene.getInnovationId());
                    out.writeLine();
                }
            }
        }
    }



	/*private void saveCoEvolvingIncrementalPopulationInfo(List<Genome> genomes, int gen) throws IOException {
		BufferedWriter writer = new BufferedWriter(new FileWriter(this.OUTPUT_FOLDER + "enabled_fit_gen_" + gen));
		writer.write("score adjusted-score direct-expression-links");
		writer.newLine();
		for(Genome g : genomes){
			CoEvolvingIncrementalGenome inc = (CoEvolvingIncrementalGenome) g;
			int directLinks = inc.getDirectExpressedLinks();
			writer.write(inc.getScore() + " " + inc.getAdjustedScore() + " " + directLinks);
			writer.newLine();
		}
		writer.close();
	}*/


    private void recordFitnessScores(int gen, Population population) {
        List<Genome> genomes = population.flatten();
        double[] fitnessScores = new double[genomes.size()];
        int index = 0;
        for (Genome g : genomes) {
            this.bestScore = Math.max(g.getScore(), bestScore);
            fitnessScores[index] = g.getScore();
            index++;
        }

        this.fitnessScores.put(gen, fitnessScores);
    }


    public double getBestFitnessScore() {
        return this.bestScore;
    }
}
