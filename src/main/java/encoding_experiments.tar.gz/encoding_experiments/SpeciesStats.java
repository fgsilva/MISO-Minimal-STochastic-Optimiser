package encoding_experiments;

import encoding_experiments.coevolve.CoEvolveEquiInitGenome;
import org.encog.ml.ea.population.Population;
import org.encog.ml.ea.species.Species;
import org.encog.neural.neat.NEATPopulation;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class SpeciesStats {

    private ArrayList<Integer> generations = new ArrayList<Integer>();
    private ArrayList<SpeciesInfo> speciesInfo = new ArrayList<SpeciesInfo>();

    public void recordInfo(int gen, Population population) {
        SpeciesInfo info = this.computeSpeciesInfo(population);

        this.generations.add(gen);
        this.speciesInfo.add(info);
    }

    private SpeciesInfo computeSpeciesInfo(Population population) {
        NEATPopulation pop = (NEATPopulation) population;
        SpeciesInfo info = new SpeciesInfo(pop.getSpecies().size());
        info.storeInformation(pop);
        return info;
    }

    public void flushSpeciesStats(String outputFolder) throws IOException {

        BufferedWriter writer = new BufferedWriter(new FileWriter(outputFolder + "species_info.csv"));

        for (int i = 0; i < generations.size(); i++) {
            writer.write(generations.get(i) + " " + speciesInfo.get(i).toString(" "));
            writer.newLine();
        }

        writer.close();
    }

    public void clear() {
        this.generations.clear();
        this.speciesInfo.clear();
    }

    private static class SpeciesInfo {

        private int numberSpecies;
        private boolean usingHybridEncoding;

        private int[] speciesType;

        private final short DIRECT_ENC_SPECIES = 1;
        private final short INDIRECT_ENC_SPECIES = 2;
        private final short HYBRID_ENC_SPECIES = 3;

        private int[] speciesSize;
        private int[] speciesAge;
        private double[] speciesBestScore;

        public String toString(String separator) {
            StringBuilder builder = new StringBuilder();
            //number of species
            builder.append(String.valueOf(this.numberSpecies));
            builder.append(separator);

            //using hybrid encoding?
            builder.append(usingHybridEncoding);
            builder.append(separator);

            //for each species
            for (int i = 0; i < numberSpecies; i++) {
                //species size
                builder.append(speciesSize[i] + "");
                builder.append(separator);

                //species type
                builder.append(toString(speciesType[i]) + "");
                builder.append(separator);

                //best score
                builder.append(speciesBestScore[i] + "");
                builder.append(separator);

                //age
                builder.append(speciesAge[i] + "");
                builder.append(separator);
            }


            return builder.toString();
        }

        private String toString(int type) {
            switch (type) {
                case DIRECT_ENC_SPECIES:
                    return "d";
                case INDIRECT_ENC_SPECIES:
                    return "i";
                case HYBRID_ENC_SPECIES:
                    return "h";
                default:
                    return "d";
            }
        }

        private SpeciesInfo(int numberOfSpecies) {
            this.numberSpecies = numberOfSpecies;
            this.speciesType = new int[numberSpecies];
            this.speciesSize = new int[numberSpecies];
            this.speciesAge = new int[numberSpecies];
            this.speciesBestScore = new double[numberSpecies];
        }

        public void storeInformation(NEATPopulation pop) {
            if (pop.getBestGenome() instanceof CoEvolveEquiInitGenome) {
                this.usingHybridEncoding = true;
            }
            int index = 0;
            for (Species s : pop.getSpecies()) {
                speciesSize[index] = s.getMembers().size();
                speciesAge[index] = s.getAge();
                speciesBestScore[index] = s.getBestScore();
                if (this.usingHybridEncoding) {
                    CoEvolveEquiInitGenome g = (CoEvolveEquiInitGenome) s.getLeader();
                    if (g.getDirectLinksExpressed() && g.getIndirectLinksExpressed()) {
                        speciesType[index] = HYBRID_ENC_SPECIES;
                    } else if (g.getDirectLinksExpressed()) {
                        speciesType[index] = DIRECT_ENC_SPECIES;
                    } else {
                        speciesType[index] = INDIRECT_ENC_SPECIES;
                    }
                }
                index++;
            }
        }
    }


}
