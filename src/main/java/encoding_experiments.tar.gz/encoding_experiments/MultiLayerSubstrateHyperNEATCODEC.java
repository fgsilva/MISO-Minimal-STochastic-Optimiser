package encoding_experiments;

import encoding_experiments.functions.RescaledSigmoid;
import encoding_experiments.layeredNets.LayeredANN;
import encoding_experiments.layeredNets.LayeredNEATCODEC;
import org.encog.engine.network.activation.ActivationFunction;
import org.encog.engine.network.activation.ActivationSteepenedSigmoid;
import org.encog.ml.MLMethod;
import org.encog.ml.data.MLData;
import org.encog.ml.data.basic.BasicMLData;
import org.encog.ml.ea.genome.Genome;
import org.encog.neural.hyperneat.HyperNEATCODEC;
import org.encog.neural.hyperneat.substrate.Substrate;
import org.encog.neural.hyperneat.substrate.SubstrateNode;
import org.encog.neural.neat.NEATLink;
import org.encog.neural.neat.NEATPopulation;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class MultiLayerSubstrateHyperNEATCODEC extends HyperNEATCODEC implements Serializable {

    protected double minWeight, maxWeight;
    protected boolean useBias, useRecurrence;

    protected ActivationFunction function;

    protected final boolean biasFirstCPPN = false;
    protected final boolean biasFirstANN = true;

    public MultiLayerSubstrateHyperNEATCODEC(double minWeight, double maxWeight,
                                             boolean useBias, boolean useRecurrence, boolean useTanh) {
        this.minWeight = minWeight;
        this.maxWeight = maxWeight;
        this.useBias = useBias;
        this.useRecurrence = useRecurrence;
        /** set the activation function (tanh or steepened sigmoid)**/

        function = useTanh ? new RescaledSigmoid() : new ActivationSteepenedSigmoid();
    }

    @Override
    public MLMethod decode(Genome genome) {
        final NEATPopulation pop = (NEATPopulation) genome.getPopulation();
        final Substrate substrate = pop.getSubstrate();
        return decode(pop, substrate, genome);
    }

    @Override
    public MLMethod decode(final NEATPopulation pop, final Substrate substrate,
                           final Genome genome) {
        // obtain the CPPN
        final LayeredNEATCODEC neatCodec = new LayeredNEATCODEC(biasFirstCPPN);
        final LayeredANN cppn = (LayeredANN) neatCodec.decode(genome);
        final ArrayList<NEATLink> linkList = new ArrayList<NEATLink>();

        //final ActivationFunction[] afs = new ActivationFunction[substrate.getNodeCount()];

        final ActivationFunction af = this.function.clone();
        // all activation functions are the same
        /*for (int i = 0; i < afs.length; i++) {
            afs[i] = af;
		}*/


        decodeDirectWeights(substrate, cppn, linkList);
        decodeRecurrentLinks(substrate, cppn, linkList);
        decodeBiasLinks(substrate, cppn, linkList, 1);

        BasicSubstrateHyperNEATCODEC basic = new BasicSubstrateHyperNEATCODEC();

        LayeredANN net = basic.createNetworkFromNEATLinks(linkList, substrate, af);
        return net;

        // check for invalid neural network
		/*if (linkList.size() == 0) {
			return null;
		}

		Collections.sort(linkList);

		final NEATNetwork network = new NEATNetwork(substrate.getInputCount(),
				substrate.getOutputCount(), linkList, afs);

		network.setActivationCycles(substrate.getActivationCycles());
		return network;*/
    }

    protected void decodeBiasLinks(Substrate substrate, LayeredANN cppn,
                                   ArrayList<NEATLink> linkList, int cppnBiasOutputIndex) {
        //input vector
        final MLData input = new BasicMLData(cppn.getInputCount());


        // now create biased links
        if (this.useBias) {
            input.clear();
            final List<SubstrateNode> biasedNodes = substrate.getBiasedNodes();
            for (final SubstrateNode target : biasedNodes) {
                //query the cppn to get the bias value for node at (x,y)
                //cppn input = (x,y, 0, 0)
                double[] targetLocation = target.getLocation();
                input.setData(0, targetLocation[0]);
                input.setData(1, targetLocation[1]);

                //input.setData(4, cppnBias);

                final MLData output = cppn.compute(input);

                double biasWeight = 0;
                try {
                    biasWeight = output.getData(cppnBiasOutputIndex);
                } catch (ArrayIndexOutOfBoundsException e) {
                    System.out.println("ml - np1");
                } catch (IndexOutOfBoundsException e) {
                    System.out.println("ml - np2");
                }
                if (Math.abs(biasWeight) > this.minWeight) {
                    //rescale.
                    biasWeight *= this.maxWeight;
                } else
                    biasWeight = 0;
                linkList.add(new NEATLink(0, target.getId(), biasWeight));
            }
        }
    }

    protected void decodeRecurrentLinks(
            Substrate substrate, LayeredANN cppn, ArrayList<NEATLink> linkList) {

        //create recurrent links
        if (this.useRecurrence) {
            this.decodeSelfRecurrent(substrate.getHiddenNodes(), 0, linkList, cppn);
            this.decodeSelfRecurrent(substrate.getOutputNodes(), 0, linkList, cppn);
        }
    }

    private void decodeSelfRecurrent(List<SubstrateNode> nodes, int cppnOutputIndex,
                                     ArrayList<NEATLink> linkList, LayeredANN cppn) {
        //input vector
        final MLData input = new BasicMLData(cppn.getInputCount());

        for (SubstrateNode target : nodes) {
            //SubstrateNode source = link.getSource(), target = link.getTarget();
            double[] targetLocation = target.getLocation();
            //x1, y1, x1, y1, i.e., link from self & to self
            input.setData(new double[]{targetLocation[0], targetLocation[1], targetLocation[0], targetLocation[1]});

            final MLData output = cppn.compute(input);
            //connection weight as cppn output number 1
            double weight = output.getData(cppnOutputIndex);
            if (Math.abs(weight) > this.minWeight) {
                //rescale.
                weight *= this.maxWeight;
            } else
                weight = 0;
            linkList.add(new NEATLink(target.getId(), target.getId(), weight));
        }
    }

    protected void decodeDirectWeights(Substrate substrate, LayeredANN cppn,
                                       ArrayList<NEATLink> linkList) {


        //create all non-bias non-recurrent links
        //first, input to hidden
        this.decodeFromTo(substrate.getInputNodes(),
                substrate.getHiddenNodes(), 0, linkList, cppn);
        //then, hidden to output
        this.decodeFromTo(substrate.getHiddenNodes(),
                substrate.getOutputNodes(), 0, linkList, cppn);
    }

    private void decodeFromTo(List<SubstrateNode> inputNodes,
                              List<SubstrateNode> targetNodes, int cppnOutputIndex,
                              ArrayList<NEATLink> linkList, LayeredANN cppn) {
        //input vector
        final MLData input = new BasicMLData(cppn.getInputCount());

        for (SubstrateNode source : inputNodes) {
            for (SubstrateNode target : targetNodes) {
                //SubstrateNode source = link.getSource(), target = link.getTarget();
                double[] sourceLocation = source.getLocation(), targetLocation = target.getLocation();
                //x1, y1, x2, y2
                input.setData(new double[]{sourceLocation[0], sourceLocation[1],
                        targetLocation[0], targetLocation[1]});

                final MLData output = cppn.compute(input);
                double weight = output.getData(cppnOutputIndex);

                if (Math.abs(weight) > this.minWeight) {
                    //rescale.
                    weight *= this.maxWeight;
                } else
                    weight = 0;
                linkList.add(new NEATLink(source.getId(), target.getId(), weight));
            }
        }
    }

    /**
     * @return the maxWeight
     */
    public double getMaxWeight() {
        return this.maxWeight;
    }

    /**
     * @return the minWeight
     */
    public double getMinWeight() {
        return this.minWeight;
    }

    /**
     * @param maxWeight the maxWeight to set
     */
    public void setMaxWeight(final double maxWeight) {
        this.maxWeight = maxWeight;
    }

    /**
     * @param minWeight the minWeight to set
     */
    public void setMinWeight(final double minWeight) {
        this.minWeight = minWeight;
    }

    /**
     * @return the useBias
     */
    public boolean isUseBias() {
        return useBias;
    }

    /**
     * @return the useRecurrence
     */
    public boolean isUseRecurrence() {
        return useRecurrence;
    }

    /**
     * @param useBias the useBias to set
     */
    public void setUseBias(boolean useBias) {
        this.useBias = useBias;
    }

    /**
     * @param useRecurrence the useRecurrence to set
     */
    public void setUseRecurrence(boolean useRecurrence) {
        this.useRecurrence = useRecurrence;
    }


}
