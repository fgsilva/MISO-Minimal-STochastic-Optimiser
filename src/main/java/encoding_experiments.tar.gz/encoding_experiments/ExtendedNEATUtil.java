package encoding_experiments;

import encoding_experiments.coevolve.*;
import org.encog.ml.CalculateScore;
import org.encog.ml.ea.opp.CompoundOperator;
import org.encog.ml.ea.opp.selection.TruncationSelection;
import org.encog.ml.ea.train.basic.TrainEA;
import org.encog.neural.neat.training.opp.NEATCrossover;
import org.encog.neural.neat.training.opp.NEATMutateAddLink;
import org.encog.neural.neat.training.opp.NEATMutateAddNode;
import org.encog.neural.neat.training.opp.NEATMutateWeights;
import org.encog.neural.neat.training.opp.links.MutatePerturbLinkWeight;
import org.encog.neural.neat.training.opp.links.MutateResetLinkWeight;
import org.encog.neural.neat.training.opp.links.SelectProportion;

import java.util.Properties;

public class ExtendedNEATUtil {

    /*public static synchronized RegisterTrainEA constructRefinementCombinedEncodingTrainer(
            Properties properties, ExtendedNEATPopulation pop, CalculateScore score,
            boolean addNewStructure, boolean signedActivation) {
        /**final RegisterTrainEA result = new RegisterTrainEA(pop, score);


         //speciation
         CoEvolveGenomeSpeciation speciation = loadSCombinedGenomepeciation(properties);
         result.setSpeciation(speciation);

         //selection
         double survivalThreshold = Double.valueOf(properties.getProperty("survivalThreshold"));
         result.setSelection(new TruncationSelection(result, survivalThreshold));

         //operators
         double mutateLinkWeightProb = Double.valueOf(properties.getProperty("mutateLinkWeightsProbability"));
         double crossoverProb = Double.valueOf(properties.getProperty("crossoverProbability"));
         final CompoundOperator weightMutation = new CompoundOperator();

         //weightMutation.getComponents().add(0.9,new NEATMutateWeights(new SelectProportion(0.1),new MutatePerturbLinkWeight(0.1)));
         //weightMutation.getComponents().add(0.1,new NEATMutateWeights(new SelectProportion(0.1),new MutateResetLinkWeight()));

         weightMutation.getComponents().add(0.9,new NEATMutateWeights(
         new CoEvolveGenomeSelectLinkProportion(0.1),new MutatePerturbLinkWeight(0.1)));
         weightMutation.getComponents().add(0.1,new NEATMutateWeights(
         new CoEvolveGenomeSelectLinkProportion(0.1),new MutateResetLinkWeight()));
         weightMutation.getComponents().finalizeStructure();
         result.setChampMutation(weightMutation);

         result.addOperation(crossoverProb, new CoEvolveGenomeCrossover());
         //result.addOperation(crossoverProb, new NEATCrossover());

         result.addOperation(mutateLinkWeightProb, weightMutation);


         if(addNewStructure){
         double mutateAddLinkProbability = Double.valueOf(properties.getProperty("mutateAddLinkProbability"));
         double mutateAddNodeProbability = Double.valueOf(properties.getProperty("mutateAddNodeProbability"));
         result.addOperation(mutateAddNodeProbability, new CoEvolveGenomeMutateAddNode(signedActivation));
         result.addOperation(mutateAddLinkProbability, new CoEvolveGenomeMutateAddLink());
         }
         //result.addOperation(0.05, new NEATMutateRemoveLink());
         result.getOperators().finalizeStructure();

         return result;
    }

    /*public static synchronized TrainEA constructIncrementalCombinedEncodingTrainer(
            Properties properties, ExtendedNEATPopulation pop, CalculateScore score,
            boolean addNewStructure) {
        final TrainEA result = new TrainEA(pop, score);

        //speciation
        CoEvolveGenomeSpeciation speciation = loadSCombinedGenomepeciation(properties);
        result.setSpeciation(speciation);

        //selection
        double survivalThreshold = Double.valueOf(properties.getProperty("survivalThreshold"));
        result.setSelection(new TruncationSelection(result, survivalThreshold));

        //operators
        double mutateLinkWeightProb = Double.valueOf(properties.getProperty("mutateLinkWeightsProbability"));
        double crossoverProb = Double.valueOf(properties.getProperty("crossoverProbability"));
        final CompoundOperator weightMutation = new CompoundOperator();


        weightMutation.getComponents().add(0.9, new NEATMutateWeights(new SelectProportion(0.1), new MutatePerturbLinkWeight(0.1)));
        weightMutation.getComponents().add(0.1, new NEATMutateWeights(new SelectProportion(0.1), new MutateResetLinkWeight()));
        weightMutation.getComponents().finalizeStructure();
        result.setChampMutation(weightMutation);

        result.addOperation(crossoverProb, new CoEvolveGenomeCrossover());

        result.addOperation(mutateLinkWeightProb, weightMutation);

        //offset link enable or disable
        result.addOperation(0.15, new CEGMutateChangeDirectExpressionWeights());


        if (addNewStructure) {
            double mutateAddLinkProbability = Double.valueOf(properties.getProperty("mutateAddLinkProbability"));
            double mutateAddNodeProbability = Double.valueOf(properties.getProperty("mutateAddNodeProbability"));
            result.addOperation(mutateAddNodeProbability, new NEATMutateAddNode());
            result.addOperation(mutateAddLinkProbability, new NEATMutateAddLink());
            result.addOperation(mutateAddLinkProbability / 4, new NEATMutateRemoveLink());
        }

        result.getOperators().finalizeStructure();
        return result;
    }*/


    public static synchronized TrainEA constructCombinedEquiInitTrainer(Properties properties,
                                                                        ExtendedNEATPopulation pop, CalculateScore score,
                                                                        boolean addNewStructureIndirect, boolean addStructureDirect) {
        final TrainEA result = new TrainEA(pop, score);

        //speciation
        CoEvolveGenomeSpeciation speciation = loadSCombinedGenomepeciation(properties);
        result.setSpeciation(speciation);

        //selection
        double survivalThreshold = Double.valueOf(properties.getProperty("survivalThreshold"));
        result.setSelection(new TruncationSelection(result, survivalThreshold));

        //operators
        double mutateLinkWeightProb = Double.valueOf(properties.getProperty("mutateLinkWeightsProbability"));
        double crossoverProb = Double.valueOf(properties.getProperty("crossoverProbability"));
        final CompoundOperator weightMutation = new CompoundOperator();

        //weightMutation.getComponents().add(0.9,new NEATMutateWeights(new SelectProportion(0.1),new MutatePerturbLinkWeight(0.1)));
        //weightMutation.getComponents().add(0.1,new NEATMutateWeights(new SelectProportion(0.1),new MutateResetLinkWeight()));

        weightMutation.getComponents().add(0.9, new NEATMutateWeights(
                new CoEvolveEquiInitGenomeSelectLinkProportion(0.1),
                new MutatePerturbLinkWeight(0.1)));
        weightMutation.getComponents().add(0.1, new NEATMutateWeights(
                new CoEvolveEquiInitGenomeSelectLinkProportion(0.1),
                new MutateResetLinkWeight()));
        weightMutation.getComponents().finalizeStructure();
        result.setChampMutation(weightMutation);

        result.addOperation(crossoverProb, new CoEvolveGenomeCrossover());
        //result.addOperation(crossoverProb, new NEATCrossover());

        result.addOperation(mutateLinkWeightProb, weightMutation);

        //offset link enable or disable
        result.addOperation(0.4, new EquiInitExpressionLinkStatusChange());


        double mutateAddLinkProbability =
                Double.valueOf(properties.getProperty("mutateAddLinkProbability"));
        double mutateAddNodeProbability =
                Double.valueOf(properties.getProperty("mutateAddNodeProbability"));

        if (addNewStructureIndirect && !addStructureDirect) {
            result.addOperation(mutateAddNodeProbability, new NEATMutateAddNode());
            result.addOperation(mutateAddLinkProbability, new NEATMutateAddLink());
        } else if (addNewStructureIndirect && addStructureDirect) {
            result.addOperation(mutateAddLinkProbability, new CoEvolveGenomeMutateAddLink());
            result.addOperation(mutateAddNodeProbability, new CoEvolveGenomeMutateAddNode());
        }
        //result.addOperation(0.05, new NEATMutateRemoveLink());
        result.getOperators().finalizeStructure();

        return result;

    }

    /*public static synchronized TrainEA constructCombinedEncodingTrainer(Properties properties,
                                                                        ExtendedNEATPopulation pop, CalculateScore score, boolean addNewStructure) {
        final TrainEA result = new TrainEA(pop, score);

        //speciation
        CoEvolveGenomeSpeciation speciation = loadSCombinedGenomepeciation(properties);
        result.setSpeciation(speciation);

        //selection
        double survivalThreshold = Double.valueOf(properties.getProperty("survivalThreshold"));
        result.setSelection(new TruncationSelection(result, survivalThreshold));

        //operators
        double mutateLinkWeightProb = Double.valueOf(properties.getProperty("mutateLinkWeightsProbability"));
        double crossoverProb = Double.valueOf(properties.getProperty("crossoverProbability"));
        final CompoundOperator weightMutation = new CompoundOperator();

        //weightMutation.getComponents().add(0.9,new NEATMutateWeights(new SelectProportion(0.1),new MutatePerturbLinkWeight(0.1)));
        //weightMutation.getComponents().add(0.1,new NEATMutateWeights(new SelectProportion(0.1),new MutateResetLinkWeight()));

        weightMutation.getComponents().add(0.9, new NEATMutateWeights(new CoEvolveGenomeSelectLinkProportion(0.1), new MutatePerturbLinkWeight(0.1)));
        weightMutation.getComponents().add(0.1, new NEATMutateWeights(new CoEvolveGenomeSelectLinkProportion(0.1), new MutateResetLinkWeight()));
        weightMutation.getComponents().finalizeStructure();
        result.setChampMutation(weightMutation);

        result.addOperation(crossoverProb, new CoEvolveGenomeCrossover());
        //result.addOperation(crossoverProb, new NEATCrossover());

        result.addOperation(mutateLinkWeightProb, weightMutation);

        //offset link enable or disable
        result.addOperation(0.4, new ExpressionLinkStatusChange());


        if (addNewStructure) {
            double mutateAddLinkProbability = Double.valueOf(properties.getProperty("mutateAddLinkProbability"));
            double mutateAddNodeProbability = Double.valueOf(properties.getProperty("mutateAddNodeProbability"));
            result.addOperation(mutateAddNodeProbability, new NEATMutateAddNode());
            result.addOperation(mutateAddLinkProbability, new NEATMutateAddLink());
        }
        //result.addOperation(0.05, new NEATMutateRemoveLink());
        result.getOperators().finalizeStructure();

        return result;
    }*/

    private static synchronized CoEvolveGenomeSpeciation loadSCombinedGenomepeciation(
            Properties properties) {
        CoEvolveGenomeSpeciation speciation = new CoEvolveGenomeSpeciation();
        /** load **/
        double disjointCoeff = Double.valueOf(properties.getProperty("disjointCoefficient"));
        double excessCoeff = Double.valueOf(properties.getProperty("excessCoefficient"));
        double weightDiffCoeff = Double.valueOf(properties.getProperty("weightDifferenceCoefficient"));
        double compatThreshold = Double.valueOf(properties.getProperty("compatibilityThreshold", "6.0"));
        int gensNoImprovement = Integer.valueOf(properties.getProperty("dropoffAge"));
        int targetNumberSpecies = Integer.valueOf(properties.getProperty("speciesTarget"));

        /** set **/
        speciation.setCompatibilityThreshold(compatThreshold);
        speciation.setConstDisjoint(disjointCoeff);
        speciation.setConstExcess(excessCoeff);
        speciation.setConstMatched(weightDiffCoeff);
        speciation.setNumGensAllowedNoImprovement(gensNoImprovement);
        speciation.setMaxNumberOfSpecies(targetNumberSpecies);

        return speciation;
    }

    public static synchronized TrainEA constructTrainer(Properties properties,
                                                        ExtendedNEATPopulation pop, CalculateScore score, boolean addNewStructure) {
        /** EA */
        final TrainEA result = new TrainEA(pop, score);
        //speciation
        RevisedNEATSpeciation speciation = loadSpeciation(properties);
        result.setSpeciation(speciation);

        //selection
        double survivalThreshold = Double.valueOf(properties.getProperty("survivalThreshold"));
        result.setSelection(new TruncationSelection(result, survivalThreshold));

        //operators
        double mutateLinkWeightProb = Double.valueOf(properties.getProperty("mutateLinkWeightsProbability"));
        double crossoverProb = Double.valueOf(properties.getProperty("crossoverProbability"));
        final CompoundOperator weightMutation = new CompoundOperator();

        weightMutation.getComponents().add(0.9, new NEATMutateWeights(new SelectProportion(0.1), new MutatePerturbLinkWeight(0.1)));
        weightMutation.getComponents().add(0.1, new NEATMutateWeights(new SelectProportion(0.1), new MutateResetLinkWeight()));
        weightMutation.getComponents().finalizeStructure();
        result.setChampMutation(weightMutation);

        result.addOperation(crossoverProb, new NEATCrossover());
        result.addOperation(mutateLinkWeightProb, weightMutation);

        if (addNewStructure) {
            double mutateAddLinkProbability = Double.valueOf(properties.getProperty("mutateAddLinkProbability"));
            double mutateAddNodeProbability = Double.valueOf(properties.getProperty("mutateAddNodeProbability"));
            result.addOperation(mutateAddNodeProbability, new NEATMutateAddNode());
            result.addOperation(mutateAddLinkProbability, new NEATMutateAddLink());
        }
        //result.addOperation(0.05, new NEATMutateRemoveLink());
        result.getOperators().finalizeStructure();

        return result;
    }

    private static synchronized RevisedNEATSpeciation loadSpeciation(Properties properties) {
        RevisedNEATSpeciation speciation = new RevisedNEATSpeciation();
        /** load **/
        double disjointCoeff = Double.valueOf(properties.getProperty("disjointCoefficient"));
        double excessCoeff = Double.valueOf(properties.getProperty("excessCoefficient"));
        double weightDiffCoeff = Double.valueOf(properties.getProperty("weightDifferenceCoefficient"));
        double compatThreshold = Double.valueOf(properties.getProperty("compatibilityThreshold", "6.0"));
        int gensNoImprovement = Integer.valueOf(properties.getProperty("dropoffAge"));
        int targetNumberSpecies = Integer.valueOf(properties.getProperty("speciesTarget"));

        /** set **/
        speciation.setCompatibilityThreshold(compatThreshold);
        speciation.setConstDisjoint(disjointCoeff);
        speciation.setConstExcess(excessCoeff);
        speciation.setConstMatched(weightDiffCoeff);
        speciation.setNumGensAllowedNoImprovement(gensNoImprovement);
        speciation.setMaxNumberOfSpecies(targetNumberSpecies);

        return speciation;
    }

    //currently similar to the EA by hyperneat and neat. future prospects in mind.
    public static synchronized RegisterTrainEA constructRegisterTrainer(Properties properties,
                                                                        ExtendedNEATPopulation pop, CalculateScore score, boolean addNewStructure) {
        /** EA */
        final RegisterTrainEA result = new RegisterTrainEA(pop, score);
        //speciation
        RevisedNEATSpeciation speciation = loadSpeciation(properties);
        result.setSpeciation(speciation);

        //selection
        double survivalThreshold = Double.valueOf(properties.getProperty("survivalThreshold"));
        result.setSelection(new TruncationSelection(result, survivalThreshold));

        //operators
        double mutateLinkWeightProb = Double.valueOf(properties.getProperty("mutateLinkWeightsProbability"));
        double crossoverProb = Double.valueOf(properties.getProperty("crossoverProbability"));
        final CompoundOperator weightMutation = new CompoundOperator();

        weightMutation.getComponents().add(0.9, new NEATMutateWeights(new SelectProportion(0.1), new MutatePerturbLinkWeight(0.1)));
        weightMutation.getComponents().add(0.1, new NEATMutateWeights(new SelectProportion(0.1), new MutateResetLinkWeight()));
        weightMutation.getComponents().finalizeStructure();
        result.setChampMutation(weightMutation);

        result.addOperation(crossoverProb, new NEATCrossover());
        result.addOperation(mutateLinkWeightProb, weightMutation);

        if (addNewStructure) {
            double mutateAddLinkProbability = Double.valueOf(properties.getProperty("mutateAddLinkProbability"));
            double mutateAddNodeProbability = Double.valueOf(properties.getProperty("mutateAddNodeProbability"));
            result.addOperation(mutateAddNodeProbability, new NEATMutateAddNode());
            result.addOperation(mutateAddLinkProbability, new NEATMutateAddLink());
        }
        //result.addOperation(0.05, new NEATMutateRemoveLink());
        result.getOperators().finalizeStructure();

        return result;
    }


}
