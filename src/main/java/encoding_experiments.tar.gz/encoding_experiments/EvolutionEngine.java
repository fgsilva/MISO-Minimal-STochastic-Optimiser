package encoding_experiments;


import ai.GameScore2048;
import org.encog.ml.CalculateScore;

import java.io.*;
import java.util.*;
import java.util.zip.GZIPOutputStream;


public class EvolutionEngine {

    //private static int runOffset = 0;

   // public static void setRunOffSet(int newOffset) {
   //     runOffset = newOffset;
    //}

    /**
     * @param args
     * @throws IOException
     * @throws
     */
    public static void main(String[] args) throws IOException {
        /*String conf = args[0];

        /**
         * setup
         */
        /*Properties prop = new Properties();
        prop.load(new FileInputStream(conf));
        /** prepare to execute **/
        /*int runs = Integer.valueOf(prop.getProperty("runs"));
        String task = prop.getProperty("task");

        String fitnessFile = prop.getProperty("fitnessFile");
        String topLevelOutputFolder = prop.getProperty("outputFolder");

        long seed = Long.valueOf(prop.getProperty("randomSeed"));
        Random masterRandom = new Random(seed);

        int activationCycles = Integer.valueOf(prop.getProperty("activationCycles", "1"));

        //hybrid encoding
        boolean executeEvolHybrid = Boolean.valueOf(prop.getProperty("hybrid", "false"));
        String hybridType = String.valueOf(prop.getProperty("hybrid-type"));

        //neat or hyperneat
        boolean isHyperNEAT = Boolean.valueOf(prop.getProperty("isHyperneat"));

        /*if (task.equalsIgnoreCase("visual-discrimination")) {
            for (int run = 1; run <= runs; run++) {
                //each run with a different seed
                int absoluteRun = run + EvolutionEngine.runOffset;
                Random runRandom = new Random(masterRandom.nextLong());
                executeBoxesScoreRunRun(topLevelOutputFolder, absoluteRun,
                        runRandom, prop, fitnessFile, activationCycles,
                        isHyperNEAT, executeEvolHybrid, hybridType);
            }
        } else if (task.equalsIgnoreCase("inverted-pendulum")) {

            final double chainMin = Double.valueOf(prop.getProperty("chain-length-min"));
            final double chainMax = Double.valueOf(prop.getProperty("chain-length-max"));
            final double chainLengthStep = Double.valueOf(prop.getProperty("chain-length-step"));

            final int cartsMin = Integer.valueOf(prop.getProperty("carts-min"));
            final int cartsMax = Integer.valueOf(prop.getProperty("carts-max"));
            final int cartsStep = Integer.valueOf(prop.getProperty("carts-step"));

            //for chain length
            for (double chain = chainMin; chain <= chainMax; chain += chainLengthStep) {
                for (int carts = cartsMin; carts <= cartsMax; carts += cartsStep) {
                    for (int run = 1; run <= runs; run++) {
                        int absoluteRun = run + EvolutionEngine.runOffset;

                        Random runRandom = new Random(masterRandom.nextLong());
                        executeInvertedPendulum(topLevelOutputFolder, absoluteRun,
                                runRandom, prop, fitnessFile, activationCycles,
                                isHyperNEAT, executeEvolHybrid, hybridType, carts, chain);
                    }
                }
            }

        } else if (task.equalsIgnoreCase("targetWeights")) {
            double regularityMax = Double.valueOf(prop.getProperty("regularityMax"));
            double regularityMin = Double.valueOf(prop.getProperty("regularityMin"));
            double regularityStep = Double.valueOf(prop.getProperty("regularityStep"));

            for (double reg = regularityMax; reg >= regularityMin; reg -= regularityStep) {
                System.out.print("reg: " + reg);
                for (int run = 1; run <= runs; run++) {
                    //each run with a different seed
                    int absoluteRun = run + EvolutionEngine.runOffset;
                    Random runRandom = new Random(masterRandom.nextLong());
                    executeTargetWeightsRun(topLevelOutputFolder, absoluteRun, reg,
                            runRandom, prop, fitnessFile, activationCycles,
                            isHyperNEAT, executeEvolHybrid, hybridType);
                }
                System.out.println("====================");
            }
        } else if (task.equalsIgnoreCase("bitmirroring")) {
            double regularityMax = Double.valueOf(prop.getProperty("regularityMax"));
            double regularityMin = Double.valueOf(prop.getProperty("regularityMin"));
            double regularityStep = Double.valueOf(prop.getProperty("regularityStep"));

            /**
             * first, vary within-column regularity (within-row fixed at "regularityMax")
             */
            /*System.out.println("BIT MIRRORING EXP 1 (WC-REG)");
            double withinRowReg = regularityMax;
            double withinColumnReg;
            //System.out.println("reg min: " + regularityMin + "; step: " + regularityStep);
            //System.exit(0);
            for (withinColumnReg = regularityMax; withinColumnReg >= regularityMin; withinColumnReg -= regularityStep) {
                System.out.print("WR-REG: " + withinRowReg + "; WC-REG: " + withinColumnReg);
                for (int run = 1; run <= runs; run++) {
                    //each run with a different seed
                    Random runRandom = new Random(masterRandom.nextLong());
                    executeBitMirroringRun(topLevelOutputFolder, run, runRandom, prop, fitnessFile,
                            withinColumnReg, withinRowReg, activationCycles, isHyperNEAT, executeEvolHybrid, hybridType);
                }
                System.out.println("====================");
            }

            withinColumnReg = 0.0;

            /**
             * now, within-column regularity = 0, vary within-row regularity
             */
           /* System.out.println("BIT MIRRORING EXP 2 (WR-REG)");
            for (withinRowReg = regularityMax; withinRowReg >= regularityMin; withinRowReg -= regularityStep) {
                System.out.print("WR-REG: " + withinRowReg + "; WC-REG: " + withinColumnReg);
                for (int run = 1; run <= runs; run++) {
                    //each run with a different seed
                    Random runRandom = new Random(masterRandom.nextLong());
                    executeBitMirroringRun(topLevelOutputFolder, run, runRandom, prop, fitnessFile,
                            withinColumnReg, withinRowReg, activationCycles, isHyperNEAT, executeEvolHybrid, hybridType);
                }
                System.out.println("====================");
            }

        }*/
    }

    public void execute2048(String topLevelOutputFolder, int run, Random runRandom, Properties prop, String fitnessFile,
                            int activationCycles, boolean isHyperNEAT,
                            boolean executeEvolHybrid, String hybridType, int trials){
        String outputFolder = topLevelOutputFolder + "/run_" + run + "/";
        createFolder(outputFolder);

        GameScore2048 score = new GameScore2048(trials, runRandom);
        ExtendedNEATTask hntask = new ExtendedNEATTask(outputFolder, score,
                fitnessFile, activationCycles, isHyperNEAT, executeEvolHybrid, hybridType);
        hntask.execute(prop);
        System.out.print("\t" + run);
    }

    /*private static void executeInvertedPendulum(String topLevelOutputFolder,
                                                int run, Random runRandom, Properties prop, String fitnessFile,
                                                int activationCycles, boolean isHyperNEAT,
                                                boolean executeEvolHybrid, String hybridType, int carts, double chain) throws IOException {
        String outputFolder = topLevelOutputFolder + "/carts_" + carts + "/chain_" + chain + "/run_" + run + "/";
        /** CREATE OUTPUT DIRECTORY**/
       /* createFolder(outputFolder);

        CoupledPendulumScore score = new CoupledPendulumScore(carts, chain);

        saveSet(score, outputFolder);
        ExtendedNEATTask hntask = new ExtendedNEATTask(outputFolder, score, fitnessFile, activationCycles,
                isHyperNEAT, executeEvolHybrid, hybridType);
        hntask.execute(prop);
        System.out.print("\t" + run);
    }

    private static void executeBoxesScoreRunRun(String topLevelOutputFolder,
                                                int run, Random runRandom, Properties prop, String fitnessFile,
                                                int activationCycles, boolean isHyperNEAT,
                                                boolean executeEvolHybrid, String hybridType) throws IOException {
        String outputFolder = topLevelOutputFolder + "/run_" + run + "/";

        /** CREATE OUTPUT DIRECTORY**/
        /*createFolder(outputFolder);

        BoxesScore score = loadBoxesScore(runRandom, prop);
        saveSet(score, outputFolder);

        ExtendedNEATTask hntask = new ExtendedNEATTask(outputFolder, score, fitnessFile, activationCycles,
                isHyperNEAT, executeEvolHybrid, hybridType);
        hntask.execute(prop);
        System.out.print("\t" + run);
    }

    /*private static BoxesScore loadBoxesScore(Random runRandom, Properties prop) {
        int resolution = Integer.valueOf(prop.getProperty("resolution"));

        return new BoxesScore(resolution, runRandom);
    }

    /*private static void executeBitMirroringRun(String topLevelOutputFolder,
                                               int run, Random random, Properties prop, String fitnessFile,
                                               double withinColumnReg, double withinRowReg, int activationCycles, boolean isHyperNEAT,
                                               boolean executeEvolHybrid, String hybridType) throws IOException {
        String outputFolder = topLevelOutputFolder + "/wc-reg_" + String.format("%.3f", withinColumnReg) +
                "_wr-reg_" + String.format("%.3f", withinRowReg) + "/run_" + run + "/";

        /** CREATE OUTPUT DIRECTORY**/
        //createFolder(outputFolder);
        /** setup and execute **/
        //first, the training set
    /*BitMirroringScore score = loadBitMirroringSet(random, prop, withinColumnReg, withinRowReg);
        //save the set
        saveSet(score, outputFolder);
        ExtendedNEATTask hntask = new ExtendedNEATTask(outputFolder, score, fitnessFile, activationCycles,
                isHyperNEAT, executeEvolHybrid, hybridType);
        hntask.execute(prop);
        System.out.print("\t" + run);
    }

    /*private static BitMirroringScore loadBitMirroringSet(Random random,
                                                         Properties prop, double withinColumnReg, double withinRowReg) {
        int inputNodesX = Integer.valueOf(prop.getProperty("numInputNodesX"));
        int inputNodesY = Integer.valueOf(prop.getProperty("numInputNodesY"));
        int outputNodesX = Integer.valueOf(prop.getProperty("numOutputNodesX"));
        int outputNodesY = Integer.valueOf(prop.getProperty("numOutputNodesY"));

        assert (inputNodesX == outputNodesX && inputNodesY == outputNodesY);

        int[] inputs = loadInputIds(inputNodesX, inputNodesY);
        int[] outputs = loadOutputIds(outputNodesX, outputNodesY, inputs.length);

        HashMap<Integer, Integer> nodesPairing = createBitMirroringPairing(withinColumnReg, withinRowReg,
                random, inputs, outputs, inputNodesX, inputNodesY);

        return new BitMirroringScore(nodesPairing, random);
    }

    /*private static HashMap<Integer, Integer> createBitMirroringPairing(
            double withinColumnReg, double withinRowReg, Random random, int[] inputs, int[] outputs,
            int inputNodesX, int inputNodesY) {
        HashMap<Integer, Integer> pairing;
        if (withinColumnReg < 0.0001 && withinRowReg < 0.0001) {
            pairing = new HashMap<Integer, Integer>();
            ArrayList<Integer> in = new ArrayList<Integer>(inputs.length);
            ArrayList<Integer> out = new ArrayList<Integer>(outputs.length);
            for (int i = 0; i < inputs.length; i++) {
                in.add(inputs[i]);
                out.add(outputs[i]);
            }
            //shuffle
            Collections.shuffle(in, random);
            Collections.shuffle(out, random);

            for (int i = 0; i < in.size(); i++) {
                pairing.put(in.get(i), out.get(i));
            }
        } else {

            ConnectionsSet set = new ConnectionsSet(inputNodesX, inputNodesY, inputs, outputs, random);
            set.createPerfectPairing();
            set.shuffleColumns(withinColumnReg);
            set.shuffleRows(withinRowReg);
            pairing = set.getPairing();
        }
        return pairing;
    }

    /*private static void executeTargetWeightsRun(String topLevelOutputFolder,
                                                int run, double reg, Random random, Properties prop, String fitnessFile, int activationCycles,
                                                boolean isHyperNEAT, boolean executeEvolHybrid, String hybridType) throws IOException {
        String outputFolder = topLevelOutputFolder + "/reg_" + String.format("%.2f", reg) + "/run_" + run + "/";

        /** CREATE OUTPUT DIRECTORY**/
       // createFolder(outputFolder);
        /** setup and execute **/
        //first, the training set
        /*TargetWeightsScore score = loadTargetWeightsSet(random, prop, reg);
        //save the set
        saveSet(score, outputFolder);
        ExtendedNEATTask hntask = new ExtendedNEATTask(outputFolder, score,
                fitnessFile, activationCycles, isHyperNEAT, executeEvolHybrid, hybridType);
        hntask.execute(prop);
        System.out.print("\t" + run);
    }*/

    private static void createFolder(String outputFolder) {
        File folder = new File(outputFolder);
        if (!folder.exists()) {
            folder.mkdirs();
        }
    }

    private static void saveSet(CalculateScore score, String outputFolder) throws IOException {
        FileOutputStream fileOut = new FileOutputStream(outputFolder + "training_set");
        GZIPOutputStream gzipOut = new GZIPOutputStream(fileOut);
        ObjectOutputStream out = new ObjectOutputStream(gzipOut);
        out.writeObject(score);
        out.close();
    }

    /*private static TargetWeightsScore loadTargetWeightsSet(Random random,
                                                           Properties prop, double regularity) {
        int inputNodesX = Integer.valueOf(prop.getProperty("numInputNodesX"));
        int inputNodesY = Integer.valueOf(prop.getProperty("numInputNodesY"));
        int outputNodesX = Integer.valueOf(prop.getProperty("numOutputNodesX"));
        int outputNodesY = Integer.valueOf(prop.getProperty("numOutputNodesY"));
        double netsWeightRange = Double.valueOf(prop.getProperty("netsWeightRange"));

        int[] inputs = loadInputIds(inputNodesX, inputNodesY);
        int[] outputs = loadOutputIds(outputNodesX, outputNodesY, inputs.length);

        TargetWeightsScore score = new TargetWeightsScore(inputs, outputs, regularity,
                netsWeightRange * 2, random, netsWeightRange);

        return score;
    }

    private static int[] loadOutputIds(int outputNodesX, int outputNodesY,
                                       int numberInputs) {
        int[] outputs = new int[outputNodesX * outputNodesY];
        for (int i = 0; i < outputs.length; i++) {
            outputs[i] = numberInputs + 1 + i;
        }

        return outputs;
    }

    private static int[] loadInputIds(int inputNodesX, int inputNodesY) {
        int[] inputs = new int[inputNodesX * inputNodesY];
        for (int i = 0; i < inputs.length; i++) {
            inputs[i] = i + 1;
        }

        return inputs;
    }*/

}
